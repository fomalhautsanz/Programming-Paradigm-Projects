public class HumanStudentTest {
    public static void main(String[] args){
        Student student1 = new Student("Matilda June",19,"2024-00128",
                "Bachelor of Science in Psychology");
        student1.displayInfo();
    }
}
