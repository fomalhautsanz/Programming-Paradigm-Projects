package Vehicle;

public class InvalidPriceException extends Exception{
    InvalidPriceException (String message){
        super(message);
    }
}
