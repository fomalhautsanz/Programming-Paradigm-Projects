package Vehicle;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Car extends Vehicle{
    String status;

    Car(){

    }

    Car(String brand, double price, String status) throws InvalidPriceException{
            super(brand, price);
            this.status = status;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Status: " + status);
    }

    public void applyDiscount(int rate){
        try{
            if (rate<0){
                throw new IllegalArgumentException("Please enter a positive value!");
            }
            price-=(price*rate/100);
            System.out.println(rate + " discount applied.");
            System.out.println("Discounted price: " + price);
        } catch (Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void applyDiscount(double rate){
        try {
            if (rate < 0) {
                throw new IllegalArgumentException("Please enter a positive value!");
            }
            price -= (price * rate / 100);
            System.out.println(rate + " discount applied.");
            System.out.println("Discounted price: " + price);
        } catch (Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static void main (String[] args) throws InvalidPriceException {
        Scanner input = new Scanner(System.in);
        double price = 0;
        Car car = null;
        double rate = 0;

        do {
            try {
                System.out.print("Enter car brand: ");
                String brand = input.nextLine();
                System.out.print("Enter car price: ");
                price = input.nextDouble();
                input.nextLine();
                if (price<0){
                    throw new InvalidPriceException("Please enter a valid price!");
                }
                System.out.print("Enter car status: ");
                String status = input.nextLine();
                car = new Car(brand, price, status);
            } catch (InvalidPriceException e){
                System.out.println("Error: " + e.getMessage());
            }
            catch (NumberFormatException e){
                System.out.println("Please enter a valid numeric price");
            }
        } while (price<0);

        do {
            try {
                System.out.print("Apply discount for " + car.brand + ": ");
                rate = input.nextDouble();
                car.applyDiscount(rate);
            } catch (InputMismatchException e){
                System.out.println("Please enter a valid numeric value!");
            }
        } while (rate<0);

    }
}
