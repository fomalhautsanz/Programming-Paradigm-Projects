package Vehicle;

import java.util.InputMismatchException;

public class Vehicle {
    String brand;
    double price;
    static int count;

    Vehicle(){

    }

    Vehicle(String brand,double price) throws InvalidPriceException{
            if (price<0){
                throw new InvalidPriceException("Please enter a valid price!");
            }
            this.brand = brand;
            this.price = price;
    }

    public void displayInfo(){
        System.out.println("Brand: " + brand);
        System.out.println("Price: " + price);
    }
}
