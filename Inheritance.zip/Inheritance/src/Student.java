public class Student extends Human {


    private String studentID;
    private String course;

    Student(String name, int age, String studentID,String course){
        super(name,age);
        this.studentID=studentID;
        this.course=course;
    }

    public String getStudentID() {
        return studentID;
    }

    public String getCourse() {
        return course;
    }

    @Override
    void displayInfo() {
        super.displayInfo();
        System.out.println("Student ID: " + getStudentID());
        System.out.println("Course: " + getCourse());
    }
}
