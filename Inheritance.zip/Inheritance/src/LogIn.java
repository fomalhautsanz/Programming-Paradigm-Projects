import java.util.Objects;
import java.util.Scanner;

public class LogIn {
    Scanner input = new Scanner(System.in);
    static String adminName = "DocQuack";
    static String password = "healthy098";
    int choice;

    void logInPage(){
        System.out.println("WELCOME TO MEDLIFE");
        System.out.println("1. Log In");
        System.out.println("2. Exit");
        choice=input.nextInt();
        input.nextLine();

        if (choice==1){
            logIn();
        }
        else if (choice==2){
            System.out.println("Thank you for stopping by!");
            System.exit(0);
        }
    }

    boolean isAdmin (String inputUsername, String inputPassword){
        return Objects.equals(inputUsername, adminName) && Objects.equals(inputPassword, password);
    }

    void logIn(){
        System.out.println("Choose log in type\n" +
                "1. Admin\n" +
                "2. Staff");
        choice = input.nextInt();
        input.nextLine();

        if (choice==1){
            while (true) {
                System.out.print("Enter username: ");
                String username = input.nextLine();
                System.out.print("Enter password: ");
                String password = input.nextLine();

                if (isAdmin(username, password)) {
                    AdminPage.adminMenu();
                } else {
                    System.out.println("Incorrect username or password");
                }
            }
        }
        else {
            System.out.println("Staff page is under development...");
        }
    }
}
