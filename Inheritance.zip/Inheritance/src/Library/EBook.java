package Library;

public class EBook extends Book{

    double fileSizeMB;
    EBook(int id,String title,String author,int yearPublished,double fileSizeMB){
        super(id, title, author, yearPublished);
        this.fileSizeMB=fileSizeMB;
    }

    public void setFileSizeMB(double fileSizeMB) {
        this.fileSizeMB = fileSizeMB;
    }

    @Override
    public String toString() {
        return super.toString() + ", File Size MB: " + fileSizeMB;
    }
}
