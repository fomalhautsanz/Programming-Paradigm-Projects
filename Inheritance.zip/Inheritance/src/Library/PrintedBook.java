package Library;

public class PrintedBook extends Book{

    int pageCount;
    PrintedBook(int id,String title,String author,int yearPublished,int pageCount){
        super(id, title, author, yearPublished);
        this.pageCount=pageCount;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }

    @Override
    public String toString() {
        return super.toString() + ", Page Count: " + pageCount;
    }
}
