package Library;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Library {

    Scanner input = new Scanner(System.in);

    ArrayList<Book> books = new ArrayList<Book>();
    int id; String title; String author; int yearPublished; double fileSizeMB; int pageCount;
    int choice;

    public void menu(){
        while (true) {
            System.out.println("================ LIBRARY MANAGEMENT SYSTEM ================");
            System.out.println("1. Add New Book");
            System.out.println("2. Display List of Books");
            System.out.println("3. Update a Book");
            System.out.println("4. Delete a Book");
            System.out.println("5. Exit");
            int menuOpt = input.nextInt();

            switch (menuOpt) {
                case 1:
                    addBook();
                    break;

                case 2:
                    displayBooks();
                    break;

                case 3:
                    updateBook();
                    break;

                case 4:
                    deleteBook();
                    break;

                case 5:
                    System.out.println("Thank you for visiting our library!");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Please enter a valid option!");
            }
        }
    }

    public void addBook(){
        try {
            do {
                System.out.println("\n ADD A BOOK");
                System.out.println("Type of Book");
                System.out.println("1. EBook");
                System.out.println("2. Printed Book");
                System.out.println("3. Exit");
                System.out.print("> ");
                choice = input.nextInt();

                switch (choice) {
                    case 1:
                        System.out.print("Enter Book ID: ");
                        id = input.nextInt();
                        input.nextLine();
                        System.out.print("Enter Book Title: ");
                        title = input.nextLine();
                        System.out.print("Enter Book Author: ");
                        author = input.nextLine();
                        System.out.print("Enter Year Published: ");
                        yearPublished = input.nextInt();
                        System.out.print("Enter File Size MB: ");
                        fileSizeMB = input.nextDouble();
                        books.add(new EBook(id, title, author, yearPublished, fileSizeMB));
                        break;

                    case 2:
                        System.out.print("Enter Book ID: ");
                        id = input.nextInt();
                        input.nextLine();
                        System.out.print("Enter Book Title: ");
                        title = input.nextLine();
                        System.out.print("Enter Book Author: ");
                        author = input.nextLine();
                        System.out.print("Enter Year Published: ");
                        yearPublished = input.nextInt();
                        System.out.print("Enter Page Count: ");
                        pageCount = input.nextInt();
                        books.add(new PrintedBook(id, title, author, yearPublished, pageCount));
                        break;

                    case 3:
                        System.out.println("Returning...");
                        break;

                    default:
                        System.out.println("Invalid option!");
                        break;
                }
            } while (choice!=3);
        } catch (InputMismatchException e){
            System.out.println("Please enter valid data type! ");
        }
    }

    public void displayBooks(){
       for (Book book : books){
           book.showBookDetails(book);
       }
    }

    public void updateBook(){
        displayBooks();
        System.out.print("Enter ID of the book to update: "); int updateBookID = input.nextInt();
        for (int i=0; i<books.size(); i++){
            if (updateBookID==books.get(i).getId()){

                Book book = books.get(i);
                System.out.print("Enter Book ID: "); id = input.nextInt();
                input.nextLine();
                System.out.print("Enter Book Title: "); title = input.nextLine();
                System.out.print("Enter Book Author: "); author = input.nextLine();
                System.out.print("Enter Year Published: "); yearPublished = input.nextInt();
                book.setId(id);
                book.setTitle(title);
                book.setAuthor(author);
                book.setYearPublished(yearPublished);

                if (book instanceof PrintedBook){
                    System.out.print("Enter Page Count: "); pageCount = input.nextInt();
                    ((PrintedBook) book).setPageCount(pageCount);
                }
                else if (book instanceof EBook){
                    System.out.print("Enter File Size MB: "); fileSizeMB = input.nextDouble();
                    ((EBook) book).setFileSizeMB(fileSizeMB);
                }
                System.out.println("Book updated successfully!");
                return;
            }
        }
        System.out.println("Book ID not found.");
    }

    public void deleteBook(){
        displayBooks();
        System.out.print("Enter ID of book to delete: "); int bookDelete = input.nextInt();

        for (int i=0; i<books.size(); i++){
            if (bookDelete==books.get(i).getId()){
                Book book = books.get(i);
                books.remove(book);
                System.out.println("Book deleted successfully!");
            }
        }
    }

    public void initialize(){
        books.add(new PrintedBook(1211,"The Hermit","Keinan Grey",2005,459));
        books.add(new PrintedBook(1239,"Red Willow","Martha Heinz",1998,712));
        books.add(new EBook(2018,"Cyber Flix","Bryan Tan",2017,9.8));
        books.add(new EBook(2156,"Amity's Vale","Linda Seele",2015,7.6));
    }
}
