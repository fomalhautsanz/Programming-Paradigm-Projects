package Library;

public class Test {
    public static void main (String[] args){
        Library myLibrary = new Library();
        myLibrary.initialize();
        myLibrary.menu();
    }
}
