package Library;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Book {
    int id;
    String title;
    String author;
    int yearPublished;

    Book(int id,String title,String author,int yearPublished){
        this.id=id;
        this.title=title;
        this.author=author;
        this.yearPublished=yearPublished;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getYearPublished() {
        return yearPublished;
    }

    public void setYearPublished(int yearPublished) {
        this.yearPublished = yearPublished;
    }

    public String toString(){
        return "Book ID: " + getId() + ", Title: " + getTitle() + ", Author: " + getAuthor() + ", Year: " + getYearPublished();
    }

    public void showBookDetails(Book book){
        System.out.println(book.toString());
    }
}
