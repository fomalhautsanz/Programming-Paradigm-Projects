public class Toddler extends Person {

    String recentDiagnosis;

    Toddler(String name, String sex, int age, String recentDiagnosis){
        super(name, sex, age);
        this.recentDiagnosis = recentDiagnosis;
    }

    void setRecentDiagnosis(String recentDiagnosis){
        this.recentDiagnosis = recentDiagnosis;
    }

    String getRecentDiagnosis(){
        return recentDiagnosis;
    }

    void displayInfo() {
        super.displayInfo();
        System.out.println("Recent Diagnosis: " + recentDiagnosis);
    }
}
