package Saver;

public class BankAccount {
    private double balance;

    BankAccount(){
        balance=0;
    }

    public void deposit (double amount){
        balance+=amount;
    }

    public void withdraw (double amount){
        if (amount<=balance && amount>0){
            balance-=amount;
        }
        else {
            System.out.println("Insufficient funds!");
        }
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}
