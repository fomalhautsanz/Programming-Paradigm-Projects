package Saver;

public class SaverTest {
    public static void main (String[] args){

        SavingsAccount saver1 = new SavingsAccount();
        saver1.setBalance(2000);
        SavingsAccount saver2 = new SavingsAccount();
        saver2.setBalance(3000);

        System.out.println("---------- Configuration: <Default> -------------");
        SavingsAccount.modifyInterestRate(4);
        System.out.println("New Balance for Saver1 = " + saver1.calculateMonthlyInterest(SavingsAccount.annualInterestRate) );
        System.out.println("New Balance for Saver2 = " + saver2.calculateMonthlyInterest(SavingsAccount.annualInterestRate) );

        SavingsAccount.modifyInterestRate(5);
        System.out.println("New Balance for Saver1 = " + saver1.calculateMonthlyInterest(SavingsAccount.annualInterestRate) );
        System.out.println("New Balance for Saver2 = " + saver2.calculateMonthlyInterest(SavingsAccount.annualInterestRate) );

    }
}
