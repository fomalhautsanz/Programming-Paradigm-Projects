package Saver;

public class SavingsAccount extends BankAccount{
    static double annualInterestRate;

    SavingsAccount(){
        super();
        annualInterestRate=0;
    }

    public double calculateMonthlyInterest(double interestRate){
        double interest = getBalance()*(interestRate/100)/12 ;
        return getBalance() + interest;
    }

    public static void modifyInterestRate(double newInterestRate){
        annualInterestRate=newInterestRate;
    }
}
