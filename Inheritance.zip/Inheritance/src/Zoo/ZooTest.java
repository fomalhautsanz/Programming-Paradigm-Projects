package Zoo;

public class ZooTest {
    public static void main (String[] args){

        Zoo myZoo = new Zoo();
        Elephant elephant = new Elephant("Magi", 10, 50);
        myZoo.addAnimal(elephant);

        Lion lion = new Lion("Leon",8, 34);
        myZoo.addAnimal(lion);

        elephant.displayInfo();
        lion.displayInfo();

        myZoo.makeAllAnimalsSound();
    }
}
