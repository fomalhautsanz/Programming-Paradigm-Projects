package Zoo;

public class Elephant extends Animal{
    double trunkLength;

    Elephant(String name, int age, double trunkLength){
        super(name, age);
        this.trunkLength=trunkLength;
    }

    @Override
    public void makeSound() {
        System.out.println("Trmpp!");
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Trunk Length: " + trunkLength);
    }
}
