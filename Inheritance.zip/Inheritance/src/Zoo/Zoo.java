package Zoo;

public class Zoo {
    static int count=0;
    Animal[] animals = new Animal[100];

    public void addAnimal(Animal a){
        if (count<animals.length){
            animals [count]=a;
            count++;
        }
    }

    public void makeAllAnimalsSound(){
        System.out.println();
        for (int i=0; i<animals.length; i++){
            if (animals[i]!=null){
                System.out.print(animals[i].getName() + ": ");
                animals[i].makeSound();
            }
        }
    }
}
