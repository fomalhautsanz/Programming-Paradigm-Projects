package Zoo;

public class Lion extends Animal{
    double maneSize;

    Lion(String name, int age, double maneSize){
        super(name,age);
        this.maneSize=maneSize;
    }

    public void makeSound() {
        System.out.println("Roar!");
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Mane Size: " + maneSize);
    }
}
