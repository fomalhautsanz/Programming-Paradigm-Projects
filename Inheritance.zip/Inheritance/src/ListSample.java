public class ListSample {
    String name;
    String position;
    String age;

    ListSample(String name, String position,String age){
        this.name=name;
        this.position=position;
        this.age=age;
    }
}
