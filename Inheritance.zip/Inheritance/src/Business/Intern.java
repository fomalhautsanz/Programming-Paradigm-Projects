package Business;

public class Intern extends Employee{

    double taxDeduction;

    Intern(String name,String id,double stipend,double taxDeduction){
        super(name,id,stipend);
        this.taxDeduction=taxDeduction;
    }

    @Override
    public void calculateSalary() {
        try {
            double deduct =getSalary() * taxDeduction / 100;
            if (getSalary()<0){
                throw new Exception("Salary is in a negative value");
            }
            setSalary(getSalary()-deduct);
            System.out.println("Stipend for " + getName() + ": " + getSalary());
        } catch (Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Override
    public void displayInfo() {
        System.out.println("FULL TIME EMPLOYEE");
        super.displayInfo();
        System.out.println("Tax Deduction: " + taxDeduction + "%");
    }
}
