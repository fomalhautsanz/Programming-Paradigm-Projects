package Business;

public class Payroll {
    public static void main (String[] args){

        FullTimeEmployee employee1 = new FullTimeEmployee("Larry Crab","KT509",34000);
        PartTimeEmployee employee2 = new PartTimeEmployee("Bob Fish","PL900",1200,48);
        Intern employee3 = new Intern("Eugene Cook","HN365",25000,5);

        employee1.displayInfo();
        employee1.calculateSalary();
        System.out.println();

        employee2.displayInfo();
        employee2.calculateSalary();
        System.out.println();

        employee3.displayInfo();
        employee3.calculateSalary();
        System.out.println();
    }
}
