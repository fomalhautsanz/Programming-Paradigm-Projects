package Business;

public class PartTimeEmployee extends Employee{
    double hourlyWage;
    double workedHours;

    PartTimeEmployee(String name,String id,double hourlyWage, double workedHours){
        super(name, id);
        this.hourlyWage=hourlyWage;
        this.workedHours=workedHours;
    }

    public void calculateSalary() {
        setSalary(hourlyWage*workedHours);
        System.out.println("Salary for " + getName() + ": " + getSalary());
    }

    @Override
    public void displayInfo() {
        System.out.println("PART TIME EMPLOYEE");
        super.displayInfo();
        System.out.println("Hourly Wage: " + hourlyWage);
        System.out.println("Worked Hours: " + workedHours);
    }
}
