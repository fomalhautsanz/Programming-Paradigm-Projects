package Business;

public class FullTimeEmployee extends Employee{

    FullTimeEmployee(String name,String id,double salary){
        super(name, id, salary);
    }

    @Override
    public void calculateSalary() {
        try {
            if (getSalary()<0){
                throw new Exception("Salary is in a negative value");
            }
            System.out.println("Salary for " + getName() + ": " + getSalary());
        } catch (Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Override
    public void displayInfo() {
        System.out.println("FULL TIME EMPLOYEE");
        super.displayInfo();
    }
}
