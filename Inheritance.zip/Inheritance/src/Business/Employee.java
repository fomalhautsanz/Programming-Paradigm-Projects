package Business;

public class Employee {
    private String name;
    private String id;
    private double salary;

    Employee(String name,String id){
        this.name=name;
        this.id=id;
    }

    Employee(String name,String id,double salary){
        this.name=name;
        this.id=id;
        this.salary=salary;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void calculateSalary(){

    }

    public void displayInfo(){
        System.out.println("Name: " + getName());
        System.out.println("ID: " + getId());
    }
}
