import java.util.ArrayList;

public class List {
    public static void main (String[] args){

        ArrayList <ListSample> employee = new ArrayList<ListSample>();
        employee.add(new ListSample("Robert","Manager","34"));
        employee.add(new ListSample("Rhea","Help Desk","25"));
        employee.add(new ListSample("Sandra","Supervisor","38"));

        for (int i=0; i< employee.size(); i++){
            System.out.println(employee.get(i).name);
        }
    }
}
