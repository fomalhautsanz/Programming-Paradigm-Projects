package Reserve;
import java.time.LocalDate;


public abstract class Reservation {
    private String reservationID;
    private String customerName;
    private LocalDate date;

    Reservation(String reservationID,String customerName,LocalDate date){
        this.reservationID=reservationID;
        this.customerName=customerName;
        this.date=date;
    }

    public void checkReservationStatus(){
        System.out.println("Reservation ID: " + getReservationID());
        System.out.println("Customer Name: " + getCustomerName());
        System.out.println("Date: " + getDate());
        System.out.println("Status: Confirmed");

    }

    public String getReservationID() {
        return reservationID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public abstract void modifyReservation(String newCustomerName, LocalDate newDate, int newRoomNumber);
}
