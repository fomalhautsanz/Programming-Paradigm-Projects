package Reserve;

import java.time.LocalDate;

public class ReservationTest {
    public static void main (String[] args){

        ResortReservation resortReservation = new ResortReservation("120008A","Loki Hemes", LocalDate.of(2025,2,13),12);
        resortReservation.checkReservationStatus();
        resortReservation.modifyReservation("Athena Wales",LocalDate.of(2025,2,16),14);
    }

}
