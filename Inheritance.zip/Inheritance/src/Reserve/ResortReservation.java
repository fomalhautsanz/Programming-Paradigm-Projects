package Reserve;

import java.time.LocalDate;

public class ResortReservation extends Reservation{
    private int roomNumber;

    ResortReservation(String reservationID, String customerName, LocalDate date, int roomNumber){
        super(reservationID, customerName, date);
        this.roomNumber=roomNumber;
    }

    @Override
    public void checkReservationStatus() {
        super.checkReservationStatus();
        System.out.println("Room Number: " + roomNumber);
        System.out.println();
    }

    @Override
    public void modifyReservation(String newCustomerName, LocalDate newDate, int newRoomNumber) {
        setCustomerName(newCustomerName);
        setDate(newDate);
        roomNumber=newRoomNumber;
        checkReservationStatus();
        System.out.println("Reservation updated successfully!");
    }
}
