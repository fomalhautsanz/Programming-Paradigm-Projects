package Reserve;

import java.time.LocalDate;

public class RailwayReservation extends Reservation{
    private int seatNumber;

    RailwayReservation(String reservationID, String customerName, LocalDate date, int seatNumber){
        super(reservationID, customerName, date);
        this.seatNumber=seatNumber;
    }

    @Override
    public void checkReservationStatus() {
        super.checkReservationStatus();
        System.out.println("Seat number: " + seatNumber);
    }

    @Override
    public void modifyReservation(String newCustomerName, LocalDate newDate, int newSeatNumber) {
        setCustomerName(newCustomerName);
        setDate(newDate);
        seatNumber=newSeatNumber;
    }
}
