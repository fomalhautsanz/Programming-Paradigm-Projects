package Movie;

import java.util.ArrayList;
import java.util.List;

public class Movie {
    private String title;
    private String director;
    private ArrayList<String> actors;
    private ArrayList<Review> reviews;

    Movie(String title,String director,ArrayList<String> actors){
        this.title=title;
        this.director=director;
        this.actors=actors;

    }

    public String getTitle() {
        return title;
    }

    public String getDirector() {
        return director;
    }

    public ArrayList<String> getActors() {
        return actors;
    }

    public void addReview(Review review){
        reviews.add(review);
    }

    public ArrayList<Review> getReviews() {
        return this.reviews;
    }
}
