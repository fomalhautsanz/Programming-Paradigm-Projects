package Movie;

import java.util.ArrayList;
import java.util.Arrays;

public class MovieTester {
    public static void main (String[] args){
        Movie movie1 = new Movie("Shark Tale","Linda Goodman",
                new ArrayList(Arrays.asList("Richard Bate","Fiona Terry")));

        Review review1 = new Review("It was fun to see","Harris Style",4.3);
        Review review2 = new Review("I expected a lot","Mara Brown",3.9);
        Review review3 = new Review("My kids loved it","Leah Jennings",4.5);

        movie1.addReview(review1);
        movie1.addReview(review2);
        movie1.addReview(review3);

        System.out.println("================== FEATURING NEW MOVIE ==================");
        System.out.println("TITLE: " + movie1.getTitle());
        System.out.println("DIRECTOR: " + movie1.getDirector());
        System.out.println("ACTORS: " + movie1.getActors());
        System.out.println();
        System.out.println("======================= REVIEWS =========================");
        for (Review review : movie1.getReviews()){
            System.out.println(review.getReviewText() + " by " + review.getReviewerName() + " : " + review.getRating());
        }
    }
}
