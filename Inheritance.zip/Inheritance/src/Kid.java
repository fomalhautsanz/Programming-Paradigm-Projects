public class Kid extends Toddler{
    int gradeLevel;

    Kid(String name, String sex, int age, String recentVaccine, int gradeLevel){
        super(name, sex, age, recentVaccine);
        this.gradeLevel = gradeLevel;
    }

    void setGradeLevel(int gradeLevel){
        this.gradeLevel=gradeLevel;
    }

    int getGradeLevel(){
        return gradeLevel;
    }

    @Override
    void displayInfo() {
        super.displayInfo();
        System.out.println("Grade Level: " + gradeLevel);
    }
}
