import java.util.Scanner;

public class MarketTest {
    static Pork pork1 = new Pork("Young Pork",200,"Nanet's Pig Farm");
    static Pork pork2 = new Pork("Mature Pork",300,"Waldo's Piggery");
    static Chicken chicken1 = new Chicken("Cull",150,"Mabini Poultry Farm");
    static Chicken chicken2 = new Chicken("Native Chicken",100,"Eddie's Sabungan");
    static Scanner input = new Scanner(System.in);
    public static void main(String[] args){
        menu();
    }

    static void menu(){
        while (true) {
            System.out.println("THE FOLLOWING ARE CURRENTLY LISTED IN YOUR SHOP: ");
            System.out.println("1. Pork");
            System.out.println("2. Chicken");
            System.out.println("3. Back");
            System.out.print("> ");
            int choice = input.nextInt();
            input.nextLine();
            if (choice==1){
                pork();
            } else if (choice==2) {
                chicken();
            }
            else {
                return;
            }
        }
    }

    static void pork(){
        System.out.print("1. ");pork1.displayInfo();
        System.out.print("2. ");pork2.displayInfo();
        System.out.println("3. Back");
        int choice = input.nextInt();
        if (choice==1){
            pork1.increaseDecrease();
        } else if (choice==2) {
            pork2.increaseDecrease();
        } else if (choice==3) {
            System.out.println("Returning...");
        }
    }

    static void chicken(){
        System.out.print("1. ");chicken1.displayInfo();
        System.out.print("2. ");chicken2.displayInfo();
        System.out.println("3. Back");
        int choice = input.nextInt();
        if (choice==1){
            chicken1.increaseDecrease();
        } else if (choice==2) {
            chicken2.increaseDecrease();
        } else if (choice==3) {
            System.out.println("Returning...");
        }
    }


}
