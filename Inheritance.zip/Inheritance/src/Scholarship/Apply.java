package Scholarship;

public class Apply {
    private String name;
    private double GPA;
    private int units;

    Apply(){

    }

    Apply(String name,double GPA,int units){
        this.name=name;
        this.GPA=GPA;
        this.units=units;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGPA(double GPA) {
        this.GPA = GPA;
    }

    public void setUnits(int units) {
        this.units = units;
    }

    public String getName() {
        return name;
    }

    public boolean isQualified(){
        return GPA>=87 && units>20;
    }
}
