package Scholarship;

import java.util.Scanner;

public class ICSScholarshipTest {
    static ICSScholarship[] applicants = new ICSScholarship[100];
    static ICSScholarship scholarship = new ICSScholarship();
    static int count;

    public static void main (String[] args){
        Scanner input = new Scanner(System.in);
        initialize();

        while (true) {
            int choice = scholarship.menu();


        if (choice==1){
            if (count<applicants.length){
                System.out.println("=========== APPLY FOR SCHOLARSHIP ==========\n");
                applicants[count]=new ICSScholarship();
                System.out.print("\nEnter your name: ");
                applicants[count].setName(input.nextLine());
                System.out.print("Enter your course: ");
                applicants[count].setCourse(input.nextLine());
                System.out.print("Enter your GPA: ");
                applicants[count].setGPA(input.nextDouble());
                input.nextLine();
                System.out.print("Enter your units: ");
                applicants[count].setUnits(input.nextInt());
                input.nextLine();
                count++;
                System.out.println("Your application has been sent!\n");
            }
        }

        else if (choice==2) {
            System.out.println("========== LIST OF SCHOLARSHIP QUALIFIERS ============");
            for (int i = 0; i < 25; i++) {
                if (applicants[i] != null && applicants[i].isQualified()) {
                    System.out.println(applicants[i].getName());
                }
            }
            System.out.println();
        }

        else if (choice==3){
            System.out.println("Thank you for applying! Now exiting...");
            System.exit(0);
        }
        }
    }

    public static void initialize(){
        applicants[0]=new ICSScholarship("Rhea Manlupig",89,24,"BSEd English");
        applicants[1]=new ICSScholarship("Ramon Juse",93,19,"BS Agriculture");
        count=2;
    }
}
