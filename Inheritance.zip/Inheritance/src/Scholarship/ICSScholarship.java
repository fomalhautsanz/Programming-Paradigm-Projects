package Scholarship;

import java.util.Scanner;

public class ICSScholarship extends Apply{
    Scanner input = new Scanner(System.in);
    private String course;

    ICSScholarship(){

    }

    ICSScholarship(String name, double GPA, int units, String course){
        super(name, GPA, units);
        this.course=course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getCourse() {
        return course;
    }

    public int menu(){
        System.out.println("====== WELCOME TO ICS Scholarship ======");
        System.out.println("1. Apply for Scholarship");
        System.out.println("2. Check for Qualifiers");
        System.out.println("3. Exit");
        System.out.print("> ");
        return input.nextInt();
    }

}
