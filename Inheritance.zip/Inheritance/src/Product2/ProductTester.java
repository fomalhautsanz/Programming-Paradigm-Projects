package Product2;

import Product1.Book;
import Product1.Electronics;
import Product1.Product;

public class ProductTester {
    public static void main (String[] args){

        //THE EXCEPTION HANDLING FOR INITIALIZATION OF OBJECTS IS IN THEIR CONSTRUCTORS
        TV tv = new TV(1900,"Toshiba",24);
        Electronics electronics = new Electronics(3000, "Sharp");
        MP3Player mp3Player = new MP3Player(75,"Apple","Red");
        Book book1 = new Book(130,"Snow White");
        Book book2 = new Book(500,"Pinocchio");

        /* THE EXCEPTION HANDLING FOR SETTERS ARE IN THE FOR LOOP SO
        THAT IT WON'T DISPLAY THE INVALID VALUES AND NOT INCLUDE THEM IN THE SUMMATION */
        //I CHANGED THE VALUES TO CORRECT ONES FOR THE SAKE OF UTILIZING THE SETTERS
        tv.setRegularPrice(1000);
        tv.setManufacturer("Sony");
        tv.setSize(24);

        electronics.setRegularPrice(2000);
        electronics.setManufacturer("Hanabishi");

        mp3Player.setRegularPrice(250);
        mp3Player.setManufacturer("Lenovo");
        mp3Player.setColor("Black");

        book1.setRegularPrice(150);
        book1.setTitle("Harry Potter");

        book2.setRegularPrice(200);
        book2.setTitle("Alice in Wonderland");

        double totalRegularPrice=0;
        double totalSalePrice=0;

        Product[] products = new Product[5];
        products[0] = tv;
        products[1] = electronics;
        products[2] = mp3Player;
        products[3] = book1;
        products[4] = book2;

        //USING FOR LOOP TO DISPLAY THE ATTRIBUTES OF OBJECTS
        for (int i=0; i<products.length; i++){
            System.out.println(products[i].getClass().getSimpleName() + " regular price: " + products[i].getRegularPrice());

            if (products[i] instanceof Book){
                System.out.println("Title: " + ((Book) products[i]).getTitle());
            }
            else if (products[i] instanceof MP3Player){
                System.out.println("Manufacturer: " + ((MP3Player) products[i]).getManufacturer());
                System.out.println("Color: " + ((MP3Player) products[i]).getColor());
            }
            else if (products[i] instanceof  TV){
                System.out.println("Manufacturer: " + ((TV) products[i]).getManufacturer());
                System.out.println("Size: " + ((TV) products[i]).getSize() + " in");
            }
            else  if (products[i] instanceof Electronics){
                System.out.println("Manufacturer: " + ((Electronics) products[i]).getManufacturer());
            }
            System.out.println();
        }

        /*USING FOR LOOP TO DISPLAY THE PRICES. ALSO FOR CALCULATING THE TOTAL
        SALE PRICE AND TOTAL REGULAR PRICE*/
        for (int i=0; i<products.length; i++) {

            try {
                if (products[i].getRegularPrice()<0){
                    throw new IllegalArgumentException("Regular Price for item no. " + i + " must be positive\n");
                }
                if (products[i].computeSalePrice()<0){
                    throw new IllegalArgumentException("Sale Price for item no. " + i + " must be positive\n");
                }
                totalRegularPrice += products[i].getRegularPrice();
                totalSalePrice += products[i].computeSalePrice();

                System.out.println("Item number " + i + ": Type = " + products[i].getClass().getSimpleName() +
                        ", Regular Price = " + products[i].getRegularPrice() + ", Sale price = " + products[i].computeSalePrice());
            } catch (Exception e){
                System.out.println("\nERROR: " + e.getMessage());
            }
        }

        System.out.println("totalRegularPrice = " + totalRegularPrice);
        System.out.println("totalSalePrice = " + totalSalePrice);
    }
}
