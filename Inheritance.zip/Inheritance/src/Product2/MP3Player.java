package Product2;

import Product1.Electronics;

public class MP3Player extends Electronics {

    private String color;
    MP3Player(double regularPrice, String manufacturer,String color){
        super(regularPrice, manufacturer);
        this.color=color;
    }

    @Override
    public double computeSalePrice() {
        return getRegularPrice()*90/100;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
