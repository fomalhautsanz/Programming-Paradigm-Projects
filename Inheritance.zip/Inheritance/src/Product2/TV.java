package Product2;

import Product1.Electronics;

public class TV extends Electronics {

    private double size;

    TV (double regularPrice, String manufacturer, double size){
        super(regularPrice, manufacturer);
        try {
            if (size<0){
                throw new IllegalArgumentException("Initialized TV size must be positive!");
            }
            this.size = size;
        } catch (Exception e){
            System.out.println("ERROR: " + e.getMessage());
        }
    }

    @Override
    public double computeSalePrice() {
        return getRegularPrice()*80/100;
    }

    public void setSize(double size) {
        this.size = size;
    }

    public double getSize() {
        return size;
    }
}
