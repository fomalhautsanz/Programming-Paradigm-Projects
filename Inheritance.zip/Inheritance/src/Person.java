public class Person {
    private  String name, sex;
    private int age;

    Person(String name, String sex, int age){
        this.name = name;
        this.sex = sex;
        this.age = age;
    }

    void setName(String newName){
        name=newName;
    }

    String getName(){
        return name;
    }

    void setSex(String newSex){
        sex=newSex;
    }

    String getSex(){
        return sex;
    }

    void setAge(int newAge){
        age=newAge;
    }

    int getAge(){
        return age;
    }


    void displayInfo(){
        System.out.println("Name: " + name);
        System.out.println("Sex: " + sex);
        System.out.println("Age: " + age);
    }
}
