public class Chicken extends Market{
    String chickenFarm;
    Chicken(String name,int price, String chickenFarm){
        super(name,price);
        this.chickenFarm=chickenFarm;
    }

    @Override
    void displayInfo() {
        super.displayInfo();
        System.out.println("Chicken Farm: " + chickenFarm);
    }
}
