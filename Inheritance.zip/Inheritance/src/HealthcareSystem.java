import java.util.Objects;
import java.util.Scanner;

public class HealthcareSystem {
    public static void main(String[] args){
        LogIn logIn = new LogIn();
        logIn.logInPage();
    }
}
