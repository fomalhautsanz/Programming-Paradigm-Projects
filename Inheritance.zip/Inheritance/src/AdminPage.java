import java.util.Scanner;

public class AdminPage {
    static Toddler[] toddlerList = new Toddler[100];
    static Kid[] kidList = new Kid[100];
    static Scanner input = new Scanner(System.in);
    static int choice;
    static int toddlerCount = 0;
    static int kidCount = 0;
    static int patientNum;
    static String newDiagnosis;

    static void adminMenu(){
        initializeToddlers();
        initializeKids();

        while (true) {
            System.out.println("1. Check Patients List");
            System.out.println("2. Add Patient");
            System.out.println("3. Update Patient Diagnosis");
            System.out.println("4. Remove Patient");
            choice = input.nextInt();

            switch (choice) {
                case 1:
                    displayPatients();
                    break;

                case 2:
                    addPatient();
                    break;

                case 3:
                    updateDiagnosis();
                    break;

                case 4:
                    removePatient();
                    break;

                default:
                    System.out.println("Please enter a valid option");
                    return;
            }
        }
    }

    static void displayPatients(){
        System.out.println("Choose patient type: ");
        System.out.println("1. Toddler");
        System.out.println("2. Kid");
        choice = input.nextInt();

        if (choice==1){
           displayToddlers();
        }
        else if (choice==2){
           displayKids();
        }
    }

    static void displayToddlers(){
        for (int i=0; i<toddlerCount; i++){
            System.out.println();
            if (toddlerList[i]!=null){
                System.out.println((i+1) + ".) ");
                System.out.println("Name: " + toddlerList[i].getName());
                System.out.println("Sex: " + toddlerList[i].getSex());
                System.out.println("Age: " + toddlerList[i].getAge());
                System.out.println("Recent Diagnosis: " + toddlerList[i].getRecentDiagnosis());
                System.out.println();
            }
        }
    }

    static void displayKids(){
        for (int i=0; i<kidCount; i++){
            if (kidList[i]!=null){
                System.out.println();
                System.out.println((i+1) + ".) ");
                System.out.println("Name: " + kidList[i].getName());
                System.out.println("Sex: " + kidList[i].getSex());
                System.out.println("Age: " + kidList[i].getAge());
                System.out.println("Recent Diagnosis: " + kidList[i].getRecentDiagnosis());
                System.out.println("Grade : " + kidList[i].getGradeLevel());
                System.out.println();
            }
        }
    }

    static void addPatient(){
        System.out.println("Choose patient type: ");
        System.out.println("1. Toddler");
        System.out.println("2. Kid");
        choice = input.nextInt();
        input.nextLine();

        if (choice==1){
            if (toddlerCount<toddlerList.length){
                System.out.print("Enter name: " );
                String name = input.nextLine();
                System.out.print("Enter sex: " );
                String sex = input.nextLine();
                System.out.print("Enter age: ");
                int age = input.nextInt();
                input.nextLine();
                System.out.print("Enter recent diagnosis: ");
                String recentDiagnosis = input.nextLine();

                toddlerList[toddlerCount]=new Toddler(name,sex,age, recentDiagnosis);
                input.nextLine();
                toddlerCount++;
            }
        }
        else if (choice==2){
            if (kidCount<kidList.length){
                System.out.print("Enter name: " );
                String name = input.nextLine();
                System.out.print("Enter sex: " );
                String sex = input.nextLine();
                System.out.print("Enter age: ");
                int age = input.nextInt();
                input.nextLine();
                System.out.print("Enter recent diagnosis: ");
                String recentDiagnosis = input.nextLine();
                System.out.print("Enter grade level: ");
                int gradeLevel = input.nextInt();

                kidList[kidCount]=new Kid(name,sex,age, recentDiagnosis,gradeLevel);
                input.nextLine();
                kidCount++;
            }
        }
    }

    static void updateDiagnosis(){
        System.out.println("Choose patient type: ");
        System.out.println("1. Toddler");
        System.out.println("2. Kid");
        choice = input.nextInt();

        if (choice==1){
            displayToddlers();
            System.out.print("Enter patient number: ");
            patientNum = input.nextInt();
            input.nextLine();

            if (patientNum>toddlerCount){
                System.out.println("Invalid input!");
                return;
            }

            for (int i=0; i<toddlerCount; i++){
                if ((i+1)==patientNum){
                    System.out.print("Enter new diagnosis for " + toddlerList[i].getName() + ": ");
                    newDiagnosis=input.nextLine();

                    toddlerList[i].setRecentDiagnosis(newDiagnosis);
                    System.out.println("Diagnosis updated successfully!");
                    break;
                }
            }
        }
        else if (choice==2){
            displayKids();
            System.out.print("Enter patient number: ");
            patientNum = input.nextInt();
            input.nextLine();

            if (patientNum>kidCount){
                System.out.println("Invalid input!");
                return;
            }

            for (int i=0; i<kidCount; i++){
                if ((i+1)==patientNum){
                    System.out.print("Enter new diagnosis for " + kidList[i].getName() + ": ");
                    newDiagnosis=input.nextLine();

                    kidList[i].setRecentDiagnosis(newDiagnosis);
                    System.out.println("Diagnosis updated successfully!");
                    break;
                }
            }
        }
    }

    static void removePatient(){
        System.out.println("Choose patient type: ");
        System.out.println("1. Toddler");
        System.out.println("2. Kid");
        choice = input.nextInt();

        if (choice==1){
            displayToddlers();
            System.out.print("Enter patient number: ");
            patientNum = input.nextInt();

                if (patientNum>toddlerCount){
                    System.out.println("Invalid input!");
                    return;
                }

                for (int i=patientNum-1; i<toddlerCount+1; i++){
                    toddlerList[i]=toddlerList[i+1];
            }

                toddlerList[toddlerCount-1]=null;
                toddlerCount--;
        }
        else if (choice==2){
            displayKids();
            System.out.print("Enter patient number: ");
            patientNum = input.nextInt();

            if (patientNum>kidCount){
                System.out.println("Invalid input!");
                return;
            }

            for (int i=patientNum-1; i<kidCount+1; i++){
                kidList[i]=kidList[i+1];
            }

            kidList[kidCount-1]=null;
            kidCount--;
        }

    }

   static void initializeToddlers(){
        toddlerList[0]=new Toddler("Ana Dias","Female",2,"Pneumonia");
        toddlerCount=1;
    }

    static void initializeKids(){
        kidList[0]=new Kid("Bobby Santos","Male",8,"Dengue",3);
        kidCount=1;
    }
}
