import java.util.Scanner;

public class Market {
    Scanner input=new Scanner(System.in);
    private String productName;
    private double price;

    Market(String productName,int price){
        this.productName=productName;
        this.price=price;
    }

    public double getPrice() {
        return price;
    }

    public String getProductName() {
        return productName;
    }

    void priceIncrease(double rate){
        price=price+(price*rate/100);
    }

    void priceDecrease(double rate){
        price=price-(price*rate/100);
    }

    void increaseDecrease(){
        System.out.println("1. Increase Price ");
        System.out.println("2. Decrease Price");
        System.out.println("3. Back");
        int choice = input.nextInt();
        input.nextLine();
        if (choice==1){
            System.out.print("Enter rate: ");
            double rate = input.nextDouble();
            priceIncrease(rate);
            displayInfo();
        }
        else if (choice==2){
            System.out.print("Enter rate: ");
            double rate = input.nextDouble();
            priceDecrease(rate);
            displayInfo();
        }
        else if (choice==3){
            System.out.println("Returning...");
            return;
        }
    }

    void displayInfo(){
        System.out.println("\nProduct Name: " + getProductName());
        System.out.println("Price: PHP" + getPrice() + " (per kilo)");
    }
}
