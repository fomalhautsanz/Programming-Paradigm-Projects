package Product1;

public class Book extends Product{

    private String title;

    public Book(double regularPrice, String title){
        super(regularPrice);
        this.title=title;
    }

    @Override
    public double computeSalePrice() {
        return getRegularPrice()*50/100;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
