package Product1;

public class Product {
    protected double regularPrice;

    public Product(double regularPrice){
        try {

            if (regularPrice<0){
                throw new IllegalArgumentException("Initialized " + this.getClass().getSimpleName() + "'s regular price must be positive!\n");
            }
            this.regularPrice = regularPrice;
        } catch (Exception e){
            System.out.println("\nERROR: " + e.getMessage());
        }
    }

    public void setRegularPrice(double regularPrice) {
        this.regularPrice = regularPrice;
    }

    public double getRegularPrice() {
        return regularPrice;
    }

    public double computeSalePrice(){

            return regularPrice;
    }

}
