public class Pork extends Market{

    String pigFarm;
    Pork(String name,int price, String pigFarm){
        super(name,price);
        this.pigFarm=pigFarm;
    }

    @Override
    void displayInfo() {
        super.displayInfo();
        System.out.println("Pig Farm: " + pigFarm);
    }
}
