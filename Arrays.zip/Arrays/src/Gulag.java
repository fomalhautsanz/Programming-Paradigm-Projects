import java.util.Scanner;

public class Gulag {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] num = {5, 8, 2, 3, 5, 7, 2};
        System.out.println("Unique numbers: ");
        displayUnique(num);
        System.out.println("\nSum of unique numbers: " + sumUnique(num));
    }

    public static void displayUnique(int[] nums) {
        for (int i = 0; i < nums.length; i++) {
            boolean isUnique = true;
            for (int j = 0; j < nums.length; j++) {
                if (nums[i] == nums[j] && i != j) {
                    isUnique = false;
                    break;
                }
            }
            if (isUnique) {
                System.out.print(nums[i] + " ");
            }
        }
    }

    public static int sumUnique(int[] nums) {
        int sum=0;
        for (int i = 0; i < nums.length; i++) {
            boolean isUnique = true;
            for (int j = 0; j < nums.length; j++) {
                if (nums[i] == nums[j] && i != j) {
                    isUnique = false;
                    break;
                }
            }
            if (isUnique) {
                sum+=nums[i];
            }
        }
        return sum;
    }
}
