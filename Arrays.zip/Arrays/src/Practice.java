import java.util.Objects;
import java.util.Scanner;
public class Practice {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        String name, id, section, email;
        int studentnum=0;
        int max = 0;
        String[][] management = new String[max][5];
        String[] credentials = {"Student Name", "Student ID", "Section","Email"};

        System.out.println("STAFF LOG IN ");
        System.out.print("Enter username: ");
        String username = input.nextLine();
        System.out.print("Enter password: ");
        String password = input.nextLine();

        if (!Objects.equals(username, "Staff1") && !Objects.equals(password, "staff123")){
            System.out.println("INVALID: Wrong username or password.");
             main(args);
        }
        else {
               System.out.println("STUDENT CREDENTIALS");
               System.out.println("[1] ADD A STUDENT");
               System.out.println("[2] DISPLAY STUDENTS");
               System.out.println("[3] DELETE STUDENT");
               System.out.println("[4] EXIT");
               int choice = input.nextInt();

               switch (choice){
                   case 1:
                      for (int i=0; i<max; i++){
                          for (int j=0; j<5; j++){
                              System.out.print(credentials[j]);
                              management[i][j]=input.nextLine();
                          }
                      }

               }



        }

    }
}
