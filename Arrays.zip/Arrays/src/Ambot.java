import java.util.Objects;
import java.util.Scanner;

public class Ambot {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int max = 0;
        int lim = 0;
        String[][] management;
        String[][] temporary;
        String[] credentials = {"Enter Name", "Enter Student ID", "Enter Section", "Enter Email"};
        String[] show = {"No.\t" + "Student Name", "Student ID", "Section", "Email"};
        int cont = 0, counter=0, num=0;
        String deletesearch;

        System.out.println("STAFF LOG IN ");
        System.out.print("Enter username: ");
        String username = input.nextLine();
        System.out.print("Enter password: ");
        String password = input.nextLine();

        if (Objects.equals(username, "Staff1") && Objects.equals(password, "staff123")) {
            System.out.print("Enter max student: ");
            max = input.nextInt();
            management = new String[max][4];
            int anothermax = max;

            do {
                System.out.println();
                System.out.println("STUDENT CREDENTIALS");
                System.out.println("[1] ADD A STUDENT");
                System.out.println("[2] DISPLAY STUDENTS");
                System.out.println("[3] DELETE STUDENT");
                System.out.println("[4] EXIT");
                int choice = input.nextInt();
                input.nextLine();

                switch(choice){
                    case 1:
                        do{
                            if (lim<max){
                                for (int i=0; i<max; i++){
                                    for (int j=0; j<4; j++){
                                        System.out.print(credentials[j] + ": ");
                                        management[i][j] = input.nextLine();
                                    }
                                    lim++;
                                    System.out.println("Student inserted successfully. ");
                                    System.out.println("Do you want to continue? [1] Yes/[2] No ");
                                    cont=input.nextInt();
                                    input.nextLine();
                                    if (cont==2){
                                        break;
                                    }
                                }
                            }
                            else{
                                System.out.println("INVALID: Student limit reached (" + max + " students) only");
                                break;
                            }
                        } while (cont!=2);
                        break;

                    case 2:
                        for (int i=0; i<4; i++){
                            System.out.print(show[i] + "\t");
                        }
                        System.out.println();
                        for (int i=0; i<max; i++){
                            System.out.print((i+1) + "\t");
                            for (int j=0; j<4; j++){
                                System.out.print(management[i][j] + "\t\t");
                            }
                            System.out.println();
                        }
                        break;

                    case 3:
                        System.out.print("Enter name to search: ");
                        deletesearch = input.nextLine();
                        temporary = new String[max-1][4];

                        for (int i=0; i<max; i++){
                            for (int j=0; j<4; j++){
                                if (Objects.equals(management[i][0], deletesearch)) {
                                    num = i;
                                }
                            }
                        }

                        for (int i=0; i<max; i++){
                            if (i==num){
                                for (int j=i; j<max-1; j++){
                                    management[j] = management[j+1];
                                }
                                max--;
                            }
                        }
                        System.out.println("Student deleted successfully!");
                        break;

                    case 4:
                        System.exit(0);
                        break;
                }
            } while (true);
        }

        else {
            System.out.println("Invalid password. Please try again.");
            main(args);
        }

    }
}
