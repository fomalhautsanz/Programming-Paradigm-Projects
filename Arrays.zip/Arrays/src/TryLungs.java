public class TryLungs {
    public static void main(String[] args) {
        int[] numbers = {3, 5, 2, 8, 5, 2, 7, 8};
        System.out.println("Original Array:");
        displayArray(numbers);

        System.out.println("\nSum of Unique Numbers: " + sumUniqueNumbers(numbers));

        System.out.println("\nReversed Array:");
        reverseArray(numbers);
        displayArray(numbers);

        System.out.println("\nElements greater than average:");
        displayAboveAverage(numbers);
    }
    public static void displayArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }
    public static int sumUniqueNumbers(int[] arr) {
        int sum = 0;

        for (int i = 0; i < arr.length; i++) {
            boolean isUnique = true;
            for (int j = 0; j < arr.length; j++) {
                if (arr[i] == arr[j] && i != j) {
                    isUnique = false;
                    break;
                }
            }
            if (isUnique) {
                sum += arr[i];
            }
        }
        return sum;
    }


    public static void reverseArray(int[] arr) {
        int start = 0, end = arr.length - 1;
        while (start < end) {
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;

            start++;
            end--;
        }
    }


    public static void displayAboveAverage(int[] arr) {
        double sum = 0;
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
        }
        double average = sum / arr.length;
        System.out.println("Average: " + average);

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > average) {
                System.out.print(arr[i] + " ");
            }
        }
        System.out.println();
    }
}
