import java.util.Objects;
import java.util.Scanner;

public class Day4 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        String[][] seats = new String[3][3];
        int choice;
        for (int i=0; i<3; i++){
            for (int j=0; j<3; j++){
                seats[i][j]="Empty";
            }
        }

        do {
            System.out.println("Seating Arrangement Tracker: ");
            System.out.println("1. Display Seating Arrangement");
            System.out.println("2. Add Student");
            System.out.println("3. Remove Student");
            System.out.println("4. Find Student");
            System.out.println("5. Count Empty Seats");
            System.out.println("6. Exit");
            choice = input.nextInt();

            switch (choice){
                case 1:
                    displayseats(seats);
                    break;
                case 2:
                    addstudent(seats,input);
                    break;
                case 3:
                    removestudent(seats,input);
                    break;
                case 4:
                    findstudent(seats,input);
                    break;
                case 5:
                    countempty(seats);
                    break;
                case 6:
                    System.exit(0);
                default:
            }
        } while (true);
    }

    public static void displayseats(String[][] seats){
        System.out.println("Current seating arrangement: ");

        for (int i=0; i<3; i++){
            for (int j=0; j<3; j++){
                System.out.print(seats[i][j] + "\t");
            }
            System.out.println();
        }
    }

    public static void addstudent (String[][] seats, Scanner input){
        System.out.print("Enter row: ");
        int row = input.nextInt();
        System.out.print("Enter column: ");
        int column = input.nextInt();
        input.nextLine();
        System.out.print("Enter student name: ");
        String name = input.nextLine();

        if (Objects.equals(seats[row][column], "Empty")){
            seats[row][column]=name;
            System.out.println("Student added successfully. ");
        }
        else{
            System.out.println("This seat is already occupied.");
        }
    }

    public static void removestudent(String[][] seats, Scanner input){
        System.out.print("Enter row: ");
        int row = input.nextInt();
        System.out.print("Enter column: ");
        int column = input.nextInt();
        input.nextLine();

        seats[row][column] = "Empty";
        System.out.println("Student removed successfully.");
    }

    public static void findstudent(String[][] seats, Scanner input){
       input.nextLine();
        System.out.print("Enter student name: ");
        String name = input.nextLine();
        int row=0;
        int column=0;
        for (int i=0; i<3; i++){
            for (int j=0; j<3; j++){
                if (Objects.equals(seats[i][j], name)){
                    row=i;
                    column=j;
                }
            }
        }
        System.out.println("Student found at row " + row + ",column " + column);
    }

    public static void countempty(String[][] seats){
        int count=0;
        for (int i=0; i<3; i++){
            for (int j=0; j<3; j++){
                if (Objects.equals(seats[i][j], "Empty")){
                    count++;
                }
            }
        }
        System.out.println("Number of empty seats: " + count);
    }

}
