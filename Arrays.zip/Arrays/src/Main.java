//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.time.LocalDateTime;
import java.time.Duration;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[][] customer = new String[60][8];
        /*
        [1][0] Slot number
        [1][1] Customer Name
        [1][2] Contact Num
        [1][3] Plate Num
        [1][4] Entry time
        [1][5] Exit Time
        [1][6] Duration
        [1][7] Total payment
        */
        int[] currentlyParking = {0};
        while (true) {
            int selectedOption = staffMenu(sc);
            chosenStaffMenuOption(selectedOption, sc, currentlyParking, customer);
        }
    }
    public static int staffMenu (Scanner sc){
        int choice;
        System.out.println("\n-----STAFF DASHBOARD-----");
        System.out.println("1. View Parking Space Availability");
        System.out.println("2. Allocate Parking Space");
        System.out.println("3. Release Parking Space");
        System.out.println("4. Logout");
        System.out.print("Enter choice: ");
        choice = sc.nextInt();
        return choice;
    }
    //Start of Main Menu
    public static void chosenStaffMenuOption (int selectedOption, Scanner sc, int[] currentlyParking, String[][] customer){
        //View Parking Space Availability
        if (selectedOption == 1){
            int occupied = 0;
            int available;
            if (currentlyParking[0] == 0){
                System.out.println("No customer is currently parking. Returning to main menu...");
            } else {
                displayParkingSpaceAvailability(customer);
                for (int a = 0; a < 60; a++){
                    if (customer[a][1] != null){
                    occupied++;
                    }
                }
                available = 60 - occupied;
                System.out.println("Total Spaces: 60");
                System.out.println("Occupied: " + occupied);
                System.out.println("Available: " + available);
            }
        }
        //Allocate Parking Space
        else if (selectedOption == 2) {
            if (currentlyParking[0] >= 60){
                System.out.println("No parking space available. Returning to main menu...");
            }
            //Check if slot chosen is empty
            int slotAllocate;
            System.out.println("\n-----Allocate Parking Space-----");
            System.out.print("Enter customer name: ");
            String customerName = sc.next();
            String contactNum = contactNumFormat(sc);
            System.out.print("Enter plate number: ");
            String plateNum = sc.next();
            do {
                System.out.print("Enter slot number to allocate: ");
                slotAllocate = sc.nextInt();
                if (slotAllocate < 1 || slotAllocate > 60){
                    System.out.println("Slot is out of bounds. Please choose from 1 - 60.\n");
                } else if ( customer[slotAllocate - 1][0] != null) {
                    System.out.println("Slot is not available.\n");
                }
            } while (slotAllocate < 1 || slotAllocate > 60 || customer[slotAllocate - 1][0] != null);
            slotAllocate -= 1;
            customer[slotAllocate][0] = String.valueOf(slotAllocate+1);
            customer[slotAllocate][1] = customerName;
            customer[slotAllocate][2] = contactNum;
            customer[slotAllocate][3] = plateNum;
            customer[slotAllocate][4] = timeStamp();
            currentlyParking[0]++;
            System.out.printf("\nParking slot was allocated successfully to %s in space %s\n", customer[slotAllocate][1], customer[slotAllocate][0]);
        }
        //Release Parking Space
        else if (selectedOption == 3) {
            if (currentlyParking[0] == 0){
                System.out.println("No customer is currently parking. Returning to main menu...");
                return;
            }
            displayParkingCustomers(customer);
            int slotToRelease;
            do {
                System.out.print("\nEnter slot number to release: ");
                slotToRelease = sc.nextInt();
                if (slotToRelease < 1 || slotToRelease > 60){
                    System.out.println("Invalid slot number. try again.");
                } else if (customer[slotToRelease - 1][0] == null){
                    System.out.println("Slot " + slotToRelease + "  is already empty.");
                } else {
                    break;
                }
            } while (true);
            timeCal(customer, slotToRelease);
            if (confirmRelease(sc)){
                customer[slotToRelease-1][0] = null;
                customer[slotToRelease-1][1] = null;
                customer[slotToRelease-1][2] = null;
                customer[slotToRelease-1][3] = null;
                customer[slotToRelease-1][4] = null;
                customer[slotToRelease-1][5] = null;
                currentlyParking[0]--;
                System.out.println("Slot has been released successfully. Returning to menu...");
            } else {
                System.out.println("Releasing of spot has been cancelled. Returning to menu...");
            }
        }
        //Logout
        else if (selectedOption == 4) {
            if (confirmExit(sc)){
                System.out.println("Logging out... The program is now terminating...");
                System.exit(0);
            } else {
                System.out.println("Logout Cancelled. Returning to menu...");
            }

        }
        //Invalid Input
        else {
            System.out.println("\nInvalid input. Try again.");
        }
    }
    //End of Main Menu
    public static void displayParkingSpaceAvailability(String[][] customer){
        System.out.println("\n-----Parking Space Availability-----");
        System.out.printf("%-5s %-20s %-20s %-20s %-20s\n", "No.", "Customer Name", "Contact Number", "Plate Number", "Entry Time");
        for (int a = 0; a<60; a++){
            if (customer[a][0] != null){
                System.out.printf("%-5s %-20s %-20s %-20s %-20s\n", customer[a][0], customer[a][1], customer[a][2], customer[a][3], customer[a][4]);
            } else {
                System.out.printf("%-5s %-20s\n", a+1, "Available");
            }
        }
    }
    public static void displayParkingCustomers (String[][] customer){
        System.out.println("\n-----Parking Customers-----");
        System.out.printf("%-5s %-20s %-20s %-20s %-20s\n", "No.", "Customer Name", "Contact Number", "Plate Number", "Entry Time");
        for (int a = 0; a<60; a++){
            if (customer[a][0] != null){
                System.out.printf("%-5s %-20s %-20s %-20s %-20s\n", customer[a][0], customer[a][1], customer[a][2], customer[a][3], customer[a][4]);
            }
        }
    }
    public static boolean confirmRelease (Scanner sc){
        System.out.println("Are you sure you want to release spot? [1]yes [2]no");
        System.out.print("Enter choice: ");
        int choice = sc.nextInt();
        while (choice < 1 || choice > 2){
            System.out.println("Invalid input. Try again.");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
        }
        return choice == 1;
    }
    public static String timeStamp (){
        // Get the current date and time
        LocalDateTime now = LocalDateTime.now();
        // Define the format
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        // Format the current date and time
        return now.format(formatter);
    }
    public static void timeCal(String[][] customer, int slotToRelease) {
        String slotRelease = String.valueOf(slotToRelease);
        String entryTimeStr;
        String exitTimeStr;
        Duration totalTime;
        for (int a = 0; a < 60; a++) {
            if (slotRelease.equals(customer[a][0])) {
                entryTimeStr = customer[a][4];
                exitTimeStr = timeStamp();

                DateTimeFormatter dbFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

                // Parse entry time using dbFormatter
                LocalDateTime entryTime = LocalDateTime.parse(entryTimeStr, dbFormatter);

                // Parse exit time using dbFormatter to ensure consistency
                LocalDateTime exitTime = LocalDateTime.parse(exitTimeStr, dbFormatter);

                // Calculate the duration between entry and exit times
                totalTime = Duration.between(entryTime, exitTime);

                // Calculate the total time in hours, minutes, and seconds
                long hours = totalTime.toHours();
                long minutes = totalTime.toMinutes() % 60;
                long seconds = totalTime.getSeconds() % 60;

                // Format the entry and exit times for output
                String entryTimeOutput = entryTime.format(timeFormatter);
                String exitTimeOutput = exitTime.format(timeFormatter);

                // Print the customer details
                System.out.println("Customer Details:");
                System.out.println("Customer: " + customer[a][1]);
                System.out.println("Plate number: " + customer[a][3]);
                System.out.println("Contact number: " + customer[a][2]);
                System.out.println("Entry Time: " + entryTimeOutput);
                System.out.println("Exit Time: " + exitTimeOutput);
                System.out.println("Total time parked: " + hours + " hours " + minutes + " minutes " + seconds + " seconds.");

                // Store total time in the customer array
                customer[a][5] = exitTime.format(dbFormatter); // Store in database format
                customer[a][6] = String.format("%02d:%02d:%02d", hours, minutes, seconds); // Store total duration

                // Call the payment calculation method
                calPayment(totalTime);
            }
        }
    }

    public static void calPayment(Duration totalTime){
        long totalPayment = 0;
        long additionalHours;
        long hours = totalTime.toHours();
        long minutes = totalTime.toMinutes() % 60;
        if (hours <= 3){
            totalPayment = 20;
        } else {
            totalPayment = 20;
            additionalHours = hours - 3;
            //if more than 5 min considered siya as 1 hour
            if (minutes > 5) {
                additionalHours++;
            }
            totalPayment += additionalHours * 10;
        }
        System.out.println("Total Payment: ₱" + totalPayment);
        System.out.println();
    }
    public static String contactNumFormat (Scanner sc){
        String contactNum;
        while (true) {
            System.out.print("Enter contact number (11 digits): ");
            contactNum = sc.next();
            // Pang check if contactNum has exactly 11 digits tapos walay letters
            if (contactNum.matches("\\d{11}")) {
                return contactNum.substring(0, 4) + "-" + contactNum.substring(4, 7) + "-" + contactNum.substring(7);
            } else {
                System.out.println("Invalid contact number. Please try again.\n");
            }
        }
    }
    public static boolean confirmExit (Scanner sc){
        System.out.println("\nAre you sure you want to exit?\t[1] Yes\t[2] No");
        System.out.print("Enter choice: ");
        int choice = sc.nextInt();
        while (choice != 1 && choice != 2) {
            System.out.println("Invalid Input. Try Again.");
            System.out.print("Enter Choice: ");
            choice = sc.nextInt();
        }
        return choice == 1;
    }
}