import java.util.Scanner;

public class ParaSaQuiz {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[][] seatingArrangement = new String[3][3];

        // Initialize all seats to "Empty"
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                seatingArrangement[i][j] = "Empty";
            }
        }

        int choice;
        do {
            System.out.println("Seating Arrangement Tracker:");
            System.out.println("1. Display Seating Arrangement");
            System.out.println("2. Add Student");
            System.out.println("3. Remove Student");
            System.out.println("4. Find Student");
            System.out.println("5. Count Empty Seats");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    displaySeatingArrangement(seatingArrangement);
                    break;
                case 2:
                    addStudent(seatingArrangement, scanner);
                    break;
                case 3:
                    removeStudent(seatingArrangement, scanner);
                    break;
                case 4:
                    findStudent(seatingArrangement, scanner);
                    break;
                case 5:
                    countEmptySeats(seatingArrangement);
                    break;
                case 6:
                    System.out.println("Exiting program...");
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 6);

        scanner.close();
    }

    // Method to display the seating arrangement
    private static void displaySeatingArrangement(String[][] seatingArrangement) {
        System.out.println("Current Seating Arrangement:");
        for (String[] row : seatingArrangement) {
            for (String seat : row) {
                System.out.print(seat + "\t");
            }
            System.out.println();
        }
    }

    // Method to add a student
    private static void addStudent(String[][] seatingArrangement, Scanner scanner) {
        System.out.print("Enter row (0-2): ");
        int row = scanner.nextInt();
        System.out.print("Enter column (0-2): ");
        int col = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter student name: ");
        String name = scanner.nextLine();

        if (seatingArrangement[row][col].equals("Empty")) {
            seatingArrangement[row][col] = name;
            System.out.println("Student added successfully.");
        } else {
            System.out.println("Seat is already occupied!");
        }
    }

    // Method to remove a student
    private static void removeStudent(String[][] seatingArrangement, Scanner scanner) {
        System.out.print("Enter row (0-2): ");
        int row = scanner.nextInt();
        System.out.print("Enter column (0-2): ");
        int col = scanner.nextInt();

        if (!seatingArrangement[row][col].equals("Empty")) {
            seatingArrangement[row][col] = "Empty";
            System.out.println("Student removed successfully.");
        } else {
            System.out.println("Seat is already empty!");
        }
    }

    // Method to find a student
    private static void findStudent(String[][] seatingArrangement, Scanner scanner) {
        System.out.print("Enter student name: ");
        scanner.nextLine(); // Consume newline
        String name = scanner.nextLine();

        for (int i = 0; i < seatingArrangement.length; i++) {
            for (int j = 0; j < seatingArrangement[i].length; j++) {
                if (seatingArrangement[i][j].equals(name)) {
                    System.out.println("Student found at row " + i + ", column " + j + ".");
                    return;
                }
            }
        }
        System.out.println("Student not found.");
    }

    // Method to count empty seats
    private static void countEmptySeats(String[][] seatingArrangement) {
        int emptyCount = 0;
        for (String[] row : seatingArrangement) {
            for (String seat : row) {
                if (seat.equals("Empty")) {
                    emptyCount++;
                }
            }
        }
        System.out.println("Number of empty seats: " + emptyCount);
    }
}
