import java.util.Objects;
import java.util.Scanner;

public class StudentManagementSyste {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int max;
        int lim = 0;
        String[][] management;
        String[] credentials = {"Enter Name", "Enter Student ID", "Enter Section", "Enter Email"};
        String[] show = {"No.\t" + "Name", "Student ID", "Section", "Email"};
        int cont = 0, num=0;
        String deletesearch;

        System.out.println("STAFF");
        System.out.println("[1] LOG IN");
        System.out.println("[2] EXIT");
        int log = input.nextInt();
        input.nextLine();
        if(log == 1) {
            System.out.println("STAFF LOG IN ");
            System.out.print("Enter username: ");
            String username = input.nextLine();
            System.out.print("Enter password: ");
            String password = input.nextLine();

            if (Objects.equals(username, "Staff1") && Objects.equals(password, "staff123")) {
                System.out.print("Enter max student: ");
                max = input.nextInt();
                management = new String[max][4];

                do {
                    System.out.println();
                    System.out.println("STUDENT CREDENTIALS");
                    System.out.println("[1] ADD A STUDENT");
                    System.out.println("[2] DISPLAY STUDENTS");
                    System.out.println("[3] DELETE STUDENT");
                    System.out.println("[4] EXIT");
                    int choice = input.nextInt();
                    input.nextLine();

                    switch (choice) {
                        case 1:
                            do {
                                if (lim < max) {
                                    for (int i = 0; i < max; i++) {
                                        for (int j = 0; j < 4; j++) {
                                            System.out.print(credentials[j] + ": ");
                                            management[i][j] = input.nextLine();
                                        }
                                        lim++;
                                        System.out.println("Student inserted successfully. ");
                                        System.out.println("Do you want to continue? [1] Yes/[2] No ");
                                        cont = input.nextInt();
                                        input.nextLine();
                                        if (cont == 2) {
                                            break;
                                        }
                                    }
                                } else {
                                    System.out.println("INVALID: Student limit reached (" + max + " students) only");
                                    break;
                                }
                            } while (cont != 2);
                            break;

                        case 2:
                            for (int i = 0; i < 4; i++) {
                                System.out.printf("%-15s", show[i]);
                            }
                            System.out.println();
                            for (int i = 0; i < max; i++) {
                                System.out.printf((i + 1) + "\t");
                                for (int j = 0; j < 4; j++) {
                                    System.out.printf("%-15s", management[i][j]);
                                }
                                System.out.println();
                            }
                            break;

                        case 3:
                            System.out.print("Enter name to search: ");
                            deletesearch = input.nextLine();

                            for (int i = 0; i < max; i++) {
                                for (int j = 0; j < 4; j++) {
                                    if (Objects.equals(management[i][0], deletesearch)) {
                                        num = i;
                                        break;
                                    }
                                }
                            }

                            for (int i = 0; i < max; i++) {
                                if (i == num) {
                                    for (int j = i; j < max - 1; j++) {
                                        management[j] = management[j + 1];
                                    }
                                    max--;
                                }
                            }
                            System.out.println("Student deleted successfully!");
                            break;

                        case 4:
                            System.exit(0);
                            break;
                    }
                } while (true);
            } else {
                System.out.println("Invalid password. Please try again.");
                main(args);
            }
        } else if (log==2) {
            System.exit(0);
        } else {
            System.out.println("Invalid number! Please try again ");
            main(args);
        }

    }
}
