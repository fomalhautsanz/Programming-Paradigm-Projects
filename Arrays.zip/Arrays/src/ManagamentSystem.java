import java.util.Arrays;
import java.util.Objects;
import java.util.Scanner;

public class ManagamentSystem {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int max=0;
        int lim=0;
        String[][] management;
        String[][] temporary;
        String[] credentials = {"Student Name", "Student ID", "Section", "Email"};


            System.out.println("STAFF LOG IN ");
            System.out.print("Enter username: ");
            String username = input.nextLine();
            System.out.print("Enter password: ");
            String password = input.nextLine();


            if (Objects.equals(username, "Staff1") && Objects.equals(password, "staff123")) {
                System.out.print("Enter max student: ");
                max = input.nextInt();
                management = new String[max][4];

      class Menu {
            public static void main(int args){

            }
        }
                System.out.println();
                System.out.println("STUDENT CREDENTIALS");
                System.out.println("[1] ADD A STUDENT");
                System.out.println("[2] DISPLAY STUDENTS");
                System.out.println("[3] DELETE STUDENT");
                System.out.println("[4] EXIT");
                int choice = input.nextInt();
                input.nextLine();
                switch (choice){
                    case 1: {
                        int click = 0;
                        do {
                            if (lim < max) {
                                for (int i = 0; i < max; i++) {
                                    for (int j = 0; j < 4; j++) {
                                        System.out.print(credentials[j] + ": ");
                                        management[i][j] = input.nextLine();
                                    }
                                    System.out.println("Student inserted successfully. ");
                                    System.out.println("Do you want to continue? [1] Yes/[2] No ");
                                    click = input.nextInt();
                                    lim++;
                                    input.nextLine();
                                }
                            } else {
                                System.out.println("INVALID: Student limit reached (" + max + " students) only");
                                main(args);
                            }
                        } while (click!=2);
                        break;
                    }
                    //case 2
                }
            } else {
                System.out.println("Invalid password. Please try again.");
            }

    }
}
