public class Member {
    private String name;
    private String memberID;
    private Book[] borrowedBooks;
    int count=0;

    Member(String name,String memberID){
        this.name=name;
        this.memberID=memberID;
    }

    public String getName() {
        return name;
    }

    public String getMemberID() {
        return memberID;
    }

    public void borrowBook(Book borrow){
        borrowedBooks = new Book[count];
        if (borrow.getAvailableCopies()>0){
            borrowedBooks[count]=borrow;
            count++;
        }
        else {
            System.out.println("This book is not available.");
        }
    }

    public void returnBook(Book returnBook){
       for (int i=0; i<borrowedBooks.length; i++){

       }
    }
}
