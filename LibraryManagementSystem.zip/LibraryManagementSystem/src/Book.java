public class Book {
    private String title;
    private String author;
    private String ISBN;
    private int availableCopies;

    Book(){

    }

    Book(String title,String author,String ISBN,int availableCopies){
        this.title=title;
        this.author=author;
        this.ISBN=ISBN;
        this.availableCopies=availableCopies;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getISBN() {
        return ISBN;
    }

    public int getAvailableCopies() {
        return availableCopies;
    }

    public void borrowBook(){
        availableCopies--;
    }

    public void returnBook(){
        availableCopies++;
    }
}
