package WashingMachine;

public class Main {
    public static void main (String[] args){

        ElectronicsProduct product = new ElectronicsProduct("FM987","SHARP Ultra Washer",12600);
        System.out.println("Product ID: " + product.getProductID());
        System.out.println("Product Name: " + product.getName());
        System.out.println("Price: " + product.getPrice());

        WashingMachine washingMachine = new WashingMachine("FM987","SHARP Ultra Washer",12600,12);
        product.applyDiscount(10);

        System.out.println("Product ID: " + product.getProductID());
        System.out.println("Product Name: " + product.getName());
        System.out.println("Price after discount: " + product.getFinalPrice());
        System.out.println("Warranty Period: " + washingMachine.getWarrantyPeriod());
        washingMachine.extendWarranty(5);
        System.out.println("Warranty period after extension: " + washingMachine.getWarrantyPeriod());
    }
}
