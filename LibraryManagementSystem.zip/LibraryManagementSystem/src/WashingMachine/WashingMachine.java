package WashingMachine;

public class WashingMachine extends ElectronicsProduct{
    private int warrantyPeriod;


    WashingMachine(String productID,String name,double price,int warrantyPeriod){
        super(productID, name, price);
        this.warrantyPeriod=warrantyPeriod;
    }

    public void extendWarranty(int additionalMonths){
        warrantyPeriod+=additionalMonths;
    }

    public int getWarrantyPeriod() {
        return warrantyPeriod;
    }

    @Override
    public void applyDiscount(double discountRate) {
        super.applyDiscount(discountRate);
        System.out.println("Discount applied to " + getName());
    }
}
