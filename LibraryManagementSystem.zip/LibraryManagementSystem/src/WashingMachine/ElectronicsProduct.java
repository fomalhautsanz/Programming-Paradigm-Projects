package WashingMachine;

public class ElectronicsProduct {
    private String productID;
    private String name;
    private double price;

    ElectronicsProduct(String productID,String name,double price){
        this.productID=productID;
        this.name=name;
        this.price=price;
    }

    public String getProductID() {
        return productID;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public void applyDiscount(double discountRate){
        price-=(price*discountRate/100);
    }

    public double getFinalPrice(){
        return price;
    }


}
