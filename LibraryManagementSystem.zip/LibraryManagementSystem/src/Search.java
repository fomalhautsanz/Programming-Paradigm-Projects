import java.util.*;

public class Search {
    public static void main (String[] args){
        String[] names = {"Mara","Leon","Andy","Barbara"};
        Arrays.sort(names);
        for (int i=0; i< names.length; i++){
            System.out.print(names[i] + " ");
        }
        System.out.println();
        int index = Arrays.binarySearch(names,"Mara");
        if (index>=0){
            System.out.println("Element is found at index " + index);
        }
        else {
            System.out.println("Element not found");
        }
    }
}
