import javax.swing.*;
import java.awt.*;

public class Saalada {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Login System");
        JLabel l1 = new JLabel("Username");
        JLabel l2 = new JLabel("Password");
        JTextField textField1 = new JTextField(20);
        JTextField textField2 = new JTextField(20);
        JButton button = new JButton("Login");

        l1.setBounds(50,50,100,30);
        l2.setBounds(50,100,100,30);
        textField1.setBounds(180,50,150,20);
        textField2.setBounds(180,100,150,20);
        button.setBounds(110,150,95,30);

        frame.setSize(390,250);
        frame.getContentPane().setBackground(new Color(240,241,197));
        frame.add(l1);
        frame.add(l2);
        frame.add(textField1);
        frame.add(textField2);
        frame.add(button);
        frame.setLayout(null);
        frame.setVisible(true);

    }
}