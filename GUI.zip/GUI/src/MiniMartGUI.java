public class MiniMartGUI {
}
