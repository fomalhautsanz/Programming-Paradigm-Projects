import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class Salada_Week2 {
    public static void main(String[] args) {
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.white);
        panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        panel.setBorder(BorderFactory.createCompoundBorder(panel.getBorder(),
                new LineBorder(Color.BLACK, 2)));
        JFrame frame = new JFrame();
        frame.setSize(400,450);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);

        JLabel addProduct = new JLabel("Add Product");
        addProduct.setBounds(30,25,150,40);
        addProduct.setFont(new Font("Arial",Font.PLAIN,18));
        panel.add(addProduct);

        RoundedTabShape tabShape = new RoundedTabShape();
        tabShape.setBounds(27, 60, 67, 5);
        panel.add(tabShape);

        JLabel productCode = new JLabel("Product Code:");
        productCode.setBounds(30,90,150,30);
        productCode.setFont(new Font("Arial",Font.BOLD,14));
        panel.add(productCode);

        RoundedTextField productCodeField = new RoundedTextField(20);
        productCodeField.setBounds(30,120,300,25);
        panel.add(productCodeField);

        JLabel name = new JLabel("Name:");
        name.setBounds(30,150,150,30);
        name.setFont(new Font("Arial",Font.BOLD,14));
        panel.add(name);

        RoundedTextField nameField = new RoundedTextField(20);
        nameField.setBounds(30,180,300,25);
        panel.add(nameField);

        JLabel quantity = new JLabel("Quantity:");
        quantity.setBounds(30,210,150,30);
        quantity.setFont(new Font("Arial",Font.BOLD,14));
        panel.add(quantity);

        RoundedTextField quantityField = new RoundedTextField(20);
        quantityField.setBounds(30,240,300,25);
        panel.add(quantityField);

        JLabel price = new JLabel("Price:");
        price.setBounds(30,270,150,30);
        price.setFont(new Font("Arial",Font.BOLD,14));
        panel.add(price);

        RoundedTextField priceField = new RoundedTextField(20);
        priceField.setBounds(30,300,300,25);
        panel.add(priceField);

        RoundedButton add = new RoundedButton("Add");
        add.setBounds(60,350,90,30);
        add.setFont(new Font("Arial",Font.BOLD,12));
        add.setBackground(new Color(7,65,115));
        add.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        add.addActionListener(e -> {
            System.out.println("Added!");
        });
        panel.add(add);

        RoundedButton back = new RoundedButton("Back");
        back.setBounds(200,350,90,30);
        back.setFont(new Font("Arial",Font.BOLD,12));
        back.setBackground(Color.white);
        back.setForeground(Color.black);
        back.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
         back.addActionListener(e -> {
             System.out.println("Going back...");
         });
        panel.add(back);

        frame.setVisible(true);
    }
}

class RoundedTabShape extends JComponent {
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2.setColor(new Color(7,65,115));
        g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 20, 20));
    }
}

class RoundedTextField extends JTextField {
    private int arcWidth = 5;
    private int arcHeight = 15;

    public RoundedTextField(int columns) {
        super(columns);
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2.setColor(getBackground());
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), arcWidth, arcHeight);

        super.paintComponent(g);
        g2.dispose();
    }

    @Override
    protected void paintBorder(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2.setColor(Color.GRAY);
        g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arcWidth, arcHeight);
        g2.dispose();
    }
}

class RoundedButton extends JButton {
    private int arcWidth = 10;
    private int arcHeight = 20;

    public RoundedButton(String text) {
        super(text);
        setFocusPainted(false);
        setContentAreaFilled(false);
        setBorderPainted(false);
        setOpaque(false);
        setForeground(Color.WHITE);
        setBackground(new Color(7,65,11));
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2.setColor(getBackground());
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), arcWidth, arcHeight);

        super.paintComponent(g);
        g2.dispose();
    }

    @Override
    protected void paintBorder(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2.setColor(Color.DARK_GRAY);
        g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arcWidth, arcHeight);
        g2.dispose();
    }
}



