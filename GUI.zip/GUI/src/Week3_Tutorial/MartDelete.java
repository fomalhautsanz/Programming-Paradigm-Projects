package Week3_Tutorial;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class MartDelete extends JFrame implements ActionListener {

    private JLabel martHeader, codeLabel, nameLabel, quantityLabel, priceLabel;
    private JTextField codeField, nameField, quantityField, priceField;
    private JButton deleteButton, backButton, searchButton;
    Connection connection;
    private Statement statement;

    public MartDelete(){
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/martDB","root","");
        } catch (SQLException e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,"Failed to connect to the database","Error",JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        setSize(450,530);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JPanel panel = new JPanel();
        panel.setSize(450,530);
        panel.setLayout(null);
        panel.setBackground(Color.white);

        martHeader = new JLabel("Delete Product");
        martHeader.setBounds(30,30,200,30);
        martHeader.setFont(new Font("Arial",Font.BOLD,20));
        panel.add(martHeader);

        JButton under = new JButton("");
        under.setBounds(30,60,70,5);
        under.setFocusPainted(false);
        under.setEnabled(false);
        under.setBorderPainted(false);
        under.setBackground(new Color(8,68,116));
        panel.add(under);

        codeLabel = new JLabel("Product Code: ");
        codeLabel.setBounds(30,100,150,20);
        codeLabel.setFont(new Font("Arial",Font.BOLD,16));
        panel.add(codeLabel);

        codeField = new JTextField(10);
        codeField.setBounds(30,125,240,30);
        panel.add(codeField);

        searchButton = new JButton("Search");
        searchButton.setBounds(290,125,120,30);
        searchButton.setBackground(new Color(8,68,116));
        searchButton.setForeground(Color.white);
        searchButton.setFont(new Font("Arial",Font.BOLD,16));
        searchButton.addActionListener(this);
        panel.add(searchButton);

        nameLabel = new JLabel("Name: ");
        nameLabel.setBounds(30,175,150,20);
        nameLabel.setFont(new Font("Arial",Font.BOLD,16));
        panel.add(nameLabel);

        nameField = new JTextField(10);
        nameField.setBounds(30,200,360,30);
        nameField.setEditable(false);
        panel.add(nameField);

        quantityLabel = new JLabel("Quantity: ");
        quantityLabel.setBounds(30,250,150,20);
        quantityLabel.setFont(new Font("Arial",Font.BOLD,16));
        panel.add(quantityLabel);

        quantityField = new JTextField(10);
        quantityField.setBounds(30,275,360,30);
        quantityField.setEditable(false);
        panel.add(quantityField);

        priceLabel = new JLabel("Price: ");
        priceLabel.setBounds(30,325,150,20);
        priceLabel.setFont(new Font("Arial",Font.BOLD,16));
        panel.add(priceLabel);

        priceField = new JTextField(10);
        priceField.setBounds(30,350,360,30);
        priceField.setEditable(false);
        panel.add(priceField);

        deleteButton = new JButton("Delete");
        deleteButton.setBounds(75,420,120,40);
        deleteButton.setFont(new Font("Arial",Font.BOLD,16));
        deleteButton.setBackground(new Color(8,68,116));
        deleteButton.setForeground(Color.white);
        deleteButton.setEnabled(false);
        deleteButton.addActionListener(this);
        panel.add(deleteButton);

        backButton = new JButton("Back");
        backButton.setBounds(225, 420, 120, 40);
        backButton.setFont(new Font("Arial", Font.BOLD, 16));
        backButton.setBackground(Color.white);
        backButton.setForeground(new Color(8, 68, 116));
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createLineBorder(new Color(8, 68, 116), 2));
        backButton.addActionListener(this);
        panel.add(backButton);

        add(panel);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == searchButton){
            int code = Integer.parseInt(codeField.getText());

            try {

                statement = connection.createStatement();
                String sql = "SELECT * FROM miniMart WHERE CODE = " + code;
                ResultSet resultSet = statement.executeQuery(sql);

                if (resultSet.next()){
                    nameField.setText(resultSet.getString("NAME"));
                    quantityField.setText(resultSet.getString("QUANTITY"));
                    priceField.setText(resultSet.getString("PRICE"));

                    deleteButton.setEnabled(true);
                }
                else {
                    JOptionPane.showMessageDialog(this,"No data found in the specified code","Error",JOptionPane.ERROR_MESSAGE);
                }

            } catch (SQLException ex){
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this,"Failed to search for the data in the database","Error",JOptionPane.ERROR_MESSAGE);
            }
        }

        if (e.getSource() == deleteButton){
            int code = Integer.parseInt(codeField.getText());

            try {
                statement = connection.createStatement();
                String sql = "DELETE FROM miniMart WHERE CODE = " + code;

                int rowsAffected = statement.executeUpdate(sql);

                if (rowsAffected > 0){
                    JOptionPane.showMessageDialog(this,"Data deleted successfully!");
                    dispose();
                    new MainMenu();
                }
                else {
                    JOptionPane.showMessageDialog(this,"No data found in the specified code");
                }
            } catch (SQLException exx){
                exx.printStackTrace();
                JOptionPane.showMessageDialog(this,"Failed to delete data","Error",JOptionPane.ERROR_MESSAGE);
            }
        }

        if (e.getSource() == backButton){
            new MainMenu();
            dispose();
        }

    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MartDelete :: new);
    }
}
