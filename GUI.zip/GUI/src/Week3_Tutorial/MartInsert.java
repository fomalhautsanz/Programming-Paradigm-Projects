package Week3_Tutorial;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class MartInsert extends JFrame implements ActionListener {

    private JLabel martHeader, codeLabel, nameLabel, quantityLabel, priceLabel;
    private JTextField codeField, nameField, quantityField, priceField;
    private JButton addButton, backButton;

    private Connection connection;
    private Statement statement;

    public MartInsert(){
        super("Add Product");

        try{
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/martDB","root","");
        } catch (SQLException e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,"Failed to connect to the database","Error",JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        setSize(450,530);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JPanel panel = new JPanel();
        panel.setSize(450,530);
        panel.setLayout(null);
        panel.setBackground(Color.white);

        martHeader = new JLabel("Add Product");
        martHeader.setBounds(30,30,200,30);
        martHeader.setFont(new Font("Arial",Font.BOLD,20));
        panel.add(martHeader);

        JButton under = new JButton("");
        under.setBounds(30,60,70,5);
        under.setFocusPainted(false);
        under.setEnabled(false);
        under.setBorderPainted(false);
        under.setBackground(new Color(8,68,116));
        panel.add(under);

        codeLabel = new JLabel("Product Code: ");
        codeLabel.setBounds(30,100,150,20);
        codeLabel.setFont(new Font("Arial",Font.BOLD,16));
        panel.add(codeLabel);

        codeField = new JTextField(10);
        codeField.setBounds(30,125,360,30);
        panel.add(codeField);

        nameLabel = new JLabel("Name: ");
        nameLabel.setBounds(30,175,150,20);
        nameLabel.setFont(new Font("Arial",Font.BOLD,16));
        panel.add(nameLabel);

        nameField = new JTextField(10);
        nameField.setBounds(30,200,360,30);
        panel.add(nameField);

        quantityLabel = new JLabel("Quantity: ");
        quantityLabel.setBounds(30,250,150,20);
        quantityLabel.setFont(new Font("Arial",Font.BOLD,16));
        panel.add(quantityLabel);

        quantityField = new JTextField(10);
        quantityField.setBounds(30,275,360,30);
        panel.add(quantityField);

        priceLabel = new JLabel("Price: ");
        priceLabel.setBounds(30,325,150,20);
        priceLabel.setFont(new Font("Arial",Font.BOLD,16));
        panel.add(priceLabel);

        priceField = new JTextField(10);
        priceField.setBounds(30,350,360,30);
        panel.add(priceField);

        addButton = new JButton("Add");
        addButton.setBounds(75,420,120,40);
        addButton.setFont(new Font("Arial",Font.BOLD,16));
        addButton.setBackground(new Color(8,68,116));
        addButton.setForeground(Color.white);
        addButton.addActionListener(this);
        panel.add(addButton);

        backButton = new JButton("Back");
        backButton.setBounds(225, 420, 120, 40);
        backButton.setFont(new Font("Arial", Font.BOLD, 16));
        backButton.setBackground(Color.white);
        backButton.setForeground(new Color(8, 68, 116));
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createLineBorder(new Color(8, 68, 116), 2));
        backButton.addActionListener(this);
        panel.add(backButton);


        add(panel);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        int code = Integer.parseInt(codeField.getText());
        String name = nameField.getText();
        int quantity = Integer.parseInt(quantityField.getText());
        double price = Double.parseDouble(priceField.getText());

        if (e.getSource() == addButton){
            try {
                statement = connection.createStatement();

                statement.executeUpdate("INSERT INTO miniMart (CODE, NAME, QUANTITY, PRICE) VALUES " +
                        "(" + code + ", '" + name + "', "+ quantity + ", " + price + ")");

                JOptionPane.showMessageDialog(this,"Product added successfully!");
                dispose();
                new MainMenu();

            } catch (SQLException ex){
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this,"Failed to insert data into the database","Error",JOptionPane.ERROR_MESSAGE);
            }
        }

        if (e.getSource() == backButton){
            dispose();
            new MainMenu();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MartInsert :: new);
    }
}
