package Week3_Tutorial;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Config {
    static String url = "jdbc:mysql://localhost:3306/";
    static String user = "root";
    static String password = "";

    static Connection connection;
    static Statement statement;

    public static void main(String[] args) {
        try {
            connection = DriverManager.getConnection(url,user,password);
            statement = connection.createStatement();

            statement.executeUpdate("DROP DATABASE IF EXISTS martDB");
            statement.executeUpdate("CREATE DATABASE martDB");
            System.out.println("Database created successfully!");
            statement.executeUpdate("USE martDB");

            String sqlCreateTable = "CREATE TABLE IF NOT EXISTS miniMart (" +
                    "CODE int PRIMARY KEY, " +
                    "NAME varchar(250), " +
                    "QUANTITY int, " +
                    "PRICE double)";

            statement.executeUpdate(sqlCreateTable);
            System.out.println("Table 'miniMart' created successfully!");
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
}
