package Week3_Tutorial;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Objects;

public class MainMenu extends JFrame{

    private JLabel image;
    private JLabel label1, label2;
    private JButton insert, update, delete;

    public MainMenu(){
        super("Mini Mart Information Management");

        setSize(450,500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        setBackground(Color.white);

        JPanel panel = new JPanel();
        panel.setBackground(Color.white);
        panel.setSize(500,500);
        panel.setLayout(null);

        ImageIcon logo = new ImageIcon(Objects.requireNonNull(MainMenu.class.getResource("martlogo.png")));
        Image scaledImage = logo.getImage().getScaledInstance(55,60,Image.SCALE_SMOOTH);
        ImageIcon resizedLogo = new ImageIcon(scaledImage);

        image = new JLabel(resizedLogo);
        image.setSize(55,60);
        image.setBounds(166,50,90,100);
        panel.add(image);

        label1 = new JLabel("MINI MART");
        label1.setFont(new Font("Arial",Font.BOLD,20));
        label1.setBounds(159,135,150,30);
        panel.add(label1);

        label2 = new JLabel("INFORMATION MANAGEMENT");
        label2.setFont(new Font("Arial",Font.BOLD,20));
        label2.setBounds(75,160,300,30);
        panel.add(label2);

        insert = new JButton("Insert");
        insert.setFont(new Font("Arial",Font.BOLD,14));
        insert.setOpaque(true);
        insert.setFocusPainted(false);
        insert.setBackground(new Color(8,68,116));
        insert.setForeground(Color.white);
        insert.setBounds(140,220,150,40);
        panel.add(insert);

        update = new JButton("Update");
        update.setFont(new Font("Arial",Font.BOLD,14));
        update.setOpaque(true);
        update.setFocusPainted(false);
        update.setBackground(new Color(8,68,116));
        update.setForeground(Color.white);
        update.setBounds(140,280,150,40);
        panel.add(update);

        delete = new JButton("Delete");
        delete.setFont(new Font("Arial",Font.BOLD,14));
        delete.setOpaque(true);
        delete.setFocusPainted(false);
        delete.setBackground(new Color(8,68,116));
        delete.setForeground(Color.white);
        delete.setBounds(140,340,150,40);
        panel.add(delete);

        insert.addActionListener(e -> {
            new MartInsert();
            dispose();
        });

        update.addActionListener(e -> {
            new MartUpdate();
            dispose();
        });

        delete.addActionListener(e -> {
            new MartDelete();
            dispose();
        });

        add(panel);
        setVisible(true);
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainMenu :: new);
    }
}
