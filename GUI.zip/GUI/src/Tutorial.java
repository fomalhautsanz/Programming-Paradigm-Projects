import javax.swing.*;

public class Tutorial {
    public static void main(String[] args) {
        //grid bug layout
        JFrame frame = new JFrame();

    }
}
