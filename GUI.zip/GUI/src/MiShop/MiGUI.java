package MiShop;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MiGUI extends JFrame implements ActionListener {

    private JCheckBox burger, pizza, fries;
    private JComboBox comboBox;
    private JTextField paymentField;
    private JButton placeOrder, clear;
    private JTextArea textArea;

    public MiGUI(){
        setSize(350,550);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JPanel panel = new JPanel();
        panel.setSize(300,550);
        panel.setLayout(null);
        add(panel);

        JLabel header = new JLabel("MiShop Bites");
        header.setBounds(120,30,300,30);
        header.setFont(new Font("Arial",Font.BOLD,14));
        panel.add(header);

        burger = new JCheckBox("Burger [$ 100]");
        burger.setBounds(30,70,300,30);
        burger.setFocusPainted(false);
        panel.add(burger);

        pizza = new JCheckBox("Pizza [$ 150]");
        pizza.setBounds(30,100,300,30);
        pizza.setFocusPainted(false);
        panel.add(pizza);

        fries = new JCheckBox("Fries [$ 85]");
        fries.setBounds(30,130,300,30);
        fries.setFocusPainted(false);
        panel.add(fries);

        JLabel paymentLabel = new JLabel("Choose payment method:");
        paymentLabel.setBounds(30,180,300,30);
        paymentLabel.setFont(new Font("Arial",Font.BOLD,12));
        panel.add(paymentLabel);


        String[] paymentMethod = {"Cash","GCash","Credit"};
        comboBox = new JComboBox<>(paymentMethod);
        comboBox.setBounds(30,210,150,30);
        panel.add(comboBox);

        JLabel payOrder = new JLabel("Enter payment: ");
        payOrder.setBounds(30,265,300,30);
        payOrder.setFont(new Font("Arial",Font.BOLD,12));
        panel.add(payOrder);

        paymentField = new JTextField(10);
        paymentField.setBounds(130,272,100,20);
        panel.add(paymentField);

        placeOrder = new JButton("Place Order");
        placeOrder.setBounds(30,320,120,30);
        placeOrder.setFont(new Font("Arial",Font.BOLD,12));
        placeOrder.addActionListener(this);
        panel.add(placeOrder);

        clear = new JButton("Clear");
        clear.setBounds(160,320,120,30);
        clear.setFont(new Font("Arial",Font.BOLD,12));
        clear.addActionListener(this);
        panel.add(clear);

        textArea = new JTextArea();
        textArea.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setBounds(30, 400, 250, 100);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        panel.add(scrollPane);


        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == placeOrder){
            StringBuilder orderSummary = new StringBuilder("ORDER SUMMARY: \n");

            double total = 0;

            if (burger.isSelected()){
                orderSummary.append("- Burger: $100 \n");
                total+=100;
            }
            if (pizza.isSelected()){
                orderSummary.append("- Pizza: $150 \n");
                total+=150;
            }
            if (fries.isSelected()){
                orderSummary.append("- Fries: $85 \n");
                total+=85;
            }

            orderSummary.append("\nTotal: $" + total + "\n");

            try {
                double payment = Double.parseDouble(paymentField.getText());

                if (payment<total){
                    JOptionPane.showMessageDialog(this,"Insufficient cash!","Error",JOptionPane.ERROR_MESSAGE);
                    paymentField.setText("");
                }
                else {
                    double change = payment - total;
                    orderSummary.append("Amount Paid: $" + payment + "\n");
                    orderSummary.append("Change: $" + change + "\n");
                    textArea.setText(orderSummary.toString());
                }
            } catch (NumberFormatException ex){
                JOptionPane.showMessageDialog(this,"Please enter a valid amount!","Error",JOptionPane.ERROR_MESSAGE);
            }
        }

        if (e.getSource() == clear){
            paymentField.setText("");
            textArea.setText("");
            burger.setSelected(false);
            pizza.setSelected(false);
            fries.setSelected(false);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MiGUI :: new);
    }
}
