package MiShop;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class MiShopDB {

    static String url = "jdbc:mysql://localhost:3306";
    static String user = "root";
    static String password = "";

    static Connection connection;
    static Statement statement;

    public static void main(String[] args) {
        try {
            connection = DriverManager.getConnection(url,user,password);
            statement = connection.createStatement();

            statement.executeUpdate("DROP DATABASE IF EXISTS miDB");
            statement.executeUpdate("CREATE DATABASE miDB");
            System.out.println("Database created successfully!");
            statement.executeUpdate("USE miDB");

            statement.executeUpdate("CREATE TABLE IF NOT EXISTS Orders (" +
                    "ORDER int AUTO_INCREMENT PRIMARY KEY," +
                    "FOOD_ITEM varchar(50)," +
                    "PAYMENT_METHOD varchar(50)," +
                    "AMOUNT_PAID double," +
                    "ORDER_TIME TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
            System.out.println("Table 'Orders' created successfully!");
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
}
