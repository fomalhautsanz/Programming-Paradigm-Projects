package Exercise;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Config {

    static String url = "jdbc:mysql://localhost:3306/";
    static String user = "root";
    static String password = "";

    static Connection connection;
    static Statement statement;

    public static void main(String[] args){
        try{
            connection = DriverManager.getConnection(url, user, password);
            statement = connection.createStatement();

            statement.executeUpdate("DROP DATABASE IF EXISTS DB2");
            statement.executeUpdate("CREATE DATABASE DB2");
            System.out.println("Database created successfully");
            String sqlUseDB = "USE DB2";
            statement.executeUpdate(sqlUseDB);
            System.out.println("Switched to database DB2");

            String sqlCreateTable = "CREATE TABLE IF NOT EXISTS Book(" +
                    "CODE int NOT NULL, " +
                    "TITLE varchar(250), " +
                    "TYPE varchar(250), " +
                    "PRICE int, " +
                    "QUANTITY int, " +
                    "SALES int DEFAULT 0," +
                    "PRIMARY KEY (code))";
            statement.executeUpdate(sqlCreateTable);
            instantiate();
            System.out.println("Table 'Book' created successfully");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void instantiate(){
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/DB2",user,password);
            statement = connection.createStatement();

            String sql = "INSERT INTO Book (CODE, TITLE, TYPE, PRICE, QUANTITY, SALES) VALUES " +
                    "(1001, 'Introduction to Java', 'Programming', 450, 20, 0)," +
                    "(1002, 'Data Structures in C', 'Computer Science', 500, 15, 0)," +
                    "(1003, 'Database Systems', 'Information Technology', 550, 18, 0)," +
                    "(1004, 'Digital Marketing Basics', 'Business', 400, 10, 0)," +
                    "(1005, 'Modern Web Design', 'Design', 600, 12, 0)," +
                    "(1006, 'Python for Data Science', 'Programming', 650, 25, 0)," +
                    "(1007, 'Linear Algebra Explained', 'Mathematics', 420, 16, 0)," +
                    "(1008, 'Cybersecurity Essentials', 'Technology', 700, 14, 0)," +
                    "(1009, 'Project Management Guide', 'Business', 480, 22, 0)," +
                    "(1010, 'Artificial Intelligence Intro', 'Computer Science', 800, 8, 0)";

            statement.executeUpdate(sql);
            System.out.println("Book records inserted successfully.");
        } catch (SQLException ex){
            ex.printStackTrace();
        }
    }
}
