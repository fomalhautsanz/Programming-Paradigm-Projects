package Exercise;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class UpdateBook extends JFrame  implements ActionListener {

    private JTextField codeField, titleField, typeField, priceField, quantityField;
    private JButton searchButton, saveButton, cancelButton;
    private Connection connection;
    private Statement statement;

    public UpdateBook(){
        super("Update Book");

        String url = "jdbc:mysql://localhost:3306/DB2";
        String user = "root";
        String password = "";

        // UpdateStudentData.java
        try {
            connection = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to connect to the database.", "Error",
                    JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        codeField = new JTextField(10);
        titleField = new JTextField(10);
        typeField = new JTextField(10);
        priceField = new JTextField(10);
        quantityField = new JTextField(10);

        searchButton = new JButton("Search");
        searchButton.addActionListener(this);
        saveButton = new JButton("Save");
        saveButton.addActionListener(this);
        saveButton.setEnabled(false);
        cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e -> {
            dispose();
        });

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(null);
        JLabel headerLabel = new JLabel("BOOK INFORMATION SYSTEM", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 16));
        headerLabel.setBounds(90, 10, 250, 30);
        add(headerLabel);

        // Labels and Fields
        JLabel codeLabel = new JLabel("BOOK CODE:");
        codeLabel.setBounds(30, 50, 100, 25);
        add(codeLabel);

        codeField = new JTextField();
        codeField.setBounds(140, 50, 120, 25);
        add(codeField);

        searchButton = new JButton("SEARCH");
        searchButton.setBounds(270, 50, 100, 25);
        searchButton.addActionListener(this);
        add(searchButton);

        JLabel titleLabel = new JLabel("BOOK TITLE:");
        titleLabel.setBounds(30, 90, 100, 25);
        add(titleLabel);

        titleField = new JTextField();
        titleField.setBounds(140, 90, 230, 25);
        add(titleField);

        JLabel typeLabel = new JLabel("BOOK TYPE:");
        typeLabel.setBounds(30, 130, 100, 25);
        add(typeLabel);

        typeField = new JTextField();
        typeField.setBounds(140, 130, 230, 25);
        add(typeField);

        JLabel priceLabel = new JLabel("BOOK PRICE:");
        priceLabel.setBounds(30, 170, 100, 25);
        add(priceLabel);

        priceField = new JTextField();
        priceField.setBounds(140, 170, 230, 25);
        add(priceField);

        JLabel quantityLabel = new JLabel("QUANTITY:");
        quantityLabel.setBounds(30, 210, 100, 25);
        add(quantityLabel);

        quantityField = new JTextField();
        quantityField.setBounds(140, 210, 230, 25);
        add(quantityField);

        // Buttons
        saveButton = new JButton("SAVE");
        saveButton.setBounds(100, 260, 100, 30);
        saveButton.setEnabled(false);
        saveButton.addActionListener(this);
        add(saveButton);

        cancelButton = new JButton("CANCEL");
        cancelButton.setBounds(220, 260, 100, 30);
        cancelButton.addActionListener(e -> {
            dispose();
            new MainMenu();
        });
        add(cancelButton);

// Add input panel to the frame
        setLayout(null);
        add(inputPanel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(420, 340);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == searchButton) {
// Get ID from text field
            int code = Integer.parseInt(codeField.getText());
// Search for the ID in the database
            try {
                statement = connection.createStatement();
                String sql = "SELECT * FROM Book WHERE CODE=" + code;
                ResultSet resultSet = statement.executeQuery(sql);
                if (resultSet.next()) {
// Data found, enable the update button and populate fields
                    titleField.setText(resultSet.getString("TITLE"));
                    typeField.setText(resultSet.getString("TYPE"));
                    priceField.setText(resultSet.getString("PRICE"));
                    quantityField.setText(resultSet.getString("QUANTITY"));
                    saveButton.setEnabled(true);

                } else {
// Data not found,show error message and disable the update button
                    JOptionPane.showMessageDialog(this, "No data found with the specified Code.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    saveButton.setEnabled(false);
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Failed to search for data in the database.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (e.getSource() == saveButton) {
// Get data from text fields
            int code = Integer.parseInt(codeField.getText());
            String title = titleField.getText();
            String type = typeField.getText();
            int price = Integer.parseInt(priceField.getText());
            int quantity = Integer.parseInt(quantityField.getText());

            try {
                statement = connection.createStatement();
                String sql = "UPDATE Book SET TITLE='" + title + "', TYPE='" + type + "', PRICE = " +
                        price + ", QUANTITY = " + quantity + " WHERE CODE = " + code;
                int rowsAffected = statement.executeUpdate(sql);
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Data updated successfully.");
// Navigate to anotherframe
                    new AnotherFrame();
// Close the current frame
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "No data found with the specified ID.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }

            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Failed to update data in the database.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(()-> {
            UpdateBook updateBook = new UpdateBook();
            updateBook.setVisible(true);
        });
    }
}

class AnotherFrame1 extends JFrame {
    public AnotherFrame1() {
        super("Another Frame");
        JLabel label = new JLabel("You have successfully updated the record!");
        add(label);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(420, 340);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}

