package Exercise;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.*;

public class MainMenu {
    private JFrame mainFrame;
    private JPanel controlPanel;

    public MainMenu(){
        prepareGUI(); }

    public static void main(String[] args){
        new MainMenu();
    }

    public void prepareGUI(){
        mainFrame = new JFrame("BOOK INFORMATION SYSTEM");
        mainFrame.setSize(300,400);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setLocationRelativeTo(null);

        controlPanel = new JPanel();
        controlPanel.setLayout(new BoxLayout(controlPanel,BoxLayout.Y_AXIS));
        TitledBorder border = BorderFactory.createTitledBorder("BOOK INFORMATION SYSTEM");
        border.setTitleFont(new Font("Arial",Font.BOLD,16));
        border.setTitleJustification(TitledBorder.CENTER);
        controlPanel.setBorder(border);

        mainFrame.add(controlPanel);

        JButton add = new JButton("ADD BOOK");
        JButton view = new JButton("VIEW BOOK");
        JButton update = new JButton("UPDATE BOOK");
        JButton delete = new JButton("DELETE BOOK");
        JButton pos = new JButton("POS");
        JButton inventory = new JButton("INVENTORY");

        JButton[] buttons = {add,view,update,delete,pos,inventory};

        for (JButton button : buttons){
            button.setAlignmentX(Component.CENTER_ALIGNMENT);
            button.setMaximumSize(new Dimension(200,40));
            button.setFont(new Font("SansSerif",Font.BOLD,14));
            button.setFocusPainted(false);
            button.setBackground(Color.WHITE);
            controlPanel.add(Box.createRigidArea(new Dimension(0,10)));
            controlPanel.add(button);
        }

        add.addActionListener(e -> {
            mainFrame.dispose();
            new AddBook();
        });
        view.addActionListener(e -> {
            mainFrame.dispose();
            new ViewBook();
        });
        update.addActionListener(e -> {
            mainFrame.dispose();
            new UpdateBook();
        });
        delete.addActionListener(e -> {
            mainFrame.dispose();
            new DeleteBook();
        });
        pos.addActionListener(e -> {
            mainFrame.dispose();
            new Pos();
        });
        inventory.addActionListener(e -> {
            mainFrame.dispose();
            new Inventory();
        });

        mainFrame.setVisible(true);
    }
}


