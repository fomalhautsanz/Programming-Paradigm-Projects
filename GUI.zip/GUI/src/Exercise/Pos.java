package Exercise;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Pos extends JFrame implements ActionListener {

    private JTextField codeField, titleField, typeField, priceField, quantityField, amountField, cashField, changeField;
    private JButton searchButton, computeBut1, computeBut2, purchaseButton, cancelButton;
    private Connection connection;
    private Statement statement;

    int sales = 0;
    int total = 0;

    public Pos(){
        super("Point of Sale");

        String url = "jdbc:mysql://localhost:3306/DB2";
        String user = "root";
        String password = "";

        try {
            connection = DriverManager.getConnection(url,user,password);
        } catch (SQLException e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,"Failed to connect to the database","Error",JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        codeField = new JTextField(10);
        titleField = new JTextField(10);
        typeField = new JTextField(10);
        priceField = new JTextField(10);
        quantityField = new JTextField(10);
        amountField = new JTextField(10);
        cashField = new JTextField(10);
        changeField = new JTextField(10);

        searchButton = new JButton("SEARCH");
        searchButton.addActionListener(this);

        computeBut1 = new JButton("COMPUTE");
        computeBut1.addActionListener(this);

        computeBut2 = new JButton("COMPUTE");
        computeBut2.addActionListener(this);

        purchaseButton = new JButton("PURCHASE");
        purchaseButton.addActionListener(this);

        cancelButton = new JButton("CANCEL");
        cancelButton.addActionListener(e -> {
            dispose();
        });

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(null);
        JLabel headerLabel = new JLabel("BOOKSHOP INFORMATION SYSTEM", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial",Font.BOLD,13));
        headerLabel.setBounds(100,10,300,30);
        add(headerLabel);

        JLabel subHeader = new JLabel("POINT OF SALE", JLabel.CENTER);
        subHeader.setFont(new Font("Arial",Font.BOLD,13));
        subHeader.setBounds(120,30,250,30);
        add(subHeader);

        JLabel codeLabel = new JLabel("BOOK CODE: ");
        codeLabel.setBounds(10,60,100,30);
        add(codeLabel);

        codeField.setBounds(130,65,200,20);
        add(codeField);

        searchButton.setBounds(340,65,100,19);
        add(searchButton);

        JLabel titleLabel = new JLabel("BOOK TITLE: ");
        titleLabel.setBounds(10,100,100,30);
        add(titleLabel);

        titleField.setBounds(130,100,200,20);
        titleField.setEditable(false);
        add(titleField);

        JLabel typeLabel = new JLabel("BOOK TYPE: ");
        typeLabel.setBounds(10,140,100,30);
        add(typeLabel);

        typeField.setBounds(130,140,200,20);
        typeField.setEditable(false);
        add(typeField);

        JLabel priceLabel = new JLabel("BOOK PRICE: ");
        priceLabel.setBounds(10,180,100,30);
        add(priceLabel);

        priceField.setBounds(130,180,200,20);
        priceField.setEditable(false);
        add(priceField);

        JLabel quantityLabel = new JLabel("QUANTITY: ");
        quantityLabel.setBounds(10,220,150,30);
        add(quantityLabel);

        quantityField.setBounds(130,220,200,20);
        add(quantityField);

        JLabel totalAmount = new JLabel("TOTAL AMOUNT: ");
        totalAmount.setBounds(30,260,150,30);
        add(totalAmount);

        amountField.setBounds(150,265,200,20);
        amountField.setEditable(false);
        add(amountField);

        computeBut1.setBounds(360,265,100,19);
        computeBut1.setEnabled(false);
        add(computeBut1);

        JLabel cash = new JLabel("CASH: ");
        cash.setBounds(30,300,150,30);
        add(cash);

        cashField.setBounds(150,300,200,20);
        add(cashField);

        JLabel change = new JLabel("CHANGE: ");
        change.setBounds(30,340,150,30);
        add(change);

        changeField.setBounds(150,345,200,20);
        changeField.setEditable(false);
        add(changeField);

        computeBut2.setBounds(360,345,100,19);
        computeBut2.setEnabled(false);
        add(computeBut2);

        purchaseButton.setBounds(150,390,100,19);
        purchaseButton.setEnabled(false);
        add(purchaseButton);

        cancelButton.setBounds(260,390,100,19);
        add(cancelButton);

        setLayout(null);
        add(inputPanel);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(540,490);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == searchButton){
            int code = Integer.parseInt(codeField.getText());

            try {
                statement = connection.createStatement();
                String sql = "SELECT * FROM Book WHERE CODE = " + code;
                ResultSet resultSet = statement.executeQuery(sql);

                if (resultSet.next()) {
                    titleField.setText(resultSet.getString("TITLE"));
                    typeField.setText(resultSet.getString("TYPE"));
                    priceField.setText(resultSet.getString("PRICE"));

                    computeBut1.setEnabled(true);
                }
                else {
                    JOptionPane.showMessageDialog(this,"No data found in the specified code","Error",JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException ex){
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this,"Failed to search for the data in the database");
            }
        }

        if (e.getSource() == computeBut1) {

            int code = Integer.parseInt(codeField.getText());
            int bookQuantity = 0;
            int price = 0;

            try {
                statement = connection.createStatement();
                String sql = "SELECT * FROM Book WHERE CODE = " + code;
                ResultSet resultSet = statement.executeQuery(sql);
                int quantityBought = Integer.parseInt(quantityField.getText());

                while (resultSet.next()){
                    bookQuantity = Integer.parseInt(resultSet.getString("QUANTITY"));
                    price = Integer.parseInt(resultSet.getString("PRICE"));
                }

                if (quantityBought<=bookQuantity){
                    total = quantityBought * price;
                    amountField.setText(String.valueOf(total));
                    computeBut2.setEnabled(true);
                }
                else {
                    JOptionPane.showMessageDialog(this, "Insufficient stocks!","Error",JOptionPane.ERROR_MESSAGE);
                    quantityField.setText("");
                }

            } catch (SQLException exx){
                exx.printStackTrace();
                JOptionPane.showMessageDialog(this, "Something went wrong while computing the total amount",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        if (e.getSource() == computeBut2){
            int cash = Integer.parseInt(cashField.getText());

               if (cash>=total){
                   int change = cash - total;
                   changeField.setText(String.valueOf(change));
                   purchaseButton.setEnabled(true);
               }
               else {
                   JOptionPane.showMessageDialog(this,"Insufficient cash!","Error",JOptionPane.ERROR_MESSAGE);
                    cashField.setText("");
               }
           }

        if (e.getSource()==purchaseButton){

            int code = Integer.parseInt(codeField.getText());
            int quantityBought = Integer.parseInt(quantityField.getText());

            try {
                statement = connection.createStatement();
                String sql = "SELECT * FROM Book WHERE CODE = " + code;
                ResultSet rs = statement.executeQuery(sql);

                while (rs.next()){
                    sales = Integer.parseInt(rs.getString("SALES"));
                }

                sales+=total;
                statement.executeUpdate("UPDATE Book SET SALES = " + sales + ", QUANTITY = QUANTITY - " + quantityBought + " WHERE CODE = " + code);
                total=0;

                new MainMenu();
                dispose();
            } catch (SQLException exception){
                JOptionPane.showMessageDialog(this,"Something went wrong. Please try again.","Error",JOptionPane.ERROR_MESSAGE);
            }
        }

    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Pos pos = new Pos();
            pos.setVisible(true);
        });
    }
}
