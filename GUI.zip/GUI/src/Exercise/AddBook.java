package Exercise;

//NO ACTION FOR BACK BUTTON YET
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class AddBook extends JFrame implements ActionListener {

    private JTextField codeField, titleField, typeField, priceField, quantityField;
    private JButton submitButton, backButton;
    private Connection connection;
    private Statement statement;
    public AddBook() {
        super("ADD BOOK");
        String url = "jdbc:mysql://localhost:3306/DB2";
        String user = "root";
        String password = "";

        try {
            connection = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to connect to the database.", "Error",
                    JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
// Create labels and text fields
        codeField = new JTextField(10);
        titleField = new JTextField(10);
        typeField = new JTextField(10);
        priceField = new JTextField(10);
        quantityField = new JTextField(10);
// Create submit button
        submitButton = new JButton("ADD");
        submitButton.addActionListener(this);

        backButton = new JButton("BACK");
        backButton.addActionListener(e->{
            dispose();
            new MainMenu();
        });

        JPanel inputPanel = new JPanel(new GridLayout(6, 2));
        inputPanel.add(new JLabel("BOOK CODE:"));
        inputPanel.add(codeField);
        inputPanel.add(new JLabel("BOOK TITLE:"));
        inputPanel.add(titleField);
        inputPanel.add(new JLabel("BOOK TYPE:"));
        inputPanel.add(typeField);
        inputPanel.add(new JLabel("BOOK PRICE:"));
        inputPanel.add(priceField);
        inputPanel.add(new JLabel("QUANTITY:"));
        inputPanel.add(quantityField);
        inputPanel.add(submitButton);
        inputPanel.add(backButton);
// Add input panel to the frame
        add(inputPanel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitButton) {
// Get data from text fields
            int code = Integer.parseInt(codeField.getText());
            String title = titleField.getText();
            String type = typeField.getText();
            int price = Integer.parseInt(priceField.getText());
            int quantity = Integer.parseInt(quantityField.getText());

            try {
                statement = connection.createStatement();
                String sql = "INSERT INTO Book (CODE, TITLE, TYPE, PRICE, QUANTITY) VALUES " +
                        "(" + code + ", '" + title + "', '" + type + "'," + price + "," + quantity + ")";
                statement.executeUpdate(sql);
                JOptionPane.showMessageDialog(this, "Data inserted successfully.");

                new AnotherFrame();

                dispose();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Failed to insert data into the database.", "Error",
                        JOptionPane.ERROR_MESSAGE);
            } }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AddBook::new);
    }
}

class AnotherFrame extends JFrame {
    public AnotherFrame() {
        super("Another Frame");

        JLabel label = new JLabel("You have successfully inserted the record!");
        JButton ok = new JButton("OK");

        ok.addActionListener(e -> {
            dispose();
            new MainMenu();
        });

        setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));  // spacing between components
        add(label);
        add(ok);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(350, 120);
        setLocationRelativeTo(null);
        setVisible(true);
    }

}

