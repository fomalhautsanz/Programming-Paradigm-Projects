package Exercise;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class Inventory extends JFrame {

    private JTable inventoryTable;
    private JButton menuButton, cancelButton;
    private Connection connection;

    public Inventory(){
        super("Inventory");
        String url = "jdbc:mysql://localhost:3306/DB2";
        String user = "root";
        String password = "";

        try {
            connection = DriverManager.getConnection(url,user,password);
        } catch (SQLException e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,"Failed to connect to the database","Error",JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        JLabel tableNameLabel = new JLabel("BOOKSHOP INFORMATION SYSTEM");
        tableNameLabel.setBounds(180,5,400,30);

        JLabel inventoryLabel = new JLabel("INVENTORY");
        inventoryLabel.setBounds(250,20,400,30);

        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{"BOOK CODE", "BOOK TITLE", "BOOK TYPE",
                "BOOK PRICE", "QUANTITY", "SALES"});

        try {
            String sql = "SELECT * FROM Book";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int code = resultSet.getInt("CODE");
                String title = resultSet.getString("TITLE");
                String type = resultSet.getString("TYPE");
                int price = resultSet.getInt("PRICE");
                int quantity = resultSet.getInt("QUANTITY");
                int sales = resultSet.getInt("SALES");
                model.addRow(new Object[]{code,title,type,price,quantity,sales});
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to fetch records from the database.", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }

        inventoryTable = new JTable(model);
// Add table to scroll pane
        JScrollPane scrollPane = new JScrollPane(inventoryTable);
        scrollPane.setBounds(0,50,600,250);

        JPanel panel = new JPanel(null);
        cancelButton = new JButton("Cancel");
        cancelButton.setBounds(250,310,100,30);
        cancelButton.addActionListener(e -> {
            dispose();
        });

        menuButton = new JButton("Main Menu");
        menuButton.setBounds(100,310,130,30);
        menuButton.addActionListener(e -> {
            new MainMenu();
            dispose();
        });

        panel.add(tableNameLabel);
        panel.add(inventoryLabel);
        panel.add(scrollPane);
        panel.add(cancelButton);
        panel.add(menuButton);
// Add panel to the frame
        add(panel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 420);
        setLocationRelativeTo(null);
        setVisible(true); }
    public static void main(String[] args) {
            SwingUtilities.invokeLater(Inventory::new);
    }
}


