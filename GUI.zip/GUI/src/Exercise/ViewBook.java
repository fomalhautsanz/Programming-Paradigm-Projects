package Exercise;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ViewBook extends JFrame {
    private JTable dataTable;
    private JButton backButton;
    private Connection connection;
    public ViewBook() {
        super("VIEW BOOK");
// Database connection parameters
        String url = "jdbc:mysql://localhost:3306/DB2";
        String user = "root";
        String password = "";

        try {
            connection = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to connect to the database.", "Error",
                    JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
// Create label for table name
        JLabel tableNameLabel = new JLabel("BOOKSHOP INFORMATION SYSTEM");
        tableNameLabel.setBounds(180,5,400,30);

        JLabel inventoryLabel = new JLabel("VIEW BOOK");
        inventoryLabel.setBounds(250,20,400,30);

        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{"BOOK CODE", "BOOK TITLE", "BOOK TYPE",
        "BOOK PRICE", "QUANTITY"});

        try {
            String sql = "SELECT * FROM Book";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int code = resultSet.getInt("CODE");
                String title = resultSet.getString("TITLE");
                String type = resultSet.getString("TYPE");
                int price = resultSet.getInt("PRICE");
                int quantity = resultSet.getInt("QUANTITY");
                model.addRow(new Object[]{code,title,type,price,quantity});
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to fetch records from the database.", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }

        dataTable = new JTable(model);
// Add table to scroll pane
        JScrollPane scrollPane = new JScrollPane(dataTable);
        scrollPane.setBounds(0,50,600,250);

        JPanel panel = new JPanel(null);
        backButton = new JButton("BACK");
        backButton.setBounds(450,305,100,30);
        backButton.addActionListener(e -> {
            dispose();
            new MainMenu();
        });
        panel.add(tableNameLabel);
        panel.add(inventoryLabel);
        panel.add(scrollPane);
        panel.add(backButton);
// Add panel to the frame
        add(panel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);
        setVisible(true); }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(ViewBook::new);
    }
}


