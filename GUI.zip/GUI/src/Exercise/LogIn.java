package Exercise;

import javax.swing.*;
import java.awt.*;
import java.util.Objects;

public class LogIn {
    private JFrame mainFrame;

    public LogIn() {
        prepareGUI();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(LogIn::new);
    }

    private void prepareGUI() {
        mainFrame = new JFrame("BOOKSHOP INFORMATION SYSTEM");
        mainFrame.setSize(450, 250);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("BOOKSHOP INFORMATION SYSTEM"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;

        JLabel userLabel = new JLabel("ENTER USERNAME: ");
        JLabel passwordLabel = new JLabel("ENTER PASSWORD: ");
        final JTextField userField = new JTextField(15);
        final JPasswordField passwordField = new JPasswordField(15);

        JButton loginButton = new JButton("LOGIN");
        JButton cancelButton = new JButton("CANCEL");

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(userLabel, gbc);

        gbc.gridx = 1;
        panel.add(userField);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(passwordLabel, gbc);

        gbc.gridx = 1;
        panel.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(loginButton, gbc);

        gbc.gridx = 1;
        panel.add(cancelButton, gbc);

        loginButton.addActionListener(e -> {
            if (Objects.equals(userField.getText(), "admin") && Objects.equals(passwordField.getText(), "test")) {
                new MainMenu();
                mainFrame.dispose();
            } else {
                JOptionPane.showMessageDialog(mainFrame, "Incorrect username or password");
                userField.setText("");
                passwordField.setText("");
            }
        });

        cancelButton.addActionListener(e -> System.exit(0));

        mainFrame.add(panel);
        mainFrame.setVisible(true);
    }
}
