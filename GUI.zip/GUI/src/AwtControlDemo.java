import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class AwtControlDemo {

    // === AWT Choice Demo ===
    static class AwtControlDemoo {
        private Frame mainFrame;
        private Label headerLabel;
        private Label statusLabel;
        private Panel controlPanel;

        public AwtControlDemoo() {
            prepareGUI();
        }

        private void prepareGUI() {
            mainFrame = new Frame("Java AWT Examples");
            mainFrame.setSize(400, 400);
            mainFrame.setLayout(new GridLayout(3, 1));

            mainFrame.addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent windowEvent) {
                    System.exit(0);
                }
            });

            headerLabel = new Label();
            headerLabel.setAlignment(Label.CENTER);

            statusLabel = new Label();
            statusLabel.setAlignment(Label.CENTER);
            statusLabel.setSize(350, 100);

            controlPanel = new Panel();
            controlPanel.setLayout(new FlowLayout());

            mainFrame.add(headerLabel);
            mainFrame.add(controlPanel);
            mainFrame.add(statusLabel);
            mainFrame.setVisible(true);
        }

        public void showChoiceDemo() {
            headerLabel.setText("Control in action: Choice");

            final Choice fruitChoice = new Choice();
            fruitChoice.add("Apple");
            fruitChoice.add("Grapes");
            fruitChoice.add("Mango");
            fruitChoice.add("Peer");

            Button showButton = new Button("Show");

            showButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    String data = "Fruit Selected: " + fruitChoice.getItem(fruitChoice.getSelectedIndex());
                    statusLabel.setText(data);
                }
            });

            controlPanel.add(fruitChoice);
            controlPanel.add(showButton);
            mainFrame.setVisible(true);
        }
    }

    // === Swing Login Form ===
    static class CreateLoginForm extends JFrame implements ActionListener {
        JButton b1;
        JPanel newPanel;
        JLabel userLabel, passLabel;
        final JTextField textField1, textField2;

        CreateLoginForm() {
            userLabel = new JLabel("Username");
            textField1 = new JTextField(15);

            passLabel = new JLabel("Password");
            textField2 = new JPasswordField(15);

            b1 = new JButton("SUBMIT");

            newPanel = new JPanel(new GridLayout(3, 1));
            newPanel.add(userLabel);
            newPanel.add(textField1);
            newPanel.add(passLabel);
            newPanel.add(textField2);
            newPanel.add(b1);

            add(newPanel, BorderLayout.CENTER);
            b1.addActionListener(this);
            setTitle("LOGIN FORM");
        }

        public void actionPerformed(ActionEvent ae) {
            String userValue = textField1.getText();
            String passValue = textField2.getText();

            if (userValue.equals("test") && passValue.equals("test")) {
                NewPage page = new NewPage();
                page.setVisible(true);
                JLabel wel_label = new JLabel("Welcome: " + userValue);
                page.getContentPane().add(wel_label);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Please enter valid username and password");
            }
        }
    }

    // === Success Page ===
    static class NewPage extends JFrame {
        NewPage() {
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            setTitle("Welcome");
            setSize(400, 200);
        }
    }

    // === Main Launcher ===
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            CreateLoginForm loginForm = new CreateLoginForm();
            loginForm.setSize(300, 100);
            loginForm.setVisible(true);
        });

        EventQueue.invokeLater(() -> {
            AwtControlDemoo demo = new AwtControlDemoo();
            demo.showChoiceDemo();
        });
    }
}
