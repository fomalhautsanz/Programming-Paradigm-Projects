package SampleSystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateDatabaseAndTable {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/";
        String user = "root";
        String password = "";

        try (Connection connection = DriverManager.getConnection(url, user, password);
             Statement statement = connection.createStatement()) {

            String sqlCreateDB = "CREATE DATABASE IF NOT EXISTS db4";
            statement.executeUpdate(sqlCreateDB);
            System.out.println("Database created successfully");

            String sqlUseDB = "USE db4";
            statement.executeUpdate(sqlUseDB);
            System.out.println("Switched to database db4");

            String sqlCreateTable = "CREATE TABLE IF NOT EXISTS student (" +
                    "id INT NOT NULL," +
                    "name VARCHAR(250) NOT NULL," +
                    "password VARCHAR(250)," +
                    "PRIMARY KEY(id))";
            statement.executeUpdate(sqlCreateTable);
            System.out.println("Table 'student' created successfully");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

