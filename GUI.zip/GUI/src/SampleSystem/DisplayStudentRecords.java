package SampleSystem;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class DisplayStudentRecords extends JFrame {
    private JTable dataTable;
    private Connection connection;

    public DisplayStudentRecords() {
        super("Display Student Records");

        String url = "jdbc:mysql://localhost:3306/db4";
        String user = "root";
        String password = "";

        try {
            connection = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to connect to the database.", "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        JLabel tableNameLabel = new JLabel("Student Table");
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{"ID", "Name", "Password"});

        try {
            String sql = "SELECT * FROM student";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String password1 = resultSet.getString("password");
                model.addRow(new Object[]{id, name, password1});
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to fetch records from the database.", "Error", JOptionPane.ERROR_MESSAGE);
        }

        dataTable = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(dataTable);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(tableNameLabel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        add(panel);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(DisplayStudentRecords::new);
    }
}

