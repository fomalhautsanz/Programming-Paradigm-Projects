package SampleSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class StudentDataEntry extends JFrame implements ActionListener {
    private JTextField idField, nameField, passwordField;
    private JButton submitButton;
    private Connection connection;
    private Statement statement;

    public StudentDataEntry() {
        super("Student Data Entry");

        String url = "jdbc:mysql://localhost:3306/db4";
        String user = "root";
        String password = "";

        try {
            connection = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to connect to the database.", "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        idField = new JTextField(10);
        nameField = new JTextField(10);
        passwordField = new JTextField(10);
        submitButton = new JButton("Submit");
        submitButton.addActionListener(this);

        JPanel inputPanel = new JPanel(new GridLayout(4, 2));
        inputPanel.add(new JLabel("ID:"));
        inputPanel.add(idField);
        inputPanel.add(new JLabel("Name:"));
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Password:"));
        inputPanel.add(passwordField);
        inputPanel.add(submitButton);

        add(inputPanel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitButton) {
            int id = Integer.parseInt(idField.getText());
            String name = nameField.getText();
            String password = passwordField.getText();

            try {
                statement = connection.createStatement();
                String sql = "INSERT INTO student (id, name, password) VALUES (" + id + ", '" + name + "', '" + password + "')";
                statement.executeUpdate(sql);
                JOptionPane.showMessageDialog(this, "Data inserted successfully.");
                new AnotherFrame();
                dispose();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Failed to insert data into the database.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(StudentDataEntry::new);
    }
}

class AnotherFrame extends JFrame {
    public AnotherFrame() {
        super("Confirmation");
        add(new JLabel("You have successfully inserted the record!"));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 100);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}

