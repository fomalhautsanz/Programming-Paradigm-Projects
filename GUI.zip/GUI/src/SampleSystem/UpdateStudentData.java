package SampleSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class UpdateStudentData extends JFrame implements ActionListener {
    private JTextField idField, nameField, passwordField;
    private JButton updateButton;
    private Connection connection;

    public UpdateStudentData() {
        super("Update Student Record");

        String url = "jdbc:mysql://localhost:3306/db4";
        String user = "root";
        String password = "";

        try {
            connection = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to connect to the database.", "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        idField = new JTextField(10);
        nameField = new JTextField(10);
        passwordField = new JTextField(10);
        updateButton = new JButton("Update");
        updateButton.addActionListener(this);

        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.add(new JLabel("ID to update:"));
        panel.add(idField);
        panel.add(new JLabel("New Name:"));
        panel.add(nameField);
        panel.add(new JLabel("New Password:"));
        panel.add(passwordField);
        panel.add(updateButton);

        add(panel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == updateButton) {
            int id = Integer.parseInt(idField.getText());
            String newName = nameField.getText();
            String newPassword = passwordField.getText();

            try {
                String sql = "UPDATE student SET name = ?, password = ? WHERE id = ?";
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1, newName);
                preparedStatement.setString(2, newPassword);
                preparedStatement.setInt(3, id);
                int rows = preparedStatement.executeUpdate();

                if (rows > 0) {
                    JOptionPane.showMessageDialog(this, "Record updated successfully.");
                } else {
                    JOptionPane.showMessageDialog(this, "Record not found.");
                }

            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error updating record.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(UpdateStudentData::new);
    }
}

