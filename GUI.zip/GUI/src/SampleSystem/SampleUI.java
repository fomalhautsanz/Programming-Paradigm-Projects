package SampleSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class SampleUI {

    private JFrame mainFrame;
    private JLabel headerLabel;
    private JPanel controlPanel;

    public SampleUI(){
        prepareGUI();
    }

    public static void main(String[] args) {
        SampleUI sampleUI = new SampleUI();
        sampleUI.showButtonDemo();
    }

    private void prepareGUI(){
        mainFrame = new JFrame("GUI Exercise");
        mainFrame.setSize(400,400);
        mainFrame.setLayout(new BorderLayout());

        mainFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        headerLabel = new JLabel("SYSTEM MENU",JLabel.CENTER);
        headerLabel.setFont(new Font("Arial",Font.BOLD,18));
        headerLabel.setBorder(BorderFactory.createEmptyBorder(20,0,20,0));

        controlPanel = new JPanel();
        controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.Y_AXIS));
        controlPanel.setBorder(BorderFactory.createEmptyBorder(10,100,10,100));
        controlPanel.setSize(400,400);

        mainFrame.add(headerLabel, BorderLayout.NORTH);
        mainFrame.add(controlPanel, BorderLayout.CENTER);
        mainFrame.setVisible(true);
    }

    private void showButtonDemo(){
        JButton config = new JButton("Configure");
        JButton add = new JButton("Add");
        JButton display = new JButton("Display");
        JButton update = new JButton("Update");
        JButton delete = new JButton("Delete");

        Dimension buttonSize = new Dimension(150, 30); // set consistent button size
        JButton[] buttons = { config, add, display, update, delete };
        for (JButton button : buttons) {
            button.setMaximumSize(buttonSize); // set fixed size
            button.setAlignmentX(Component.CENTER_ALIGNMENT); // center the button
            controlPanel.add(button);
            controlPanel.add(Box.createRigidArea(new Dimension(0, 15))); // add vertical spacing
        }

        config.addActionListener(e -> new CreateDatabaseAndTable());
        add.addActionListener(e -> new StudentDataEntry());
        display.addActionListener(e -> new DisplayStudentRecords());
        update.addActionListener(e -> new UpdateStudentData());
        delete.addActionListener(e -> new DeleteStudentData());

        mainFrame.revalidate();
        mainFrame.repaint();
    }
}
