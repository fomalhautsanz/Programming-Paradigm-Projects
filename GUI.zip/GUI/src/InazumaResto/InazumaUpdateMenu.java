package InazumaResto;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InazumaUpdateMenu extends JFrame implements ActionListener {

    private JTextField idField, nameField, priceField;
    private JButton updateButton;
    private Connection connection;

    public InazumaUpdateMenu(){
        super("Update Menu");

        String url = "jdbc:mysql://localhost:3306/inazumaDB";
        String user = "root";
        String password = "";

        try {
            connection = DriverManager.getConnection(url,user,password);
        } catch (SQLException e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,"Failed to connect to the database","Error",JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        idField = new JTextField(10);
        nameField = new JTextField(10);
        priceField = new JTextField(10);
        updateButton = new JButton("Update");
        updateButton.addActionListener(this);

        JPanel panel = new JPanel(new GridLayout(4,2));
        panel.add(new JLabel("Dish ID to update: "));
        panel.add(idField);
        panel.add(new JLabel("New Dish Name: "));
        panel.add(nameField);
        panel.add(new JLabel("New Price: "));
        panel.add(priceField);
        panel.add(updateButton);

        add(panel);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(300,200);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == updateButton){
            int id = Integer.parseInt(idField.getText());
            String name = nameField.getText();
            int price = Integer.parseInt(priceField.getText());

            try {
                String sql = "UPDATE inazumaTable SET FOOD_NAME = ?, FOOD_PRICE = ? WHERE FOOD_ID = ?";
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1,name);
                preparedStatement.setInt(2,price);
                preparedStatement.setInt(3,id);
                int rows = preparedStatement.executeUpdate();

                if(rows>0){
                    JOptionPane.showMessageDialog(this,"Menu updated successfully");
                }
                else {
                    JOptionPane.showMessageDialog(this,"Record not found");
                }

                dispose();
            } catch (SQLException ex){
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this,"Error updating menu","Error",JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(InazumaUpdateMenu::new);
    }
}
