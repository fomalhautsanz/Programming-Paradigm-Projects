package InazumaResto;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Objects;

public class InazumaMenuUI {

    private JFrame mainFrame;
    private JLabel headerLabel,japanlabel,logo;
    private JPanel controlPanel;

    private void prepareGUI(){
        mainFrame = new JFrame("Inazuma Resutoran");
        mainFrame.setSize(400,490);
        mainFrame.setLayout(new BorderLayout());

        mainFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        ImageIcon imageIcon = new ImageIcon(Objects.requireNonNull(InazumaMenuUI.class.getResource("inazuma.png")));
        Image scaledImage = imageIcon.getImage().getScaledInstance(90, 100, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon = new ImageIcon(scaledImage);

        logo = new JLabel(resizedIcon);
        logo.setSize(30,30);
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);

        headerLabel = new JLabel("INAZUMA RESUTORAN",JLabel.CENTER);
        headerLabel.setFont(new Font("Meiryo", Font.BOLD, 24));
        headerLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        japanlabel = new JLabel("稲妻城",JLabel.CENTER);
        japanlabel.setFont(new Font("Meiryo", Font.BOLD, 18));
        japanlabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        headerPanel.add(logo);
        headerPanel.add(headerLabel);
        headerPanel.add(japanlabel);

        controlPanel = new JPanel();
        controlPanel.setLayout(new BoxLayout(controlPanel,BoxLayout.Y_AXIS));
        controlPanel.setBorder(BorderFactory.createEmptyBorder(10,100,10,100));
        controlPanel.setSize(400,400);

        mainFrame.add(headerPanel,BorderLayout.NORTH);
        mainFrame.add(controlPanel,BorderLayout.CENTER);
        mainFrame.setVisible(true);
    }

    private void showButtonDemo(){

        JButton config = new JButton("Configure Menu");
        JButton add = new JButton("Add Dish");
        JButton display = new JButton("Display Menu");
        JButton update = new JButton("Update Menu");
        JButton delete = new JButton("Delete Dish");

        Dimension buttonSize = new Dimension(150,30);
        JButton[] buttons = {config,add,display,update,delete};
        Font moderFont = new Font("Meiryo",Font.BOLD,14);

        for (JButton button:buttons){
            button.setMaximumSize(buttonSize);
            button.setPreferredSize(buttonSize);
            button.setOpaque(true);
            button.setBackground(new Color(105,36,124));
            button.setForeground(Color.white);
            button.setFont(moderFont);
            button.setFocusPainted(false);
            button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            button.setAlignmentX(Component.CENTER_ALIGNMENT);
            controlPanel.add(button);
            controlPanel.add(Box.createRigidArea(new Dimension(0,15)));
        }

        config.addActionListener(e -> new InazumaCreateDatabase());
        add.addActionListener(e -> new InazumaAddDish());
        display.addActionListener(e -> new InazumaDisplayMenu());
        update.addActionListener(e -> new InazumaUpdateMenu());
        delete.addActionListener(e -> new InazumaDeleteDish());

        mainFrame.revalidate();
        mainFrame.repaint();
    }

    public static void main(String[] args) {
        InazumaMenuUI ui = new InazumaMenuUI();
        ui.prepareGUI();
        ui.showButtonDemo();
    }
}
