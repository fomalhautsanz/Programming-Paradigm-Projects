package InazumaResto;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class InazumaAddDish extends JFrame implements ActionListener {

    private JTextField foodId, foodName, foodPrice;
    private JButton submitButton;
    private Connection connection;
    private Statement statement;

    public InazumaAddDish(){
        super("Add Dish");

        String url = "jdbc:mysql://localhost:3306/inazumaDB";
        String user = "root";
        String password = "";

        try {
            connection = DriverManager.getConnection(url,user,password);

        } catch (SQLException e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,"Failed to connect to the database","Error",JOptionPane.ERROR_MESSAGE);
        }

        foodId = new JTextField(10);
        foodName = new JTextField(10);
        foodPrice = new JTextField(10);
        submitButton = new JButton("Submit");
        submitButton.addActionListener(this);

        JPanel inputPanel = new JPanel(new GridLayout(4,2));
        inputPanel.add(new JLabel("Food ID: "));
        inputPanel.add(foodId);
        inputPanel.add(new JLabel("Specialty Name: "));
        inputPanel.add(foodName);
        inputPanel.add(new JLabel("Price: "));
        inputPanel.add(foodPrice);
        inputPanel.add(submitButton);

        add(inputPanel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300,300);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitButton){
            int id = Integer.parseInt(foodId.getText());
            String name = foodName.getText();
            int price = Integer.parseInt(foodPrice.getText());

            try {
                statement = connection.createStatement();
                String sql = "INSERT INTO inazumaTable (FOOD_ID, FOOD_NAME, FOOD_PRICE) VALUES " +
                        "( " + id + ", '" + name + "', " + price + ")";

                statement.executeUpdate(sql);
                JOptionPane.showMessageDialog(this,"Data inserted successfully");
                new AnotherFrame();
                dispose();
            } catch (SQLException ex){
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this,"Failed to insert data into the database","Error",JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(InazumaAddDish::new);
    }

    class AnotherFrame extends JFrame{
        public AnotherFrame(){
            super("Confirmation");
            add(new JLabel("Dish have been successfully added to the menu!"));
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setSize(300,300);
            setLocationRelativeTo(null);
            setVisible(true);
        }
    }
}
