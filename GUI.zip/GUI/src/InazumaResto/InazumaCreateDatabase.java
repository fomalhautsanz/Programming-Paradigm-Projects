package InazumaResto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class InazumaCreateDatabase {
    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/";
        String user = "root";
        String password = "";

        try (Connection connection = DriverManager.getConnection(url,user,password);
             Statement statement = connection.createStatement()){

            statement.executeUpdate("DROP DATABASE IF EXISTS inazumaDB");
            statement.executeUpdate("CREATE DATABASE inazumaDB");
            statement.executeUpdate("USE inazumaDB");

            System.out.println("Database inazumaDB created successfully!");

            statement.executeUpdate("CREATE TABLE IF NOT EXISTS inazumaTable (" +
                    "FOOD_ID int PRIMARY KEY, FOOD_NAME varchar(250), FOOD_PRICE int)");

            System.out.println("Table created successfully!");

        } catch (SQLException e){
            e.printStackTrace();
        }
    }
}
