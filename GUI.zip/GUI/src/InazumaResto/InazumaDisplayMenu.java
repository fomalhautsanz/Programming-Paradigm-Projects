package InazumaResto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.Stack;

public class InazumaDisplayMenu extends JFrame{
    private JTable menuTable;
    private Connection connection;

    public InazumaDisplayMenu(){
        super("Display Menu");

        String url = "jdbc:mysql://localhost:3306/inazumaDB";
        String user = "root";
        String password = "";

        try {
            connection = DriverManager.getConnection(url,user,password);
        } catch (SQLException e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,"Failed to connect to the database","Error",JOptionPane.ERROR_MESSAGE);
        }

        JLabel menuTableName = new JLabel("Inazuma Special Menu");
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{"Food ID","Specialty Name","Price"});

        try{
            String sql = "SELECT * FROM inazumaTable";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()){
                int id = resultSet.getInt("FOOD_ID");
                String name = resultSet.getString("FOOD_NAME");
                int price = resultSet.getInt("FOOD_PRICE");
                model.addRow(new Object[]{id,name,price});
            }
            dispose();
        } catch (SQLException e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,"Failed to fetch records from the database","Error",JOptionPane.ERROR_MESSAGE);
        }

        menuTable = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(menuTable);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(menuTableName,BorderLayout.NORTH);
        panel.add(scrollPane,BorderLayout.CENTER);
        add(panel);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600,400);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(InazumaDisplayMenu::new);
    }
}
