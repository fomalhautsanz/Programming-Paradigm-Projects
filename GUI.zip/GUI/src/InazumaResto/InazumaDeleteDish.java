package InazumaResto;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InazumaDeleteDish extends JFrame implements ActionListener {
    private JTextField idField;
    private JButton deleteButton;
    private Connection connection;

    public InazumaDeleteDish(){
        super("Delete Dish from Menu");

        String url = "jdbc:mysql://localhost:3306/inazumaDB";
        String user = "root";
        String password = "";

        try {
            connection = DriverManager.getConnection(url,user,password);
        } catch (SQLException e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,"Failed to connect to the database","Error",JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        idField = new JTextField(10);
        deleteButton = new JButton("Delete");
        deleteButton.addActionListener(this);

        JPanel panel = new JPanel(new GridLayout(2,2));
        panel.add(new JLabel("Enter dish ID to delete: "));
        panel.add(idField);
        panel.add(deleteButton);

        add(panel);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(300,120);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == deleteButton){
            int id = Integer.parseInt(idField.getText());

            try {
                String sql = "DELETE FROM inazumaTable WHERE FOOD_ID = ?";
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setInt(1,id);
                int rows = preparedStatement.executeUpdate();

                if (rows > 0){
                    JOptionPane.showMessageDialog(this,"Record deleted successfully");
                }
                else {
                    JOptionPane.showMessageDialog(this,"Record not found");
                }
                dispose();
            } catch (SQLException ex){
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this,"Error deleting record","Error",JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(InazumaDeleteDish::new);
    }
}
