import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Objects;

public class LogInSystem implements ActionListener {

    private static JLabel userText = new JLabel("Username");
    private static JLabel passText = new JLabel("Password");
    private static JLabel title = new JLabel("Vintage Diaries");
    public static JTextField userField = new JTextField(20);
    private static JPasswordField passwordField = new JPasswordField();
    private static JButton login = new JButton();
    public static JLabel success = new JLabel("");

    public static void main(String[] args) {

        JPanel panel = new JPanel();
        JFrame frame = new JFrame("Vintage Diaries");
        frame.setSize(450,450);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.add(panel);
        panel.setLayout(null);
        panel.setBackground(new Color(251,228,214));

        title.setBounds(120,160,250,40);
        title.setFont(new Font("Lucida Handwriting",Font.BOLD,20));

        userText.setBounds(80,200,80,25);
        userText.setFont(new Font("Lucida Handwriting", Font.BOLD, 12));
        userField.setBounds(170,200,165,25);

        passText.setBounds(80,230,80,25);
        passText.setFont(new Font("Lucida Handwriting", Font.BOLD, 12));
        passwordField.setBounds(170,230,165,25);

        login.setText("Login");
        login.setBounds(170,280,95,30);
        login.addActionListener(new LogInSystem());

        success.setBounds(80,350,300,25);
        success.setFont(new Font("Lucida Handwriting",Font.BOLD,12));

        ImageIcon image = new ImageIcon(Objects.requireNonNull(LogInSystem.class.getResource("diary.png")));
        JLabel displayImg = new JLabel(image);
        displayImg.setBounds(160,30,123,117);

        panel.add(displayImg);
        panel.add(title);
        panel.add(userText);
        panel.add(userField);
        panel.add(passText);
        panel.add(passwordField);
        panel.add(login);
        panel.add(success);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String user = userField.getText();
        String pass = passwordField.getText();

        if (user.equals("sparkling_tangerine") && pass.equals("asdfghjkl")){
            PartOne home = new PartOne();

            home.home();
        }
        else {
            success.setText("Invalid username or password. Try again.");
            success.setForeground(new Color(164,44,44));
        }
    }
}
