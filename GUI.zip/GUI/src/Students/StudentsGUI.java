package Students;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class StudentsGUI extends JFrame{

    private JTextField idField, nameField, ageField, genderField;
    private DefaultTableModel tableModel;
    private JTable studentTable;
    private StudentsDatabase studentsDatabase;

    public StudentsGUI(){
        studentsDatabase = new StudentsDatabase();
        studentsDatabase.createDatabase();
        studentsDatabase.connectToDB();

        String[] names = {"Marcus Tale", "Leah Green", "Jordan Sparks", "Emily White", "Noah Gray", "Chloe Black", "Daniel Stone", "Ava Silver"};
        String[] genders = {"Male", "Female"};
        int[] ages = {18, 19, 20, 21, 22};

        for (int i = 0; i < 20; i++) {
            int id = 3000 + (int)(Math.random() * 1000);  // random ID between 3000 and 3999
            String name = names[(int)(Math.random() * names.length)];
            String gender = genders[(int)(Math.random() * genders.length)];
            int age = ages[(int)(Math.random() * ages.length)];

            Students randomStudent = new Students(id, name, age, gender);
            studentsDatabase.addStudent(randomStudent);
        }

        setTitle("Student Management System");
        setSize(600,400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(5,2));
        idField = new JTextField();
        nameField = new JTextField();
        ageField = new JTextField();
        genderField = new JTextField();
        JButton addButton = new JButton("Add Student");

        inputPanel.add(new JLabel("Student ID: "));
        inputPanel.add(idField);

        inputPanel.add(new JLabel("Name: "));
        inputPanel.add(nameField);

        inputPanel.add(new JLabel("Age: "));
        inputPanel.add(ageField);

        inputPanel.add(new JLabel("Gender: "));
        inputPanel.add(genderField);

        inputPanel.add(addButton);

        inputPanel.add(new JLabel(""));

        add(inputPanel, BorderLayout.NORTH);

        String[] header = {"Student ID", "Name", "Age", "Gender"};
        tableModel = new DefaultTableModel(header,0);
        studentTable = new JTable(tableModel);
        add(new JScrollPane(studentTable), BorderLayout.CENTER);

        addButton.addActionListener(e -> {
            try {
                Students students = new Students(
                        Integer.parseInt(idField.getText()),
                        nameField.getText(),
                        Integer.parseInt(ageField.getText()),
                        genderField.getText()
                );

                studentsDatabase.addStudent(students);
                loadStudents();
                clearFields();

            } catch (Exception ex){
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        loadStudents();
    }

    private void loadStudents(){
        try{
            List<Students> students = studentsDatabase.getAllStudents();
            tableModel.setRowCount(0);

            for (Students s : students){
               Object[] row = {
                       s.getId(),
                       s.getName(),
                       s.getAge(),
                       s.getGender()
               };
               tableModel.addRow(row);
            }
        } catch (Exception e){
            JOptionPane.showMessageDialog(this,"Error loading students");
        }
    }

    private void clearFields(){
        idField.setText("");
        nameField.setText("");
        ageField.setText("");
        genderField.setText("");
    }
}

class Main{
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            StudentsGUI studentsGUI = new StudentsGUI();
            studentsGUI.setVisible(true);
        });
    }
}
