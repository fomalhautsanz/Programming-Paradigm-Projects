package Students;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentsDatabase {
    Connection connection;

    private void SQLErrors(SQLException e){
        System.out.println("SQL Exception: " + e.getMessage());
        System.out.println("SQL State: " + e.getSQLState());
        System.out.println("Vendor Error: " + e.getErrorCode());
    }

    public  StudentsDatabase(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Connected successfully!");
            System.out.println();
        } catch (Exception e){
            System.err.println("Unable to find and load driver");
            System.exit(1);
        }
    }

    public void connectToDB(){
        try{
            connection = DriverManager.getConnection
                    ("jdbc:mysql://localhost:3306/studentdb","root","");
        } catch (SQLException e) {
            SQLErrors(e);
        }
    }

    public void createDatabase(){
        try{
            connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","");
            Statement statement = connection.createStatement();

            statement.executeUpdate("DROP DATABASE IF EXISTS studentdb");
            statement.executeUpdate("CREATE DATABASE studentdb");
            statement.executeUpdate("USE studentdb");


            statement.executeUpdate
                    ("CREATE TABLE Students (STUDENT_ID int PRIMARY KEY, NAME varchar(25), AGE int(11), " +
                            "GENDER varchar(25));");

            statement.close();
            connection.close();

        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    public void addStudent(Students student){

        String sql = "INSERT INTO Students VALUES (?, ?, ?, ?)";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            /*statement.executeUpdate("INSERT INTO Students VALUES (9870, 'Marcus Tale', 18, 'Male')");
            statement.executeUpdate("INSERT INTO Students VALUES (3124, 'Leah Green', 18, 'Female')");
            statement.executeUpdate("INSERT INTO Students VALUES (0574, 'Samantha Klaus', 19, 'Female')");
            statement.executeUpdate("INSERT INTO Students VALUES (1690, 'Donnie Heath', 19, 'Male')");
            statement.executeUpdate("INSERT INTO Students VALUES (4065, 'Valerie Samuels', 19, 'Female')");*/

            preparedStatement.setInt(1, student.getId());
            preparedStatement.setString(2, student.getName());
            preparedStatement.setInt(3, student.getAge());
            preparedStatement.setString(4, student.getGender());
            preparedStatement.executeUpdate();
            preparedStatement.close();

        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    public List<Students> getAllStudents(){
        String sql = "SELECT * FROM Students";
        List<Students> students = new ArrayList<>();

        try {
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(sql);

            while (rs.next()){
                students.add(new Students(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getInt(3),
                        rs.getString(4)
                ));
            }

            statement.close();
            rs.close();
        } catch (SQLException e){
            SQLErrors(e);
        }

        return students;
    }

}
