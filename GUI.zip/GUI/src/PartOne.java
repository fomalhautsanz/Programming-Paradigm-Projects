import javax.swing.*;
import java.awt.*;
import java.util.Objects;

public class PartOne {
    void home() {
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(251,228,214));

        ImageIcon image = new ImageIcon(Objects.requireNonNull(getClass().getResource("cat.png")));
        JLabel displayImg = new JLabel(image);
        displayImg.setBounds(160,230,113,110);
        panel.add(displayImg);


        JLabel welcome = new JLabel("<html><body style='width: 300px;'>Welcome to Vintage Diaries, " +
                LogInSystem.userField.getText() +
                "!<br>Here you can express yourself freely and find <br> solace in our therapeutic environment.</body></html>");
        welcome.setBounds(40,120,400,100);
        welcome.setFont(new Font("Lucida Handwriting", Font.BOLD, 12));

        panel.add(welcome);

        JFrame frame = new JFrame("Vintage Diaries");
        frame.setSize(450,450);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);
        frame.setVisible(true);
    }
}
