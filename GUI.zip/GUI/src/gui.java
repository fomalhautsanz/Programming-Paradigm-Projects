import javax.swing.*;
import java.awt.*;
import javax.swing.border.LineBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class gui {
    public static void main(String[] args) {

        JFrame frame = new JFrame("Shop");
        JPanel panel = new JPanel(null);
        JLabel label1 = new JLabel();
        JLabel label2 = new JLabel();
        JLabel label3 = new JLabel();
        JLabel label4 = new JLabel();
        JLabel label5 = new JLabel();
        JButton button1 = new JButton();
        JButton button2 = new JButton();
        JButton button3 = new JButton();
        JTextField textField1 = new JTextField();
        JTextField textField2 = new JTextField();
        JTextField textField3 = new JTextField();
        JTextField textField4 = new JTextField();

        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.setBorder(BorderFactory.createCompoundBorder(panel.getBorder(),
                new LineBorder(Color.BLACK, 2)));

        button1.setBounds(45, 50, 67, 5);
        button1.setBackground(new Color(46, 108, 156));

        label1.setBounds(45, 20, 120, 30);
        label1.setText("Add Product");
        label1.setFont(new Font("Arial", Font.PLAIN, 18));
        label1.setForeground(Color.BLACK);

        label2.setBounds(45, 80, 120, 30);
        label2.setText("Product Code:");
        label2.setFont(new Font("Arial", Font.PLAIN, 17));
        label2.setForeground(Color.BLACK);

        label3.setBounds(45, 145, 120, 30);
        label3.setText("Name:");
        label3.setFont(new Font("Arial", Font.PLAIN, 17));
        label3.setForeground(Color.BLACK);

        textField1.setBounds(45, 110, 300, 25);
        textField1.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        textField2.setBounds(45, 175, 300, 25);
        textField2.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        label4.setBounds(45, 210, 120, 30);
        label4.setText("Quantity:");
        label4.setFont(new Font("Arial", Font.PLAIN, 17));
        label4.setForeground(Color.BLACK);

        textField3.setBounds(45, 240, 300, 25);
        textField3.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        label5.setBounds(45, 275, 120, 30);
        label5.setText("Price:");
        label5.setFont(new Font("Arial", Font.PLAIN, 17));
        label5.setForeground(Color.BLACK);

        textField4.setBounds(45, 305, 300, 25);
        textField4.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        button2.setBounds(100, 375, 80, 35);
        button2.setBackground(new Color(46, 108, 156));
        button2.setFocusPainted(false);
        button2.setForeground(Color.WHITE);
        button2.setText("Add");

        button3.setBounds(200, 375, 80, 35);
        button3.setBackground(Color.WHITE);
        button3.setForeground(new Color(46, 108, 156));
        button3.setBorder(BorderFactory.createLineBorder(new Color(46, 108, 156), 2));
        button3.setFocusPainted(false);
        button3.setText("Back");

        panel.add(label1); panel.add(button1); panel.add(label2); panel.add(textField1);
        panel.add(label3); panel.add(textField2); panel.add(label4); panel.add(textField3);
        panel.add(label5); panel.add(textField4); panel.add(button2); panel.add(button3);


        button2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, "Product added!", null, JOptionPane.INFORMATION_MESSAGE);
                textField1.setText("");
                textField2.setText("");
                textField3.setText("");
                textField4.setText("");
            }
        });

        frame.add(panel);
        frame.setSize(400, 500);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
