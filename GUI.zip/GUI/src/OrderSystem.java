import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class OrderSystem extends JFrame {
    private JRadioButton item1, item2, item3;
    private JSpinner qty1, qty2, qty3;
    private JLabel totalLabel;
    private JButton orderButton;

    private final double price1 = 10.0;
    private final double price2 = 15.0;
    private final double price3 = 20.0;

    public OrderSystem() {
        setTitle("Simple Order System");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(5, 1));

        // Item 1
        JPanel panel1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        item1 = new JRadioButton("Item 1 ($10.00)");
        qty1 = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
        panel1.add(item1);
        panel1.add(new JLabel("Quantity:"));
        panel1.add(qty1);
        add(panel1);

        // Item 2
        JPanel panel2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        item2 = new JRadioButton("Item 2 ($15.00)");
        qty2 = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
        panel2.add(item2);
        panel2.add(new JLabel("Quantity:"));
        panel2.add(qty2);
        add(panel2);

        // Item 3
        JPanel panel3 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        item3 = new JRadioButton("Item 3 ($20.00)");
        qty3 = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
        panel3.add(item3);
        panel3.add(new JLabel("Quantity:"));
        panel3.add(qty3);
        add(panel3);

        // Order Button
        orderButton = new JButton("Place Order");
        orderButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                placeOrder();
            }
        });
        add(orderButton);

        // Total Label
        totalLabel = new JLabel("Total: $0.00");
        totalLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(totalLabel);

        setVisible(true);
    }

    private void placeOrder() {
        double total = 0.0;
        StringBuilder orderDetails = new StringBuilder();

        if (item1.isSelected()) {
            int quantity = (Integer) qty1.getValue();
            total += price1 * quantity;
            orderDetails.append("Item 1 x").append(quantity).append("\n");
        }
        if (item2.isSelected()) {
            int quantity = (Integer) qty2.getValue();
            total += price2 * quantity;
            orderDetails.append("Item 2 x").append(quantity).append("\n");
        }
        if (item3.isSelected()) {
            int quantity = (Integer) qty3.getValue();
            total += price3 * quantity;
            orderDetails.append("Item 3 x").append(quantity).append("\n");
        }

        totalLabel.setText(String.format("Total: $%.2f", total));

        // Save order to database
        saveOrderToDatabase(orderDetails.toString(), total);
    }

    private void saveOrderToDatabase(String orderDetails, double total) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:sqlite:orders.db");
            Statement stmt = conn.createStatement();
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY AUTOINCREMENT, details TEXT, total REAL)");
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO orders (details, total) VALUES (?, ?)");
            pstmt.setString(1, orderDetails);
            pstmt.setDouble(2, total);
            pstmt.executeUpdate();
            pstmt.close();
            stmt.close();
            conn.close();
            JOptionPane.showMessageDialog(this, "Order placed successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving order to database.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new OrderSystem());
    }
}
