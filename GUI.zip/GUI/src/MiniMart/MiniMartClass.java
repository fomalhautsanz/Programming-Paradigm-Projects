package MiniMart;

public class MiniMartClass {
    private int productCode;
    private String productName;
    private int productPrice;
    private int quantity;

    public int getProductCode() {
        return productCode;
    }

    public String getProductName() {
        return productName;
    }

    public int getProductPrice() {
        return productPrice;
    }

    public int getQuantity() {
        return quantity;
    }
}
