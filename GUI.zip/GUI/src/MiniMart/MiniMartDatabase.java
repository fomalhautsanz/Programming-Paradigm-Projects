package MiniMart;

import java.sql.*;

public class MiniMartDatabase {
    Connection connection;

    private void SQLErrors(SQLException e){
        System.out.println("SQL Exception: " + e.getMessage());
        System.out.println("SQL State: " + e.getSQLState());
        System.out.println("Vendor Error: " + e.getErrorCode());
    }

    public MiniMartDatabase(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Connected successfully!");
            System.out.println();
        } catch (Exception e){
            System.err.println("Unable to find and load driver");
            System.exit(1);
        }
    }

    public void connectToDB(){
        try {
            connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/miniMartDB","root",""
            );
        } catch (SQLException e) {
            SQLErrors(e);
        }
    }

    public void createDatabase(){
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","");
            Statement statement = connection.createStatement();

            statement.executeUpdate("DROP DATABASE IF EXISTS miniMartDB");
            statement.executeUpdate("CREATE DATABASE miniMartDB");
            statement.executeUpdate("USE miniMartDB");

            statement.executeUpdate("CREATE TABLE Products (PRODUCT_CODE int PRIMARY KEY, PRODUCT_NAME varchar(25), " +
                    "PRODUCT_PRICE int (11), PRODUCT_QUANTITY int (11));");

            statement.close();
            connection.close();
        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    public void addProduct(MiniMartClass product){

        String sql = "INSERT INTO Products VALUES (?, ?, ?, ?)";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, product.getProductCode());
            preparedStatement.setString(2,product.getProductName());
            preparedStatement.setInt(3, product.getProductPrice());
            preparedStatement.setInt(4, product.getQuantity());
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException e){
            SQLErrors(e);
        }
    }


    public void updateProduct(MiniMartClass product){
        String sql = "UPDATE Products SET PRODUCT_NAME = ?, PRODUCT_PRICE = ?, PRODUCT_QUANTITY = ? WHERE PRODUCT_CODE = ?";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1,product.getProductName());
            preparedStatement.setInt(2, product.getProductPrice());
            preparedStatement.setInt(3, product.getQuantity());
            preparedStatement.setInt(4, product.getProductCode());
        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    public void deleteProduct(MiniMartClass product){
        String sql = "DELETE FROM Products WHERE PRODUCT_CODE = ?";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, product.getProductCode());
            int rowsAffected = preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException e){
            SQLErrors(e);
        }
    }
}
