package CoffeeShop;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CoffeeCreateDB {
    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/";
        String user = "root";
        String password = "";

        try (Connection connection = DriverManager.getConnection(url,user,password);
             Statement statement = connection.createStatement()){

            statement.executeUpdate("DROP DATABASE IF EXISTS coffeeDB");
            statement.executeUpdate("CREATE DATABASE coffeeDB");
            statement.executeUpdate("USE coffeeDB");

            System.out.println("Database coffeeDB has been created successfully!");

            statement.executeUpdate("CREATE TABLE IF NOT EXISTS coffee (" +
                    "COFFEE_ID int PRIMARY_KEY, COFFEE_NAME varchar(250), COFFEE_PRICE int)");

            System.out.println("Table created successfully!");
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
}
