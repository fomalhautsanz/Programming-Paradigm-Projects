package CoffeeShop;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class CoffeeOrder extends JFrame {

    private JRadioButton item1, item2, item3, item4;
    private JSpinner qty1, qty2, qty3, qty4;
    private JLabel totalLabel;
    private JButton orderButton;

    private final double price1 = 10.0;
    private final double price2 = 12.0;
    private final double price3 = 9.0;
    private final double price4 = 14.0;

    public CoffeeOrder(){
        setTitle("Coffee Order System");
        setSize(400,300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(6,1));

        JPanel panel1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        item1 = new JRadioButton("Cappuccino ($10.00)");
        qty1 = new JSpinner(new SpinnerNumberModel(1,1,100,1));
        panel1.add(item1);
        panel1.add(new JLabel("Quantity: "));
        panel1.add(qty1);
        add(panel1);


        JPanel panel2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        item2 = new JRadioButton("Mocha ($12.00)");
        qty2 = new JSpinner(new SpinnerNumberModel(1,1,100,1));
        panel2.add(item2);
        panel2.add(new JLabel("Quantity: "));
        panel2.add(qty2);
        add(panel2);

        JPanel panel3 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        item3 = new JRadioButton("Americano ($9.00)");
        qty3 = new JSpinner(new SpinnerNumberModel(1,1,100,1));
        panel3.add(item3);
        panel3.add(new JLabel("Quantity: "));
        panel3.add(qty3);
        add(panel3);

        JPanel panel4 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        item4 = new JRadioButton("Espresso ($14.00)");
        qty4 = new JSpinner(new SpinnerNumberModel(1,1,100,1));
        panel4.add(item4);
        panel4.add(new JLabel("Quantity: "));
        panel4.add(qty4);
        add(panel4);

        orderButton = new JButton("Place Order");
        orderButton.setSize(90,30);
        orderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                placeOrder();
            }
        });
        add(orderButton);

        totalLabel = new JLabel("Total: $0.00");
        totalLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(totalLabel);

        setVisible(true);
    }

    private void placeOrder(){
        double total = 0.0;
        StringBuilder orderDetails = new StringBuilder();

        if(item1.isSelected()){
            int quantity = (int) qty1.getValue();
            total+=quantity*price1;
            orderDetails.append("Cappuccino x").append(quantity).append("\n");
        }

        if (item2.isSelected()){
            int quantity = (int) qty2.getValue();
            total+=quantity*price2;
            orderDetails.append("Mocha x").append(quantity).append("\n");
        }
        if (item3.isSelected()){
            int quantity = (int) qty3.getValue();
            total+=quantity*price3;
            orderDetails.append("Americano x").append(quantity).append("\n");
        }
        if (item4.isSelected()){
            int quantity = (int) qty4.getValue();
            total+=quantity*price4;
            orderDetails.append("Espresso x").append(quantity).append("\n");
        }

        totalLabel.setText(String.format("Total: %.2f",total));

        saveOrder(String.valueOf(orderDetails),total);
    }

    private void saveOrder(String orderDetails, double total){
        String url = "jdbc:mysql://localhost:3306/inazumaDB";
        String user = "root";
        String password = "";

        try {
            Connection connection = DriverManager.getConnection(url,user,password);
            Statement statement = connection.createStatement();

            statement.executeUpdate("CREATE TABLE IF NOT EXISTS coffee (id int PRIMARY_KEY, details varchar(250), total double)");

            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO coffee (details,total) VALUES (?,?)");
            preparedStatement.setString(1,orderDetails);
            preparedStatement.setDouble(2, total);
            preparedStatement.executeUpdate();
            preparedStatement.close();
            statement.close();
            connection.close();
            JOptionPane.showMessageDialog(this,"Order placed successfully");
        } catch (SQLException e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,"Error in placing the order");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(CoffeeOrder :: new);
    }
}
