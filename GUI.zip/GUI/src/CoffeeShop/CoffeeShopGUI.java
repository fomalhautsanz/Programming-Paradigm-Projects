package CoffeeShop;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class CoffeeShopGUI {

    private JFrame mainFrame;
    private JLabel headerLabel;
    private JPanel controlPanel;

    private void prepareGUI(){

        //1. SET THE MAIN FRAME FIRST
        mainFrame = new JFrame("Coffee Shop");
        mainFrame.setSize(400,400);
        mainFrame.setLayout(new BorderLayout());

        mainFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        //2. MAKE A PANEL FOR HEADERS
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel,BoxLayout.Y_AXIS));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20,0,20,0));

        headerLabel = new JLabel("COFFEE SHOP",JLabel.CENTER);
        headerLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        headerPanel.add(headerLabel);

        //3. MAKE A ANOTHER PANEL FOR THE BUTTONS
        controlPanel = new JPanel();
        controlPanel.setLayout(new BoxLayout(controlPanel,BoxLayout.Y_AXIS));
        controlPanel.setBorder(BorderFactory.createEmptyBorder(10,100,10,100));
        controlPanel.setSize(400,400);

        //4. ADD EVERYTHING TO THE MAIN FRAME
        mainFrame.add(headerPanel,BorderLayout.NORTH);
        mainFrame.add(controlPanel,BorderLayout.CENTER);
        mainFrame.setVisible(true);
    }

    //5. MAKE THE BUTTONS

    private void showButtonDemo(){
        JButton config = new JButton("Configure");
        JButton add = new JButton("Add");
        JButton display = new JButton("Display");
        JButton update = new JButton("Update");
        JButton delete = new JButton("Delete");
        JButton order = new JButton("Order");

        Dimension buttonSize = new Dimension(150,30);
        JButton[] buttons = {config,add,display,update,delete,order};

        for (JButton button:buttons){
            button.setMaximumSize(buttonSize);
            button.setPreferredSize(buttonSize);
            button.setOpaque(true);
            button.setBackground(new Color(148, 137, 121));
            button.setForeground(Color.white);
            button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            button.setAlignmentX(Component.CENTER_ALIGNMENT);
            controlPanel.add(button);
            controlPanel.add(Box.createRigidArea(new Dimension(0,15)));
        }

        mainFrame.revalidate();
        mainFrame.repaint();
    }

    public static void main(String[] args) {
        CoffeeShopGUI coffeeShopGUI = new CoffeeShopGUI();
        coffeeShopGUI.prepareGUI();
        coffeeShopGUI.showButtonDemo();
    }
}
