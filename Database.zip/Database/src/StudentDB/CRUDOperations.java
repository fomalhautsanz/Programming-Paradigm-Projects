package StudentDB;

public interface CRUDOperations {
    void add(RegularStudent student);
    void readALL();
    void update(int id);
    void delete(int id);
}
