package StudentDB;

import java.sql.*;
import java.util.Scanner;

public class StudentDAO implements CRUDOperations{

    Connection connection;
    Scanner input = new Scanner(System.in);

    private void SQLErrors(SQLException e){
        System.out.println("SQL Exception: " + e.getMessage());
        System.out.println("SQL State: " + e.getSQLState());
        System.out.println("Vendor Error: " + e.getErrorCode());
    }

    public StudentDAO(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Connected successfully!");
            System.out.println();
        } catch (Exception e){
            System.err.println("Unable to find and load driver");
            System.exit(1);
        }
    }

    public void connectToDB(){
        try {
            connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/classdb","root",""
            );
        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    public void createDatabase(){
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","");
            Statement statement = connection.createStatement();

            statement.executeUpdate("DROP DATABASE IF EXISTS classdb");
            statement.executeUpdate("CREATE DATABASE classdb");
            statement.executeUpdate("USE classdb");

            statement.executeUpdate("CREATE TABLE classTable (Name varchar(50), Age int (11), Student_ID INT PRIMARY KEY," +
                    "Units int(11));");

            statement.executeUpdate("INSERT INTO classTable VALUES ('Layla Haymes', 18, 2024-00034, 20)");
            statement.executeUpdate("INSERT INTO classTable VALUES ('Bob Wayne', 18, 2024-0178, 20)");
            statement.executeUpdate("INSERT INTO classTable VALUES ('Wanda Maximoff', 18, 2024-00090, 20)");

            statement.close();
            connection.close();

        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    public void showDatabase(){
        try {
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery("SELECT * FROM classTable");

            System.out.println();
            System.out.printf("%-16s | %-6s | %-10s | %-6s", "Name","Age","Student_ID","Units");
            System.out.println();

            while (rs.next()){
                System.out.printf("%-16s | %-6s | %-10s | %-6s", rs.getString(1), rs.getString(2),
                        rs.getString(3), rs.getString(4));
                System.out.println();
            }
            System.out.println();

            rs.close();
            statement.close();

        } catch (SQLException e){
            SQLErrors(e);
        }
    }


    @Override
    public void add(RegularStudent student) {
        try {
            Statement statement = connection.createStatement();

            statement.executeUpdate(
                    "INSERT INTO classTable VALUES ('" + student.getName() + "', " + student.getAge() + ", " +
                            student.getId() + ", " + student.getUnits() + ")"
            );

            statement.close();
        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    @Override
    public void update(int id) {

        System.out.println("UPDATE");
        System.out.print("Enter Name: "); String name = input.nextLine();
        System.out.println("Enter Age: "); int age = input.nextInt();
        System.out.println("Enter ID: "); int Id = input.nextInt();
        System.out.println("Enter units: "); int units = input.nextInt();

        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate(
                    "UPDATE classTable " +
                            "SET Name = '" + name + "', Age = " + age +", Student_ID = " + Id + ", Units = " + units +
                            " WHERE Student_ID = " + id + ";"
            );

            statement.close();

        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    @Override
    public void delete(int id) {

        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate("DELETE FROM classTable WHERE Student_ID = " + id);
        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    public void disconnectDB(){
        try {
            System.out.println("Disconnecting...");
            connection.close();
        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    @Override
    public void readALL() {

    }
}
