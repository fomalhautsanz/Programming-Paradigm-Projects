package StudentDB;

import java.util.Scanner;

public class StudentMain {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        StudentDAO db = new StudentDAO();
        db.createDatabase();
        db.connectToDB();

        while (true){

            System.out.println("STUDENT MANAGEMENT SYSTEM");
            System.out.println("1. View All Students");
            System.out.println("2. Add Student");
            System.out.println("3. Update Student Information");
            System.out.println("4. Delete Student");
            System.out.println("5. Exit");
            int choice = input.nextInt();
            input.nextLine();

            switch (choice){
                case 1:
                    db.showDatabase();
                    break;

                case 2:
                    System.out.print("Enter Name: "); String name = input.nextLine();
                    System.out.println("Enter Age: "); int age = input.nextInt();
                    System.out.println("Enter ID: "); int Id = input.nextInt();
                    System.out.println("Enter units: "); int units = input.nextInt();

                    RegularStudent student = new RegularStudent(name,age,Id,units);
                    db.add(student);
                    break;

                case 3:
                    db.showDatabase();
                    System.out.print("Enter Student ID of the student: "); int updateID = input.nextInt();
                    db.update(updateID);
                    break;

                case 4:
                    db.showDatabase();
                    System.out.print("Enter Student ID of the student: "); int deleteID = input.nextInt();
                    db.delete(deleteID);
                    break;

                case 5:
                    db.disconnectDB();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Please enter a valid option!");
                    break;
            }
        }
    }
}
