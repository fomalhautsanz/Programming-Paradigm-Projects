package StudentDB;

public class RegularStudent extends Student{

    private int units;

    RegularStudent(String name, int age, int id, int units){
        super(name, age, id);
        this.units=units;
    }

    public void setUnits(int units) {
        this.units = units;
    }

    public int getUnits() {
        return units;
    }

    @Override
    public void displayInfo() {
        System.out.println("Name: " + getName());
        System.out.println("Age: " + getAge());
        System.out.println("ID: " + getId());
        System.out.println("Units: " + units);
    }
}
