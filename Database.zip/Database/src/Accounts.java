import java.sql.*;

public class Accounts {
    Connection connection;

    private void SQLErrors(SQLException e){
        System.out.println("SQL Exception: " + e.getMessage());
        System.out.println("SQL State: " + e.getSQLState());
        System.out.println("Vendor Error: " + e.getErrorCode());
    }

    public Accounts(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Connected successfully!");
            System.out.println();
        } catch (Exception e){
            System.err.println("Unable to find and load driver");
            System.exit(1);
        }
    }

    public void connectToDB(){
        try {
            connection = DriverManager.getConnection
                    ("jdbc:mysql://localhost:3306/accounts","root","");
        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    public void executeSQL(){
        try {
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery
                    ("SELECT * FROM accs");

            while (rs.next()){
                System.out.print("Account ID: " + rs.getString(1));
                System.out.print(" | Account Name: " + rs.getString(2));
                System.out.println();
            }

            rs.close();
            statement.close();
            connection.close();

        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    public void addAccount(){
        try {
            Statement statement = connection.createStatement();
            int rowsAffected = statement.executeUpdate
                    ("INSERT INTO accs VALUES (6001, 'Farah Noel')");

            System.out.println("Inserted successfully! Rows affected: " + rowsAffected);

            statement.close();
        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    public void removeAccount(){
        try {
            Statement statement = connection.createStatement();
            int rowsAffected = statement.executeUpdate
                    ("DELETE FROM accs WHERE Account_ID=3421");

            System.out.println("Deleted successfully! Rows affected: " + rowsAffected);

            statement.close();
        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    public void updateAccount(){
        try {
            Statement statement = connection.createStatement();
            int rowsAffected = statement.executeUpdate
                    ("UPDATE accs SET Account_Name='Freya Noelle' WHERE Account_ID=6001");

            System.out.println("Updated successfully! Rows affected: " + rowsAffected);

            statement.close();
        } catch (SQLException e){
            SQLErrors(e);
        }
    }



    public static void main(String[] args) {
        Accounts accounts = new Accounts();
        accounts.connectToDB();

        accounts.executeSQL();

    }
}
