package Excercise;

import java.sql.*;

public class ExerciseDB {
    Connection connection;

    private void SQLErrors(SQLException e){
        System.out.println("SQL Exception: " + e.getMessage());
        System.out.println("SQL State: " + e.getSQLState());
        System.out.println("Vendor Error: " + e.getErrorCode());
    }

    ExerciseDB(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Connected successfully!");
            System.out.println();
        } catch (Exception e){
            System.err.println("Unable to find and load driver");
            System.exit(1);
        }
    }

    public void connectToDB(){
        try {
            connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/exerciseDB","root",""
            );
        } catch (SQLException e) {
            SQLErrors(e);
        }
    }

    public void disconnectDB(){
        try {
            connection.close();
        }
        catch (SQLException e){
            SQLErrors(e);
        }
    }

    public void createDatabase(){
        try {
            connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/","root",""
            );
            Statement statement = connection.createStatement();

            statement.executeUpdate("DROP DATABASE IF EXISTS exerciseDB");
            statement.executeUpdate("CREATE DATABASE exerciseDB");
            statement.executeUpdate("USE exerciseDB");

            statement.executeUpdate("CREATE TABLE Customer (CUSTOMER_NUMBER int(11) PRIMARY KEY AUTO_INCREMENT, LAST varchar(25), FIRST varchar(25)," +
                    "STREET varchar(25), CITY varchar(25), STATE varchar(25), ZIP_CODE int(11), BALANCE double, CREDIT_LIMIT double," +
                    "SLSREP_NUMBER int(11))");

            statement.executeUpdate("CREATE TABLE Part (PART_NUMBER varchar(50), PART_DESCRIPTION varchar(50), UNITS_ON_HAND int(11)," +
                    "ITEM_CLASS varchar(25), WAREHOUSE_NUMBER int(11), UNIT_PRICE double)");
            statement.close();
        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    public void addAccount(){
        try {
            Statement statement = connection.createStatement();

            //Customer
            statement.executeUpdate
                    ("INSERT INTO Customer VALUES (124, 'Adams', 'Sally', '481 Oak', 'Lansing', 'MI', 49224, 818.75, 1000, 3)");

            statement.executeUpdate
                    ("INSERT INTO Customer VALUES (256, 'Samuels', 'Ann', '215 Pete', 'Grant', 'MI', 49219, 21.5, 1500, 6)");

            statement.executeUpdate
                    ("INSERT INTO Customer VALUES (311, 'Charles', 'Don', '48 College', 'Ira', 'MI', 49034, 825.75, 1000, 12)");

            statement.executeUpdate
                    ("INSERT INTO Customer VALUES (315, 'Daniels', 'Tom', '914 Cherry', 'Kent', 'MI', 48391, 770.75, 750, 6)");

            statement.executeUpdate
                    ("INSERT INTO Customer VALUES (405, 'Williams', 'Al', '519 Watson', 'Grant', 'MI', 49219, 402.75, 1500, 12)");

            statement.executeUpdate
                    ("INSERT INTO Customer VALUES (412, 'Adams', 'Sally', '16 Elm', 'Lansing', 'MI', 49224, 1817.5, 2000, 3)");

            statement.executeUpdate
                    ("INSERT INTO Customer VALUES (522, 'Nelson', 'Mary', '108 Pine', 'Ada', 'MI', 49441, 98.75, 1500, 12)");

            statement.executeUpdate
                    ("INSERT INTO Customer VALUES (567, 'Dinh', 'Tran', '808 Ridge', 'Harper', 'MI', 48421, 402.4, 750, 6)");

            statement.executeUpdate
                    ("INSERT INTO Customer VALUES (587, 'Galves', 'Mara', '512 Pine', 'Ada', 'MI', 49441, 114.6, 1000, 6)");

            statement.executeUpdate
                    ("INSERT INTO Customer VALUES (622, 'Martin', 'Dan', '419 Chip', 'Grant', 'MI', 49219, 1045.75, 1000, 3)");

            //Part
            statement.executeUpdate
                    ("INSERT INTO Part VALUES ('AX12', 'Iron', 104, 'HW', 3, 24.95)");

            statement.executeUpdate
                    ("INSERT INTO Part VALUES ('AZ52', 'Dartboard', 20, 'SG', 2, 12.95)");

            statement.executeUpdate
                    ("INSERT INTO Part VALUES ('BA74', 'Basketball', 40, 'SG', 1, 29.95)");

            statement.executeUpdate
                    ("INSERT INTO Part VALUES ('BH22', 'Cornpopper', 95, 'HW', 3, 24.95)");

            statement.executeUpdate
                    ("INSERT INTO Part VALUES ('BT04', 'Gas Grill', 11, 'AP', 2, 149.99)");

            statement.executeUpdate
                    ("INSERT INTO Part VALUES ('BX66', 'Washer', 52, 'AP', 3, 399.99)");

            statement.executeUpdate
                    ("INSERT INTO Part VALUES ('CA14', 'Griddle', 78, 'HW', 3, 39.99)");

            statement.executeUpdate
                    ("INSERT INTO Part VALUES ('CB03', 'Bike', 44, 'SG', 1, 299.99)");

            statement.executeUpdate
                    ("INSERT INTO Part VALUES ('CX11', 'Blender', 112, 'HW', 3, 22.95)");

            statement.executeUpdate
                    ("INSERT INTO Part VALUES ('CZ81', 'Treadmill', 68, 'SG', 2, 349.95)");

        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    public void showDatabase(){
        try {
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery("SELECT * FROM Customer");

            System.out.println("Table: Customer");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");

            System.out.printf("%-16s | %-10s | %-6s | %-12s | %-9s | %-6s | %-10s | %-10s | %-14s | %-16s\n",
                    "CUSTOMER_NUMBER", "LAST", "FIRST", "STREET", "CITY", "STATE",
                    "ZIP_CODE", "BALANCE", "CREDIT_LIMIT", "SLSREP_NUMBER");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");

            while (rs.next()){
                System.out.printf("%-16s | %-10s | %-6s | %-12s | %-9s | %-6s | %-10s | %-10s | %-14s | %-16s",
                        rs.getString(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getString(5), rs.getString(6),
                        rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10));
                System.out.println();
            }
            System.out.println("\n");

            rs = statement.executeQuery("SELECT * FROM Part");

            System.out.println("Table: Part");
            System.out.println("------------------------------------------------------------------------------------------------------");

            System.out.printf("%-12s | %-18s | %-16s | %-12s | %-18s | %-10s\n",
                    "PART_NUMBER", "PART_DESCRIPTION", "UNITS_ON_HAND",
                    " ITEM_CLASS", "WAREHOUSE_NUMBER", "UNIT_PRICE");
            System.out.println("------------------------------------------------------------------------------------------------------");

            while (rs.next()){
                System.out.printf("%-12s | %-18s | %-16s | %-12s | %-18s | %-10s",
                        rs.getString(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getString(5), rs.getString(6));
                System.out.println();
            }
            System.out.println("\n");

        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    public void problems(){
        try {
            //1. Customers with balance > 75% of credit limit
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery("SELECT CUSTOMER_NUMBER, LAST, FIRST FROM Customer WHERE BALANCE > (CREDIT_LIMIT * 0.75)");

            System.out.println("Table: Customer");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");

            System.out.printf("%-16s | %-10s | %-6s \n",
                    "CUSTOMER_NUMBER", "LAST", "FIRST");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");

            while (rs.next()){
                System.out.printf("%-16s | %-10s | %-6s ",
                        rs.getString(1), rs.getString(2), rs.getString(3));
                System.out.println();
            }
            System.out.println("\n");

            //2. Total balance of all customers grouped by city
           rs = statement.executeQuery("SELECT CITY, SUM(BALANCE) AS TOTAL_BALANCE " +
                   "FROM Customer GROUP BY CITY " +
                   "ORDER BY TOTAL_BALANCE DESC");

            System.out.println("Table: Customer");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");

            System.out.printf("%-9s | %-10s \n",
                    "CITY", "TOTAL_BALANCE");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");

            while (rs.next()){
                System.out.printf(" %-9s | %-10s ",
                        rs.getString(1), rs.getString(2));
                System.out.println();
            }
            System.out.println("\n");

            //3. Customer(s) with the highest balance in each ZIP code

            rs = statement.executeQuery("SELECT * FROM Customer c WHERE BALANCE = (SELECT MAX(BALANCE) " +
                    "FROM Customer WHERE ZIP_CODE = c.ZIP_CODE)");

            System.out.println("Table: Customer");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");

            System.out.printf("%-16s | %-10s | %-6s | %-12s | %-9s | %-6s | %-10s | %-10s | %-14s | %-16s\n",
                    "CUSTOMER_NUMBER", "LAST", "FIRST", "STREET", "CITY", "STATE",
                    "ZIP_CODE", "BALANCE", "CREDIT_LIMIT", "SLSREP_NUMBER");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");

            while (rs.next()){
                System.out.printf("%-16s | %-10s | %-6s | %-12s | %-9s | %-6s | %-10s | %-10s | %-14s | %-16s",
                        rs.getString(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getString(5), rs.getString(6),
                        rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10));
                System.out.println();
            }
            System.out.println("\n");

            //4. Customers represented by same sales rep and live in same city

            rs = statement.executeQuery("SELECT * FROM Customer c1 " +
                    "WHERE EXISTS (" +
                    "SELECT 1 " +
                    "FROM Customer c2 " +
                    "WHERE c1.CUSTOMER_NUMBER <> c2.CUSTOMER_NUMBER " +
                    "AND c1.SLSREP_NUMBER = c2.SLSREP_NUMBER " +
                    "AND c1.CITY = c2.CITY)");

            System.out.println("Table: Customer");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");

            System.out.printf("%-16s | %-10s | %-6s | %-12s | %-9s | %-6s | %-10s | %-10s | %-14s | %-16s\n",
                    "CUSTOMER_NUMBER", "LAST", "FIRST", "STREET", "CITY", "STATE",
                    "ZIP_CODE", "BALANCE", "CREDIT_LIMIT", "SLSREP_NUMBER");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");

            while (rs.next()){
                System.out.printf("%-16s | %-10s | %-6s | %-12s | %-9s | %-6s | %-10s | %-10s | %-14s | %-16s",
                        rs.getString(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getString(5), rs.getString(6),
                        rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10));
                System.out.println();
            }
            System.out.println("\n");

            //5. Average balance per sales rep (only where avg > $500)

            rs = statement.executeQuery("SELECT SLSREP_NUMBER, AVG(BALANCE) AS AVERAGE_BALANCE FROM Customer " +
                    "GROUP BY SLSREP_NUMBER " +
                    "HAVING AVG(BALANCE) > 500");

            System.out.println("Table: Customer");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");

            System.out.printf(" %-10s | %-16s\n",
                    "SLSREP_NUMBER", "BALANCE");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");

            while (rs.next()){
                System.out.printf("%-10s | %-16s",
                        rs.getString(1), rs.getString(2));
                System.out.println();
            }
            System.out.println("\n");


        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    public static void main(String[] args) {
        ExerciseDB exerciseDB = new ExerciseDB();
        exerciseDB.createDatabase();
        exerciseDB.connectToDB();
        exerciseDB.addAccount();
        exerciseDB.showDatabase();
        exerciseDB.problems();
        exerciseDB.disconnectDB();
    }
}
