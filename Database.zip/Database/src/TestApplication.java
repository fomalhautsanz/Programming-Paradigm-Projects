import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestApplication {
    static final String DB_URL = "jdbc:mysql://localhost:3306/tutorialdb";
    static final String USER = "root";
    static final String PASS = "";
    static Connection connection;

    public static void main(String[] args) {
        connect();
    }

    public static Connection connect(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connected to the database");

            Statement statement;
            statement = connection.createStatement();
            ResultSet resultSet;
            resultSet = statement.executeQuery(
                    "select * from people");
                int ID;
            String Name;
            while (resultSet.next()) {
                ID = resultSet.getInt("ID");
                Name = resultSet.getString("Name").trim();
                System.out.println("ID : " + ID
                        + " Name : " + Name);
            }
            resultSet.close();
            statement.close();
            connection.close();

        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Failed to connect to the database!");
            e.printStackTrace();
        }
        return connection;
    }

    public static void disconnect(){
        try {
            if (connection != null && !connection.isClosed()){
                connection.close();
                System.out.println("Disconnected from the database!");
            }
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
}