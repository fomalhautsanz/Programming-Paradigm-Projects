import java.sql.*;

public class DatabaseExercise1 {

    Connection connection;

    private void SQLErrors(SQLException e){
        System.out.println("SQL Exception: " + e.getMessage());
        System.out.println("SQL State: " + e.getSQLState());
        System.out.println("Vendor Error: " + e.getErrorCode());
    }

    public DatabaseExercise1(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Connected successfully!");
            System.out.println();
        } catch (Exception e){
            System.err.println("Unable to find and load driver");
            System.exit(1);
        }
    }

    public void connectToDB(){
        try {
            connection = DriverManager.getConnection
                    ("jdbc:mysql://localhost:3306/myDB","root","");
        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    public void createDatabase(){
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/", "root", "");
            Statement statement = connection.createStatement();

            statement.executeUpdate("DROP DATABASE IF EXISTS myDB");
            statement.executeUpdate("CREATE DATABASE myDB");
            statement.executeUpdate("USE myDB");

            statement.executeUpdate("CREATE TABLE Sales_Rep (SLSREP_NUMBER int(11) PRIMARY KEY AUTO_INCREMENT," +
                    "LAST varchar(25), FIRST varchar(25), STREET varchar(50), CITY varchar(25)," +
                    "STATE varchar(25), ZIP_CODE varchar(15), TOTAL_COMMISSION double," +
                    "COMMISSION_RATE double);");

            statement.executeUpdate("CREATE TABLE Customer (CUSTOMER_NUMBER int(11) PRIMARY KEY AUTO_INCREMENT," +
                    "LAST varchar(25), FIRST varchar(25), STREET varchar(50), CITY varchar(25)," +
                    "STATE varchar(25), ZIP_CODE int(11), BALANCE double," +
                    "CREDIT_LIMIT double, SLSREP_NUMBER int(11));");

            statement.executeUpdate("CREATE TABLE Orders (ORDER_NUMBER int(11) PRIMARY KEY AUTO_INCREMENT," +
                    "ORDER_DATE date, CUSTOMER_NUMBER int(11));");

            statement.executeUpdate("CREATE TABLE Part (PART_NUMBER varchar(50)," +
                    "PART_DESCRIPTION varchar(50), UNITS_ON_HAND int(11), ITEM_CLASS varchar(25), " +
                    "WAREHOUSE_NUMBER int(11), UNIT_PRICE double);");

            statement.executeUpdate("CREATE TABLE Order_Line (ORDER_NUMBER int(11), PART_NUMBER varchar(25)," +
                    "NUMBER_ORDERED int(11), QUOTED_PRICE double);");



            statement.close();
            connection.close();

        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    public void showDatabase(){
        try {
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery
                    ("SELECT * FROM Sales_Rep");

            System.out.println("Table: Sales_Rep");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------");

            System.out.printf("%-16s | %-10s | %-10s | %-12s | %-9s | %-6s | %-10s | %-10s | %-14s\n",
                    "SLSREP_NUMBER", "LAST", "FIRST", "STREET", "CITY", "STATE",
                    "ZIP_CODE", "TOTAL_COMMISSION", "COMMISSION_RATE");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------");

            while (rs.next()){
                System.out.printf("%-16s | %-10s | %-10s | %-12s | %-9s | %-6s | %-10s | %-16s | %-14s",
                        rs.getString(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getString(5), rs.getString(6),
                        rs.getString(7), rs.getString(8), rs.getString(9));
                System.out.println();
            }
            System.out.println("\n");

            rs = statement.executeQuery("SELECT * FROM Customer");

            System.out.println("Table: Customer");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");

            System.out.printf("%-16s | %-10s | %-6s | %-12s | %-9s | %-6s | %-10s | %-10s | %-14s | %-16s\n",
                    "CUSTOMER_NUMBER", "LAST", "FIRST", "STREET", "CITY", "STATE",
                    "ZIP_CODE", "BALANCE", "CREDIT_LIMIT", "SLSREP_NUMBER");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");

            while (rs.next()){
                System.out.printf("%-16s | %-10s | %-6s | %-12s | %-9s | %-6s | %-10s | %-10s | %-14s | %-16s",
                        rs.getString(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getString(5), rs.getString(6),
                        rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10));
                System.out.println();
            }
            System.out.println("\n");

            rs = statement.executeQuery("SELECT * FROM Orders");

            System.out.println("Table: Orders");
            System.out.println("-----------------------------------------------------");
            System.out.printf("%-16s | %-16s | %-16s\n",
                    "ORDER_NUMBER", "ORDER_DATE", "CUSTOMER_NUMBER");
            System.out.println("-----------------------------------------------------");

            while (rs.next()){
                System.out.printf("%-16s | %-16s | %-16s",
                        rs.getString(1), rs.getString(2), rs.getString(3));
                System.out.println();
            }
            System.out.println("\n");


            rs = statement.executeQuery("SELECT * FROM Part");

            System.out.println("Table: Part");
            System.out.println("------------------------------------------------------------------------------------------------------");

            System.out.printf("%-12s | %-18s | %-16s | %-12s | %-18s | %-10s\n",
                    "PART_NUMBER", "PART_DESCRIPTION", "UNITS_ON_HAND",
                    " ITEM_CLASS", "WAREHOUSE_NUMBER", "UNIT_PRICE");
            System.out.println("------------------------------------------------------------------------------------------------------");

            while (rs.next()){
                System.out.printf("%-12s | %-18s | %-16s | %-12s | %-18s | %-10s",
                        rs.getString(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getString(5), rs.getString(6));
                System.out.println();
            }
            System.out.println("\n");

            rs = statement.executeQuery("SELECT * FROM Order_Line");

            System.out.println("Table: Order_Line");
            System.out.println("--------------------------------------------------------------");

            System.out.printf("%-12s | %-12s | %-16s | %-12s\n",
                    "ORDER_NUMBER", "PART_NUMBER", "NUMBER_ORDERED",
                    "QUOTED_PRICE");
            System.out.println("--------------------------------------------------------------");

            while (rs.next()){
                System.out.printf("%-12s | %-12s | %-16s | %-12s",
                        rs.getString(1), rs.getString(2), rs.getString(3),
                        rs.getString(4));
                System.out.println();
            }
            System.out.println("\n");


            rs.close();
            statement.close();
            connection.close();

        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    public void addAccount(){
        try {
            Statement statement = connection.createStatement();

            //Sales_Rep
            statement.executeUpdate
                    ("INSERT INTO Sales_Rep VALUES (3, 'Jones', 'Mary', '123 Main', 'Grant', 'MI', '49219', 2150, 0.05)");

            statement.executeUpdate
                    ("INSERT INTO Sales_Rep VALUES (6, 'Smith', 'William', '102 Raymond', 'Ada', 'MI', '49441', 4912.5, 0.07)");

            statement.executeUpdate
                    ("INSERT INTO Sales_Rep VALUES (12, 'Diaz', 'Miguel', '419 Harper', 'Lansing', 'MI', '49224', 2150, 0.05)");

            //Customer
            statement.executeUpdate
                    ("INSERT INTO Customer VALUES (124, 'Adams', 'Sally', '481 Oak', 'Lansing', 'MI', 49224, 818.75, 1000, 3)");

            statement.executeUpdate
                    ("INSERT INTO Customer VALUES (256, 'Samuels', 'Ann', '215 Pete', 'Grant', 'MI', 49219, 21.5, 1500, 6)");

            statement.executeUpdate
                    ("INSERT INTO Customer VALUES (311, 'Charles', 'Don', '48 College', 'Ira', 'MI', 49034, 825.75, 1000, 12)");

            statement.executeUpdate
                    ("INSERT INTO Customer VALUES (315, 'Daniels', 'Tom', '914 Cherry', 'Kent', 'MI', 48391, 770.75, 750, 6)");

            statement.executeUpdate
                    ("INSERT INTO Customer VALUES (405, 'Williams', 'Al', '519 Watson', 'Grant', 'MI', 49219, 402.75, 1500, 12)");

            statement.executeUpdate
                    ("INSERT INTO Customer VALUES (412, 'Adams', 'Sally', '16 Elm', 'Lansing', 'MI', 49224, 1817.5, 2000, 3)");

            statement.executeUpdate
                    ("INSERT INTO Customer VALUES (522, 'Nelson', 'Mary', '108 Pine', 'Ada', 'MI', 49441, 98.75, 1500, 12)");

            statement.executeUpdate
                    ("INSERT INTO Customer VALUES (567, 'Dinh', 'Tran', '808 Ridge', 'Harper', 'MI', 48421, 402.4, 750, 6)");

            statement.executeUpdate
                    ("INSERT INTO Customer VALUES (587, 'Galves', 'Mara', '512 Pine', 'Ada', 'MI', 49441, 114.6, 1000, 6)");

            statement.executeUpdate
                    ("INSERT INTO Customer VALUES (622, 'Martin', 'Dan', '419 Chip', 'Grant', 'MI', 49219, 1045.75, 1000, 3)");

            //Orders
            statement.executeUpdate
                    ("INSERT INTO Orders VALUES (12489, '2002-09-02', 124)");

            statement.executeUpdate
                    ("INSERT INTO Orders VALUES (12491, '2002-09-02', 311)");

            statement.executeUpdate
                    ("INSERT INTO Orders VALUES (12494, '2002-09-04', 315)");

            statement.executeUpdate
                    ("INSERT INTO Orders VALUES (12495, '2002-09-04', 256)");

            statement.executeUpdate
                    ("INSERT INTO Orders VALUES (12498, '2002-09-05', 522)");

            statement.executeUpdate
                    ("INSERT INTO Orders VALUES (12500, '2002-09-05', 124)");

            statement.executeUpdate
                    ("INSERT INTO Orders VALUES (12504, '2002-09-05', 522)");

            //Part
            statement.executeUpdate
                    ("INSERT INTO Part VALUES ('AX12', 'Iron', 104, 'HW', 3, 24.95)");

            statement.executeUpdate
                    ("INSERT INTO Part VALUES ('AZ52', 'Dartboard', 20, 'SG', 2, 12.95)");

            statement.executeUpdate
                    ("INSERT INTO Part VALUES ('BA74', 'Basketball', 40, 'SG', 1, 29.95)");

            statement.executeUpdate
                    ("INSERT INTO Part VALUES ('BH22', 'Cornpopper', 95, 'HW', 3, 24.95)");

            statement.executeUpdate
                    ("INSERT INTO Part VALUES ('BT04', 'Gas Grill', 11, 'AP', 2, 149.99)");

            statement.executeUpdate
                    ("INSERT INTO Part VALUES ('BX66', 'Washer', 52, 'AP', 3, 399.99)");

            statement.executeUpdate
                    ("INSERT INTO Part VALUES ('CA14', 'Griddle', 78, 'HW', 3, 39.99)");

            statement.executeUpdate
                    ("INSERT INTO Part VALUES ('CB03', 'Bike', 44, 'SG', 1, 299.99)");

            statement.executeUpdate
                    ("INSERT INTO Part VALUES ('CX11', 'Blender', 112, 'HW', 3, 22.95)");

            statement.executeUpdate
                    ("INSERT INTO Part VALUES ('CZ81', 'Treadmill', 68, 'SG', 2, 349.95)");

            //Order_Line

            statement.executeUpdate
                    ("INSERT INTO Order_Line VALUES (12489, 'AX12', 11, 21.95)");

            statement.executeUpdate
                    ("INSERT INTO Order_Line VALUES (12498, 'AZ52', 2, 12.95)");

            statement.executeUpdate
                    ("INSERT INTO Order_Line VALUES (12498, 'BA74', 4, 24.95)");

            statement.executeUpdate
                    ("INSERT INTO Order_Line VALUES (12491, 'BT04', 1, 149.99)");

            statement.executeUpdate
                    ("INSERT INTO Order_Line VALUES (12500, 'BT04', 1, 149.99)");

            statement.executeUpdate
                    ("INSERT INTO Order_Line VALUES (12491, 'BZ66', 1, 399.99)");

            statement.executeUpdate("INSERT INTO Order_Line VALUES (12494, 'CB03', 4, 279.99)");

            statement.executeUpdate("INSERT INTO Order_Line VALUES (12495, 'CX11', 2, 22.95)");

            statement.executeUpdate("INSERT INTO Order_Line VALUES (12504, 'CZ81', 2, 325.99)");


            statement.close();
        } catch (SQLException e){
            SQLErrors(e);
        }
    }

    public static void main(String[] args) {
        DatabaseExercise1 db = new DatabaseExercise1();
        db.createDatabase();
        db.connectToDB();
        db.addAccount();
        db.showDatabase();
    }

}
