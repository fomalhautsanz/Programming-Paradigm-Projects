import java.util.*;

public class ViewPriceRates {
    public static double firstThreeHoursRate = 20;
    public static double additionalHourlyRate = 5;
    /*
    I USED THESE TWO METHODS TO ENSURE THAT THE PRICE RATES CAN BE UPDATED
     */

    public static void viewAndUpdatePriceRates(Scanner input) {
        System.out.println("\n=======================================");
        System.out.println("          SET PRICE RATES");
        System.out.println("=======================================");
        System.out.println("Current Pricing:");
        System.out.println("- First 3 Hours: ₱" + firstThreeHoursRate);
        System.out.println("- Additional Hourly Rate After 3 Hours: ₱" + additionalHourlyRate + "/hour");

        while (true) {
            System.out.print("Enter the new rate for the first 3 hours: ₱");
            if (input.hasNextDouble()) { //ENSURES THAT THE INPUT IS A DOUBLE
                firstThreeHoursRate = input.nextDouble();
                break;
            } else {
                System.out.println("Invalid input. Please enter a numeric value.");
                input.nextLine();
            }
        }


        while (true) {
            System.out.print("Enter the new additional hourly rate (after 3 hours): ₱");
            if (input.hasNextDouble()) { //ENSURES THAT THE INPUT IS DOUBLE
                additionalHourlyRate = input.nextDouble();
                break;
            } else {
                System.out.println("Invalid input. Please enter a numeric value.");
                input.nextLine();
            }
        }

        input.nextLine();

        System.out.println("\nPricing updated successfully!");
        System.out.println("Press Enter to return to Admin Dashboard.");
        input.nextLine();
    }
}
