import java.util.*;

public class Guide {
    public static double firstThreeHoursRate = 20;
    public static double additionalHourlyRate = 5;

    public static void viewAndUpdatePriceRates(Scanner input) {
        System.out.println("\n=======================================");
        System.out.println("          SET PRICE RATES");
        System.out.println("=======================================");
        System.out.println("Current Pricing:");
        System.out.println("- First 3 Hours: ₱" + String.format("%.2f", firstThreeHoursRate));
        System.out.println("- Additional Hourly Rate After 3 Hours: ₱" + String.format("%.2f", additionalHourlyRate) + "/hour");

        // Update the first 3 hours rate
        while (true) {
            System.out.print("Enter the new rate for the first 3 hours: ₱");
            if (input.hasNextDouble()) {
                firstThreeHoursRate = input.nextDouble();
                break;
            } else {
                System.out.println("Invalid input. Please enter a numeric value.");
                input.nextLine(); // Clear invalid input
            }
        }

        // Update the additional hourly rate
        while (true) {
            System.out.print("Enter the new additional hourly rate (after 3 hours): ₱");
            if (input.hasNextDouble()) {
                additionalHourlyRate = input.nextDouble();
                break;
            } else {
                System.out.println("Invalid input. Please enter a numeric value.");
                input.nextLine(); // Clear invalid input
            }
        }

        // Clear the buffer after numeric inputs
        input.nextLine();

        System.out.println("\nPricing updated successfully!");
        System.out.println("Press Enter to return to Admin Dashboard.");
        input.nextLine(); // Wait for user to press Enter
    }
}
