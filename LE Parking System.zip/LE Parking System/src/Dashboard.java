import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Scanner;

public class Dashboard {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[][] staffs = new String[10][4]; //ARRAY FOR STAFFS
        while (true) {
            System.out.println("=====================================");
            System.out.println("PARKING MANAGEMENT SYSTEM");
            System.out.println("=====================================");
            System.out.println("1. Log In");
            System.out.println("2. Exit");

            if (!input.hasNextInt()) {
                System.out.println("Please enter a valid option.");
                input.nextLine();
                continue;
            }

            int loginChoice = input.nextInt();

            if (loginChoice == 1) {
                input.nextLine();
                if (adminLogIn(staffs,input)){
                    adminDashboard(staffs,input);
                }
                else {
                    break; //CHANGE THE BREAK, INSERT STAFF DASHBOARD METHOD/CLASS HERE
                }
            }
            else if (loginChoice == 2) {
                System.out.println("Now exiting the system...");
                System.exit(0);
            }
            else {
                System.out.println("Please enter a valid option. ");
            }
        }
    }

    public static boolean adminLogIn(String[][] arr, Scanner input) {
        while (true) {
            System.out.println("=====================================");
            System.out.println("PARKING MANAGEMENT SYSTEM LOG IN");
            System.out.println("=====================================");
            System.out.println("Press ENTER to proceed...");
            input.nextLine();
            System.out.print("Enter username: ");
            String enterUsername = input.nextLine();
            System.out.print("Enter password: ");
            String enterPassword = input.nextLine();

            if (Objects.equals(enterUsername, "admin123") && Objects.equals(enterPassword, "usepadmin")) {
                System.out.println("Log in successful! Welcome admin.");
                return true;
            }

            for (int i = 0; i < arr.length; i++) {
                if (arr[i] != null && Objects.equals(enterUsername, arr[i][0]) && Objects.equals(enterPassword, arr[i][1])) {
                    System.out.println("Log in successful! Welcome staff.");
                    return false;
                }
            }

            System.out.println("Wrong username or password. Please try again.");
        }
    }


    public static void adminDashboard (String[][] arr, Scanner input){
        System.out.println("======================================");
        System.out.println("ADMIN DASHBOARD");
        System.out.println("======================================");
        System.out.println("1. Manage Staff Accounts");
        System.out.println("2. Set Price Rates");
        System.out.println("3. View Reports");
        System.out.println("4. Log Out");
        int dashboardChoice = input.nextInt();

        switch (dashboardChoice){
            case 1:
                manageStaffAccs(arr,input);
                /*
                ANG METHOD SA AKONG PART KAY GIBUTANG NA NAKO DIRIA NA CLASS SINCE ANG
                STAFFS ARRAY NAKO ANG BASIS TO ENABLE TO THE STAFFS TO LOG IN SA LOG IN PAGE
                 */
                break;

            case 2:
                ViewPriceRates.viewAndUpdatePriceRates(input);
                adminDashboard(arr,input);
                /*
                GI-CALL NAKO ANG CLASS SA PART NI EXEQUIEL SINCE ISA RA ANG PARAMETER WHICH IS ANG INPUT, DALI RA MA-INVOKE
                 */
                break;

            case 3:
                /*
                CALL/INVOKE DIRI ANG STAFF DASHBOARD CLASS NI MARIA, I THINK ANG CLASS JUD ANG IBUTANG DIRI IF PWEDE, KAY DAGHAN SIYAG
                METHODS. TAPOS IF IBUTANG TO ANG MGA METHODS DIRIA NA CLASS BASIN TAAS NA KAAYO.
                 */
                System.out.println("Under development");
                break;

            case 4:
                System.out.println("Logging out...");
                adminLogIn(arr,input);

            default:
                System.out.println("Please enter a valid option number.");
        }
    }

    public static void manageStaffAccs(String[][] staffs, Scanner input){
        int count = 0;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss a");
        /*
        NAG GAMIT KO UG DATE AND TIME FORMATTER PARA NAAY TAMA NGA FORMAT ANG TIME DIDTO SA LAST LOG IN NA COLUMN SA DISPLAY STAFFS
         */

        while (true) {
            System.out.println("===================================");
            System.out.println("MANAGE STAFF ACCOUNTS");
            System.out.println("===================================");
            System.out.println("1. Create New Staff Account");
            System.out.println("2. View All Staff");
            System.out.println("3. Back to Dashboard");
            System.out.print("Select an option: ");

            if (!input.hasNextInt()) { // If mag enter ang user ug input na letters or other characters, mag throw siya ug error sa user
                System.out.println("Invalid input. Please enter a valid option number.");
                input.nextLine();
                continue;
            }
            int managestaffmenu = input.nextInt();
            input.nextLine();

            switch (managestaffmenu) {
                case 1:
                    createNewStaff(staffs, input, formatter, count);
                    count = Math.min(count + 1, staffs.length); //Para i-update ang count variable to track the existing accs, ensuring the count never exceeds the staffs array
                    break;

                case 2:
                    manageStaffActions(staffs, input, count);
                    break;

                case 3:
                    System.out.println("Returning to the dashboard...");
                    adminDashboard(staffs,input);
                    break;

                default:
                    System.out.println("Please enter a valid option number.");
            }
        }
    }


    public static void createNewStaff(String[][] staffs, Scanner input, DateTimeFormatter formatter, int count) {
        System.out.println("===================================");
        System.out.println("CREATE A NEW STAFF ACCOUNT");
        System.out.println("===================================");
        if (count >= staffs.length) {
            System.out.println("Limit reached. Cannot create more accounts. Please contact the system developers.");
            /*
            ANG LIMIT ANI IS 10 STAFFS, IF MO-EXCEED ANI, MO-PRINT SA ANANG NAA SA TAAS
             */
        } else {
            while (true) {
                System.out.print("Enter new staff username: ");
                staffs[count][0] = input.nextLine();
                System.out.print("Enter new staff password: ");
                staffs[count][1] = input.nextLine();

                if ("".equals(staffs[count][0]) || "".equals(staffs[count][1])) {
                    System.out.println("It seems like you did not enter a username or password. Please try again.");
                    break;
                }

                staffs[count][2] = "Active";
                staffs[count][3] = LocalDateTime.now().format(formatter);
                System.out.println("Account successfully created!");
                break;
            }
        }
    }

    public static void manageStaffActions(String[][] staffs, Scanner input, int count) {
        System.out.println("===================================");
        System.out.println("VIEW ALL STAFFS");
        System.out.println("===================================");
        displayStaffs(staffs, count);

        if (count == 0) {
            System.out.println("No staff accounts available to manage.");
            return;
        }

        System.out.println("Actions: ");
        System.out.println("1. Deactivate a Staff Account");
        System.out.println("2. Reset Staff Password");
        System.out.println("3. Back to Manage Staff Menu");
        System.out.print("Select an action: ");

        if (!input.hasNextInt()) { //Checks the user input again para sa mga invalid inputs
            System.out.println("Invalid input. Returning to Manage Staff Menu.");
            input.nextLine();
            return;
        }

        int actions = input.nextInt();
        input.nextLine();

        switch (actions) {
            case 1:
                deactivateAcc(staffs, input, count);
                break;

            case 2:
                resetPassword(staffs, input, count);
                break;

            case 3:
                System.out.println("Returning to Manage Staff Menu...");
                break;

            default:
                System.out.println("Invalid option. Returning to Manage Staff Menu.");
        }
    }

    public static void displayStaffs(String[][] staffs, int count) {
        int displayCount = 0;

        System.out.printf("%-4s %-15s %-10s %-20s%n", "#", "Username", "Status", "Last Login");
        /*
        ANG KANANG NAAY MGA PERCENT(%) MGA SPACING VALUES NA SIYA PARA ALIGNED ANG PAG DISPLAY SA INFORMATION SA STAFFS
         */
        for (int i = 0; i < count; i++) {
            if (staffs[i] != null && staffs[i][0] != null) {
                System.out.printf("%-4d %-15s %-10s %-20s%n", (displayCount + 1), staffs[i][0], staffs[i][2], staffs[i][3]);
                displayCount++; //INCREMENT PARA MA-DISPLAY ANG UBANG ROWS SA ARRAY
            }
        }

        if (displayCount == 0) {
            System.out.println("No staff accounts to display.");
        }
    }

    public static void deactivateAcc(String[][] staffs, Scanner input, int count) {
        System.out.print("Enter staff username to deactivate: ");
        String username = input.nextLine();
        boolean userFound = false;

        for (int i = 0; i < count; i++) {
            if (staffs[i] != null && Objects.equals(username, staffs[i][0])) { //DAPAT DILI NULL ANG GIPANGITA AND EXISTING SIYA SA ARRAY
                System.out.println("Confirm account deactivation (y/n): ");
                String confirm = input.nextLine();
                if (confirm.equalsIgnoreCase("y")) {
                    System.out.println("Staff account " + staffs[i][0] + " has been successfully deactivated.");
                    staffs[i] = null;
                } else {
                    System.out.println("Deactivation cancelled.");
                }
                userFound = true;
                break;
            }
        }
        if (!userFound) {
            System.out.println("User not found.");
        }
    }

    public static void resetPassword(String[][] staffs, Scanner input, int count) {
        System.out.print("Enter staff username to reset password: ");
        String username = input.nextLine();
        boolean userFound = false;

        for (int i = 0; i < count; i++) {
            if (staffs[i] != null && Objects.equals(username, staffs[i][0])) {
                while (true) {
                    System.out.print("New password for [" + staffs[i][0] + "]: ");
                    String newPassword = input.nextLine();
                    System.out.print("Confirm password: ");
                    String confirmPassword = input.nextLine();
                    if (!Objects.equals(confirmPassword, newPassword)) {
                        System.out.println("Passwords don't match. Please try again.");
                    } else {
                        staffs[i][1] = newPassword;
                        System.out.println("Password for [" + staffs[i][0] + "] has been successfully reset.");
                        return;
                    }
                }
            }
        }
        if (!userFound) {
            System.out.println("User not found.");
        }
    }

}
