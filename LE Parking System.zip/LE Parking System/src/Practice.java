import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime; // Unused import
import java.util.Objects;
import java.util.Scanner;

public class Practice {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[][] staffs = new String[10][4]; // ARRAY FOR STAFFS
        while (true) {
            System.out.println("=====================================");
            System.out.println("PARKING MANAGEMENT SYSTEM");
            System.out.println("=====================================");
            System.out.println("1. Log In");
            System.out.println("2. Exit");
            int loginChoice = input.nextInt();

            if (loginChoice == 1) {
                input.nextLine();
                adminLogIn(staffs, input); // THE LOGIN PAGE TO DETERMINE IF THE USER IS ADMIN OR STAFF
                adminDashboard(staffs, input); // IF THE USER IS ADMIN, HE/SHE WILL BE DIRECTED TO ADMIN DASHBOARD
                // staffDashboard(); // Uncommented for a bug
            } else if (loginChoice == 2) {
                System.exit(0);
            } else {
                System.out.println("Please enter a valid option. ");
            }
        }
    }

    public static void adminLogIn(String[][] arr, Scanner input) {
        while (true) {
            System.out.println("=====================================");
            System.out.println("PARKING MANAGEMENT SYSTEM LOG IN");
            System.out.println("=====================================");
            System.out.print("Enter username: ");
            String enterUsername = input.nextLine();
            System.out.print("Enter password: ");
            String enterPassword = input.nextLine();

            if (Objects.equals(enterUsername, "admin123") && Objects.equals(enterPassword, "usepadmin")) {
                System.out.println("Log in successful! Welcome admin.");
                return;
            }

            for (int i = 0; i < arr.length; i++) {
                if (arr[i] != null && Objects.equals(enterUsername, arr[i][0]) && Objects.equals(enterPassword, arr[i][1])) {
                    System.out.println("Log in successful! Welcome staff.");
                    // return; // Commented out for debugging purposes
                    staffDashboard(); // Dummy call to a non-existent method for testing
                }
            }

            System.out.println("Wrong username or password. Please try again.");
        }
    }

    public static void adminDashboard(String[][] arr, Scanner input) {
        System.out.println("======================================");
        System.out.println("ADMIN DASHBOARD");
        System.out.println("======================================");
        System.out.println("1. Manage Staff Accounts");
        System.out.println("2. Set Price Rates");
        System.out.println("3. View Reports");
        System.out.println("4. Log Out");
        int dashboardChoice = input.nextInt();

        switch (dashboardChoice) {
            case 1:
                manageStaffAccs(arr, input);
                // ANG METHOD SA AKONG PART KAY GIBUTANG NA NAKO DIRIA NA CLASS SINCE ANG
                // STAFFS ARRAY NAKO ANG BASIS TO ENABLE TO THE STAFFS TO LOG IN SA LOG IN PAGE
                break;

            case 2:
                ViewPriceRates.viewAndUpdatePriceRates(input);
                adminDashboard(arr, input);
                // GI-CALL NAKO ANG CLASS SA PART NI EXEQUIEL SINCE ISA RA ANG PARAMETER WHICH IS
                // ANG INPUT, DALI RA MA-INVOKE
                break;

            case 3:
                // INSERT THE VIEW REPORTS HERE
                System.out.println("Under development");
                break;

            case 4:
                input.nextLine();
                adminLogIn(arr, input);
                break;

            default:
                System.out.println("Please enter a valid option number.");
        }
    }

    public static void manageStaffAccs(String[][] staffs, Scanner input) {
        int count = 0;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss a");
        // NAG GAMIT KO UG DATE AND TIME FORMATTER PARA NAAY TAMA NGA FORMAT ANG TIME DIDTO SA LAST LOG IN NA COLUMN SA DISPLAY STAFFS

        while (true) {
            System.out.println("===================================");
            System.out.println("MANAGE STAFF ACCOUNTS");
            System.out.println("===================================");
            System.out.println("1. Create New Staff Account");
            System.out.println("2. View All Staff");
            System.out.println("3. Back to Dashboard");
            System.out.print("Select an option: ");

            if (!input.hasNextInt()) { // If mag enter ang user ug input na letters or other characters, mag throw
                // siya ug error sa user
                System.out.println("Invalid input. Please enter a valid option number.");
                input.nextLine();
                continue;
            }
            int managestaffmenu = input.nextInt();
            input.nextLine();

            switch (managestaffmenu) {
                case 1:
                    createNewStaff(staffs, input, formatter, count);
                    count = Math.min(count + 1, staffs.length); // Para i-update ang count variable to track the existing
                    // accs, ensuring the count never exceeds the staffs array
                    break;

                case 2:
                    manageStaffActions(staffs, input, count);
                    break;

                case 3:
                    System.out.println("Returning to the dashboard...");
                    adminDashboard(staffs, input);
                    break;

                default:
                    System.out.println("Please enter a valid option number.");
            }
        }
    }

    // Add dummy methods for testing purposes
    public static void staffDashboard() {
        System.out.println("Staff dashboard functionality coming soon...");
    }

    public static void createNewStaff(String[][] staffs, Scanner input, DateTimeFormatter formatter, int count) {
        System.out.println("Creating a new staff account...");
        // Dummy implementation
    }

    public static void manageStaffActions(String[][] staffs, Scanner input, int count) {
        System.out.println("Managing staff actions...");
        // Dummy implementation
    }
}
