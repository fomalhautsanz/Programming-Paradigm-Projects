import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Scanner;

public class NewManageStaffAccs {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[][] staffs = new String[5][4]; // [username, password, status, last login]
        int count = 0;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss a");

        while (true) {
            System.out.println("===================================");
            System.out.println("MANAGE STAFF ACCOUNTS");
            System.out.println("===================================");
            System.out.println("1. Create New Staff Account");
            System.out.println("2. View All Staff");
            System.out.println("3. Back to Dashboard");
            System.out.print("Select an option: ");

            if (!input.hasNextInt()) { // If mag enter ang user ug input na letters or number greater than 3, dili siya pwede
                System.out.println("Invalid input. Please enter a valid option number.");
                input.nextLine();
                continue;
            }
            int managestaffmenu = input.nextInt();
            input.nextLine();

            switch (managestaffmenu) {
                case 1:
                    createNewStaff(staffs, input, formatter, count);
                    count = Math.min(count + 1, staffs.length); //Para i-update ang count variable to track the existing accs, ensuring the count never exceeds the staffs array
                    break;

                case 2:
                    manageStaffActions(staffs, input, count);
                    break;

                case 3:
                    System.out.println("Returning to the dashboard...");
                    input.close();

                default:
                    System.out.println("Please enter a valid option number.");
            }
        }
    }

    public static void createNewStaff(String[][] staffs, Scanner input, DateTimeFormatter formatter, int count) {
        System.out.println("===================================");
        System.out.println("CREATE A NEW STAFF ACCOUNT");
        System.out.println("===================================");
        if (count >= staffs.length) {
            System.out.println("Limit reached. Cannot create more accounts. Please contact the system developers.");
        } else {
            System.out.print("Enter new staff username: ");
            staffs[count][0] = input.nextLine();
            System.out.print("Enter new staff password: ");
            staffs[count][1] = input.nextLine();
            staffs[count][2] = "Active";
            staffs[count][3] = LocalDateTime.now().format(formatter);
            System.out.println("Account successfully created!");
        }
    }

    public static void manageStaffActions(String[][] staffs, Scanner input, int count) {
        System.out.println("===================================");
        System.out.println("VIEW ALL STAFFS");
        System.out.println("===================================");
        displayStaffs(staffs, count);

        if (count == 0) {
            System.out.println("No staff accounts available to manage.");
            return;
        }

        System.out.println("Actions: ");
        System.out.println("1. Deactivate a Staff Account");
        System.out.println("2. Reset Staff Password");
        System.out.println("3. Back to Manage Staff Menu");
        System.out.print("Select an action: ");

        if (!input.hasNextInt()) { //Checks the user input again para sa mga invalid inputs
            System.out.println("Invalid input. Returning to Manage Staff Menu.");
            input.nextLine();
            return;
        }

        int actions = input.nextInt();
        input.nextLine();

        switch (actions) {
            case 1:
                deactivateAcc(staffs, input, count);
                break;

            case 2:
                resetPassword(staffs, input, count);
                break;

            case 3:
                System.out.println("Returning to Manage Staff Menu...");
                break;

            default:
                System.out.println("Invalid option. Returning to Manage Staff Menu.");
        }
    }

    public static void displayStaffs(String[][] staffs, int count) {
        int displayCount = 0;

        System.out.printf("%-4s %-15s %-10s %-20s%n", "#", "Username", "Status", "Last Login");
        for (int i = 0; i < count; i++) {
            if (staffs[i] != null && staffs[i][0] != null) {
                System.out.printf("%-4d %-15s %-10s %-20s%n", (displayCount + 1), staffs[i][0], staffs[i][2], staffs[i][3]);
                displayCount++;
            }
        }

        if (displayCount == 0) {
            System.out.println("No staff accounts to display.");
        }
    }

    public static void deactivateAcc(String[][] staffs, Scanner input, int count) {
        System.out.print("Enter staff username to deactivate: ");
        String username = input.nextLine();
        boolean userFound = false;

        for (int i = 0; i < count; i++) {
            if (staffs[i] != null && Objects.equals(username, staffs[i][0])) {
                System.out.println("Confirm account deactivation (y/n): ");
                String confirm = input.nextLine();
                if (confirm.equalsIgnoreCase("y")) {
                    System.out.println("Staff account " + staffs[i][0] + " has been successfully deactivated.");
                    staffs[i] = null;
                } else {
                    System.out.println("Deactivation cancelled.");
                }
                userFound = true;
                break;
            }
        }
        if (!userFound) {
            System.out.println("User not found.");
        }
    }

    public static void resetPassword(String[][] staffs, Scanner input, int count) {
        System.out.print("Enter staff username to reset password: ");
        String username = input.nextLine();
        boolean userFound = false;

        for (int i = 0; i < count; i++) {
            if (staffs[i] != null && Objects.equals(username, staffs[i][0])) {
                userFound = true;
                while (true) {
                    System.out.print("New password for [" + staffs[i][0] + "]: ");
                    String newPassword = input.nextLine();
                    System.out.print("Confirm password: ");
                    String confirmPassword = input.nextLine();
                    if (!Objects.equals(confirmPassword, newPassword)) {
                        System.out.println("Passwords don't match. Please try again.");
                    } else {
                        staffs[i][1] = newPassword;
                        System.out.println("Password for [" + staffs[i][0] + "] has been successfully reset.");
                        return;
                    }
                }
            }
        }
        if (!userFound) {
            System.out.println("User not found.");
        }
    }
}

