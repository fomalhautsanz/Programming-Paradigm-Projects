package Exceptions;

public class SalaryException extends RuntimeException {
    public SalaryException(String message) {
        super(message);
    }
}
