package Employees;

public class Intern extends Employee{
    private String schoolName;

    public Intern(String name, double baseSalary, String position, String schoolName){
        super(name, baseSalary, position);
        this.schoolName=schoolName;
    }

    public String getSchoolName() {
        return schoolName;
    }

    @Override
    public double calculateSalary() {
        return super.calculateSalary();
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("School Name: " + getSchoolName());
    }
}
