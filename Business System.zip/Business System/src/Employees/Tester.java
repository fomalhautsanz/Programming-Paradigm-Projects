package Employees;

public class Tester {
    public static void main (String[] args){
        Manager employee = new Manager("Harris Style",-9000,"Manager",-9);
    }
}
