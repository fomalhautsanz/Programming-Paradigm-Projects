package Employees;

import Utils.TaxCalculator;

public class Developer extends Employee {
    private double performanceBonus;

    public Developer(String name, double baseSalary, String position, double performanceBonus){
        super(name, baseSalary, position);
        this.performanceBonus = performanceBonus;
    }

    public double getPerformanceBonus() {
        return performanceBonus;
    }

    @Override
    public double calculateSalary() {
        return super.calculateSalary()+performanceBonus;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Performance Bonus: " + getPerformanceBonus());
        System.out.println("Total Salary (Before Tax): " + calculateSalary());
        System.out.println("Tax Deduction: " + TaxCalculator.calculateTax(calculateSalary()));
    }
}
