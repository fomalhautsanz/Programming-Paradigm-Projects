package Employees;

public class Employee {
    private String name;
    private double baseSalary;
    private String position;

    public Employee(String name,double baseSalary,String position){
        this.name=name;
        this.baseSalary=baseSalary;
        this.position=position;
    }

    public String getName() {
        return name;
    }

    public double getBaseSalary(){
        return baseSalary;
    }

    public String getPosition(){
        return position;
    }

    public double calculateSalary(){
        return baseSalary;
    }

    public void displayInfo(){
        System.out.println("Name: " + getName());
        System.out.println("Base Salary: " + getBaseSalary());
        System.out.println("Position: " + getPosition() );
    }

}
