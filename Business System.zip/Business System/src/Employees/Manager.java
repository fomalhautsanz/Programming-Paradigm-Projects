package Employees;

public class Manager extends Employee{
    private double bonus;

    public Manager(String name, double baseSalary, String position, double bonus){
        super(name, baseSalary, position);
            this.bonus = bonus;
    }

    public double getBonus() {
        return bonus;
    }

    @Override
    public double calculateSalary() {
        return super.calculateSalary()+bonus;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Bonus: " + getBonus());
    }
}
