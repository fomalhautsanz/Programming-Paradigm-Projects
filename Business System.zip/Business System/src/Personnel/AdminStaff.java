package Personnel;

import Exceptions.InvalidPositionException;

import java.util.Objects;

public class AdminStaff extends Personnel{

    private String role;

    AdminStaff(String name,String department,String role){
        super(name, department);
        this.role=role;
    }

    public String getRole() {
        return role;
    }

    public double calculateSalary() {
        double salary = 0;

        if (Objects.equals(role, "Accountant")){
            salary=28000;
            setBaseSalary(salary);
        }
        else if (Objects.equals(role, "Registrar")) {
            salary=23000;
            setBaseSalary(salary);
        }
        else if (Objects.equals(role, "Librarian")) {
            salary=20000;
        }
        else {
            throw new InvalidPositionException(getName() + "'s role does not exist in admin staffs");
        }
        return salary;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
    }
}
