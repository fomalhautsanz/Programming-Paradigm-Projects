package Personnel;

import PersonnelSalary.PersonnelTaxCalculator;
import Utils.TaxCalculator;

import java.util.UUID;
import PersonnelSalary.PersonnelTaxCalculator;
import PersonnelSalary.Salary;

public class Personnel {
    private String name;
    private UUID id = UUID.randomUUID();
    private String department;
    private double baseSalary;
    Salary salary = new Salary();

    Personnel(String name,String department){
        this.name=name;
        this.department=department;
    }

    public String getName() {
        return name;
    }

    public UUID getId() {
        return id;
    }

    public String getDepartment() {
        return department;
    }

    public void setBaseSalary(double baseSalary) {
        this.baseSalary = baseSalary;
    }

    public double calculateSalary(){
        return baseSalary;
    }

    public void displayInfo(){
        try {
            System.out.println("--------------------------------------------------------");
            System.out.println("Name: " + getName());
            System.out.println("ID: " + getId());
            System.out.println("Department: " + getDepartment());
            System.out.println("Base Salary: " + calculateSalary());
            System.out.println("Tax: " + PersonnelTaxCalculator.calculateTax(this));
            System.out.println("Net Salary: " + salary.applyTax(this));
            System.out.println("--------------------------------------------------------");
        } catch (Exception e) {
            System.out.println("\n⚠ ERROR: " + e.getMessage());
        }
    }
}
