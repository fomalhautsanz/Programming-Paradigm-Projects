package Personnel;

import Exceptions.InvalidPositionException;

import java.util.Objects;

public class Professor extends Personnel{
    private String rank;

    Professor(String name,String department,String rank){
        super(name, department);
        this.rank=rank;
    }

    public String getRank() {
        return rank;
    }

    @Override
    public double calculateSalary() {
        double salary = 0;

        if (Objects.equals(rank, "Assistant")){
            salary=20000;
            setBaseSalary(salary);
        }
        else if (Objects.equals(rank, "Associate")) {
            salary=30000;
            setBaseSalary(salary);
        }
        else if (Objects.equals(rank, "Full")) {
            salary=40000;
        }
        else {
            throw new InvalidPositionException(getName() + "'s role does not exist in faculty\n");
        }

        return salary;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
    }
}
