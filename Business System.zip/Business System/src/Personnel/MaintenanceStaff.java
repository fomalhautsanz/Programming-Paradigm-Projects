package Personnel;

public class MaintenanceStaff extends Personnel{
    private int hoursWorked;

    MaintenanceStaff(String name,String department,int hoursWorked){
        super(name, department);
        this.hoursWorked=hoursWorked;
    }

    public int getHoursWorked() {
        return hoursWorked;
    }

    @Override
    public double calculateSalary() {
        return 300 * hoursWorked;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
    }
}
