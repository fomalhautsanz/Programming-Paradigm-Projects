package Personnel;

public class PersonnelMain {
    public static void main (String[] args){


            Professor professor = new Professor("Roberto Delos Reyes", "Faculty", "Associat");
            AdminStaff adminStaff = new AdminStaff("Merlinda Perez", "Admin", "Registrar");
            MaintenanceStaff maintenanceStaff = new MaintenanceStaff("Lito Bernin", "Maintenance", 12);

            professor.displayInfo();
            adminStaff.displayInfo();
            maintenanceStaff.displayInfo();
    }
}
