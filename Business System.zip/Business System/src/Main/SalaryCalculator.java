package Main;

import Employees.Developer;
import Employees.Employee;
import Employees.Manager;
import Employees.Intern;
import Exceptions.InvalidSalaryException;
import Exceptions.NegativeSalaryException;
import Utils.TaxCalculator;

import java.util.Date;

public class SalaryCalculator {

    public double calculateSalary(Employee employee) throws InvalidSalaryException{
        double salary = employee.calculateSalary();

        if (salary<0){
            throw new NegativeSalaryException("Salary for " + employee.getName() + " must be positive\n----------------------------------------------\n");
        }
        else if (salary>100000){
            throw new InvalidSalaryException("Unrealistic salary detected for " + employee.getName());
        }

        return salary;
    }

    public double calculateSalary(Employee employee, double bonus) throws InvalidSalaryException{
        if (employee instanceof Intern){
            throw new InvalidSalaryException("Only managers and developers can avail a bonus");
        }

        double salary = employee.calculateSalary();
        return calculateSalary(employee);
    }

    public double applyTax(Employee employee) throws InvalidSalaryException{
        double salary = calculateSalary(employee);
        double tax = TaxCalculator.calculateTax(salary);
        return salary-tax;
    }
}
