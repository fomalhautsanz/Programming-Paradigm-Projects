package Main;

import Employees.Developer;
import Employees.Employee;
import Employees.Intern;
import Employees.Manager;
import Utils.TaxCalculator;

public class Main {
    public static void main (String[] args){

        Business myCompany = new Business("TechSolutions");

        Manager manager = new Manager("Piolo Mard",-70800,"Manager",5000);
        Developer developer = new Developer("John Hobkins",35000,"Developer",4000);
        Intern intern = new Intern("Grace Mellow",17000,"Intern","University of Michigan");

        myCompany.addEmployee(manager);
        myCompany.addEmployee(developer);
        myCompany.addEmployee(intern);

        SalaryCalculator calculator = new SalaryCalculator();

        System.out.println("=============== PAYROLL PROCESSING ===============");

        for ( Employee emp : myCompany.getEmployeeList()){
            try {
                double grossSalary = 0;
                if (emp instanceof Intern){
                    grossSalary = calculator.calculateSalary(emp);
                }
                else if (emp instanceof Manager) {
                    grossSalary = calculator.calculateSalary(emp,((Manager) emp).getBonus());
                }
                else if (emp instanceof Developer) {
                    grossSalary = calculator.calculateSalary(emp,((Developer) emp).getPerformanceBonus());
                }

                double taxCalculator = TaxCalculator.calculateTax(grossSalary);
                double netSalary = calculator.applyTax(emp);

                System.out.println("Employee Name: " + emp.getName());
                System.out.println("Position: " + emp.getPosition());
                System.out.println("Base Salary: " + emp.getBaseSalary());
                if (emp instanceof Manager){
                    System.out.println("Bonus: " + ((Manager) emp).getBonus());
                }
                if (emp instanceof Developer){
                    System.out.println("Performance Bonus: " + ((Developer) emp).getPerformanceBonus());
                }
                System.out.println("Total Salary (Before Tax): " + grossSalary);
                System.out.println("Tax Deduction: " + taxCalculator);
                System.out.println("Final Salary: " + netSalary);

                System.out.println("\n----------------------------------------------\n");
            } catch (Exception e){
                System.out.println("\n⚠ ERROR: " + e.getMessage());
            }
            }

        myCompany.displayPayroll();
    }
}
