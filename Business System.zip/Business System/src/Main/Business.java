package Main;

import Employees.Employee;
import java.util.ArrayList;
import java.util.List;


public class Business {
    private String name;
    private List<Employee> employeeList;
    private static double totalPayroll = 0;

    public Business (String name){
        this.name=name;
        this.employeeList=new ArrayList<>();
    }

    public void addEmployee(Employee employee){
        employeeList.add(employee);
    }

    public double calculateTotalPayroll(){
        double total = 0;


        for (Employee emp : employeeList){
            if (emp.calculateSalary()<0 || emp.calculateSalary()>100000){
                continue;
            }
            total += emp.calculateSalary();
        }
        totalPayroll=total;
        return total;
    }

    public void displayPayroll(){
        System.out.println("============= " + name + " PAYROLL SUMMARY =============");

        for (Employee emp : employeeList){

            if (emp.calculateSalary()<0 || emp.calculateSalary()>100000){
                continue;
            }
            System.out.println("NAME: " + emp.getName() + " | " + "SALARY: " + emp.calculateSalary());
        }

        System.out.println("TOTAL PAYROLL EXPENSE: $" + calculateTotalPayroll());
        System.out.println("=====================================================");
    }

    public static double getTotalPayroll() {
        return totalPayroll;
    }

    public List<Employee> getEmployeeList() {
        return employeeList;
    }
}
