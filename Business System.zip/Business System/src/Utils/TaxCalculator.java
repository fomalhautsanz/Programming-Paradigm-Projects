package Utils;

public class TaxCalculator {
    private static final double LOW_TAX_RATE = 0.10;
    private static final double MID_TAX_RATE = 0.20;
    private static final double HIGH_TAX_RATE = 0.30;

    public static double calculateTax(double salary){
        if (salary<20000){
            return salary*LOW_TAX_RATE;
        }
        else if (salary<=45000){
            return salary*MID_TAX_RATE;
        }
        else {
            return salary*HIGH_TAX_RATE;
        }
    }
}
