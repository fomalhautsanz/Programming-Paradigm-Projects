package PersonnelSalary;

import Employees.Employee;
import Personnel.Personnel;
import Personnel.Professor;
import Personnel.AdminStaff;
import Personnel.MaintenanceStaff;

public class PersonnelTaxCalculator {
    private static final double LOW_TAX_RATE = 0.05;
    private static final double MID_TAX_RATE = 0.08;
    private static final double HIGH_TAX_RATE = 0.10;

    public static double calculateTax(Personnel personnel){

        double tax=0;

        if (personnel instanceof Professor){
           tax = personnel.calculateSalary()*HIGH_TAX_RATE;
        }
        else if (personnel instanceof AdminStaff){
            tax = personnel.calculateSalary()*MID_TAX_RATE;
        }
        else if (personnel instanceof MaintenanceStaff){
            tax = personnel.calculateSalary()*LOW_TAX_RATE;
        }

        return tax;
    }
}
