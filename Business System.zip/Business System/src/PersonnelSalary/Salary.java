package PersonnelSalary;

import Employees.Employee;
import Exceptions.InvalidSalaryException;
import Exceptions.NegativeSalaryException;
import Personnel.Personnel;

public class Salary {

    public double salaryCalculator(Personnel personnel) throws InvalidSalaryException{
        double salary = personnel.calculateSalary();

        if (salary<0){
            throw new NegativeSalaryException(personnel.getName() + "'s salary must be positive!");
        }
        else if (salary>100000){
            throw new InvalidSalaryException(personnel.getName() + "'s salary is unrealistic");
        }

        return salary;
    }


    public double applyTax(Personnel personnel) throws InvalidSalaryException{
        double salary = salaryCalculator(personnel);
        double tax = PersonnelTaxCalculator.calculateTax(personnel);

        return salary-tax;
    }

}
