public class CatTest {
    public static void main (String[] args){
        Cat meowyCat = new Cat();
        meowyCat.actions();
    }
}
