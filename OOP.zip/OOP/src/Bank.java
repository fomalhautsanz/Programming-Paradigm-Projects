import java.util.Scanner;

public class Bank {
    Scanner input = new Scanner(System.in);

    String name;
    String accountNum;
    double balance;
    double deposit;
    double withdraw;

    void deposit(double depositAmount){
       if (depositAmount>0){
           balance+=depositAmount;
           System.out.println("Money deposited successfully!");
       }
       else {
           System.out.println("Deposit amount must be positive!");
       }
    }

    void withdraw(double withdrawAmount){

        if (withdrawAmount>balance){
            System.out.println("Insufficient funds!");
        }
        else if (withdrawAmount>0){
            balance-=withdrawAmount;
            System.out.println("Withdraw successful!");
        }
        else {
            System.out.println("Withdraw amount must be positive!");
        }
    }

    void displayAcc(){
        System.out.println("Name: " + name);
        System.out.println("Account Number: " + accountNum);
        System.out.println("Balance: " + balance);
        System.out.println();
    }

    void bankMenu(){
        int choice;

            while (true) {
                System.out.println("Choose an action for this account:" +
                        "\n1.) Deposit Money" +
                        "\n2.) Withdraw Money" +
                        "\n3.) None");
                choice = input.nextInt();

                if (choice==1){
                    System.out.print("Enter the amount you want to deposit: ");
                    double depositAmount = input.nextDouble();
                    deposit(depositAmount);
                    System.out.println();
                    displayAcc();
                }
                else if (choice==2){
                    System.out.print("Enter the amount you want to withdraw: ");
                    double withdrawAmount = input.nextDouble();
                    withdraw(withdrawAmount);
                    System.out.println();
                    displayAcc();
                }
                else if (choice==3){
                    break;
                }
            }

    }


}
