public class Car {
    String make;
    String model;
    int year;
    double price;

    void displayInfo(){
        System.out.println();
        //NOTE: CALL THE VARIABLES
        System.out.println("Car Make: " + make);
        System.out.println("Model: " + model);
        System.out.println("Year: " + year);
        System.out.println("Price: " + price);
        System.out.println();
    }

    void applyDiscount (double rate){
        //NOTE: BUHATIG PARAMETER NA MO-RECEIVE SA PERCENTAGE NA I-INPUT SA USER
        //NOTE: FORMULA FOR CALCULATING DISCOUNTED PRICE
        price = price - (price*rate/100);
    }
}

