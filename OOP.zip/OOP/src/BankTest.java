import java.util.Scanner;

public class BankTest {
    public static void main (String[] args){
        Scanner input = new Scanner(System.in);

        Bank acc1 = new Bank();
        acc1.name = "Lyn Ortega";
        acc1.accountNum = "C01278";
        acc1.balance = 0;

        acc1.displayAcc();
        acc1.bankMenu();
    }
}
