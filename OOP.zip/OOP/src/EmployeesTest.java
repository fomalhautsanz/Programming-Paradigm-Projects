import java.util.Scanner;

public class EmployeesTest {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);

        Employees employee1 = new Employees();
        Employees employee2 = new Employees();

        System.out.println("EMPLOYEE 1");
        employee1.name = "Lily Cruz";
        employee1.jobTitle = "HR Manager";
        employee1.salary = 14000;
        employee1.displayEmployee();

        System.out.print("Do you want to update " + employee1.name + "'s salary? (Y/N): ");
        String choice = input.nextLine();

        if (choice.equalsIgnoreCase("y")){
            System.out.print("Enter the increase rate of salary: ");
            double rate = input.nextDouble();
            input.nextLine();

            double updatedSalary = employee1.updateSalary(rate);
            employee1.setSalary(updatedSalary);
            employee1.displayEmployee();
        }
        System.out.println();

        System.out.println("EMPLOYEE 2");
        employee2.name = "Herman Torres";
        employee2.jobTitle = "Finance Manager";
        employee2.salary = 18000;
        employee2.displayEmployee();

        System.out.print("Do you want to update " + employee2.name + "'s salary? (Y/N): ");
        choice = input.nextLine();

        if (choice.equalsIgnoreCase("y")){
            System.out.print("Enter the increase rate of salary: ");
            double rate = input.nextDouble();
            input.nextLine();

            double updatedSalary = employee2.updateSalary(rate);
            employee2.setSalary(updatedSalary);
            employee2.displayEmployee();
        }
        System.out.println();
    }
}
