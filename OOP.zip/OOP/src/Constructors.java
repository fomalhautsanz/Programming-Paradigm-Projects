

public class Constructors {

    String element;
    int num;

    public Constructors(String elementName, int atomicNum){
        element=elementName;
        num=atomicNum;
    }

    public static void main(String[] args){
        Constructors elementPeriodic = new Constructors("Oxygen", 8);
        System.out.print(elementPeriodic.element + " " + elementPeriodic.num);
    }

}
