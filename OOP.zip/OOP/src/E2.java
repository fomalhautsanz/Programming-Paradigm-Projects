import java.util.Scanner;

public class E2 {
    public static void main (String[] args){
        Scanner input = new Scanner(System.in);

        System.out.println("===============================");
        System.out.println("WELCOME TO MY MUSIC");
        System.out.println("===============================");
        System.out.println("\n1.) Add Song\n" +
                "2.) Display Song List\n" +
                "3.) Remove Song\n" +
                "4.) Play Random Song");
        int choice = input.nextInt();

        switch (choice){
            case 1:
                int i=0;
                    System.out.print("Enter song title: ");
                    String songTitle = input.nextLine();
                    System.out.print("Enter song artist: ");
                    String songArtist = input.nextLine();

                    E1 songs = new E1(songTitle, songArtist);
                    songs.addSong(songs);
                    System.out.println("Song added to the list successfully!");
                    break;

            case 2:
                E1 display = new E1();
                display.displaySongs();
                break;

            case 3:
                System.out.print("Enter the song number you want to delete: ");
                int songNum = input.nextInt();


        }
    }
}
