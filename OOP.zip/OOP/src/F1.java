import java.util.Objects;
import java.util.Scanner;

public class F1 {
    private String name;
    private String accountType;
    private int ID;
    private double balance;
    private String username;
    private String password;
    Scanner input = new Scanner(System.in);

    F1(String name,String accountType, int ID, double balance){
        this.name=name;
        this.accountType=accountType;
        this.ID=ID;
        this.balance=balance;
    }

    public void menu(){
        while (true) {
            displayInfo();
            input.nextLine();
            System.out.println("1. Deposit Money");
            System.out.println("2. Withdraw Money");
            System.out.println("3. Exit");
            int choice = input.nextInt();
            input.nextLine();
            if (choice==1){
                System.out.print("Enter deposit: "); double deposit = input.nextInt();
                deposit(deposit);
            }
            else if (choice==2){
                System.out.print("Enter withdraw amount: "); double withdraw = input.nextInt();
                withdraw(withdraw);
            }
            else if (choice==3){
                System.out.println("Now exiting the program...");
                System.exit(0);
            }
        }
    }
    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setName(String newName){
        this.name=newName;
    }

    public String getName(){
        return name;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getID() {
        return ID;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public void deposit(double depositMoney){
        balance+=depositMoney;
    }

    public void withdraw(double withdrawMoney){
        if (withdrawMoney>balance){
            System.out.println("Insufficient funds!");
        }
        else if (withdrawMoney>0){
            balance-=withdrawMoney;
            System.out.println("Withdraw successful!");
        }
    }

    public void displayInfo(){
        System.out.println("Name: " + getName());
        System.out.println("Account Type: " + getAccountType());
        System.out.println("ID: " + getID());
        System.out.println("Balance: " + getBalance());
    }
}

class F2{
    public static void main (String[] args){
        Scanner input = new Scanner(System.in);
        F1 client1 = new F1("Mandy Gomez","Savings",1010,500);
        client1.setUsername("gomez1010"); client1.setPassword("000qwerty");

        System.out.println("WELCOME TO MYBANK!");
        System.out.println("1. Log In");
        System.out.println("2. Exit");
        int choice = input.nextInt();
        input.nextLine();
        if (choice==1){
            System.out.print("Enter username: ");
            String username = input.nextLine();
            System.out.print("Enter password: ");
            String password = input.nextLine();

            if (Objects.equals(username, client1.getUsername()) && Objects.equals(password, client1.getPassword())){
                client1.menu();
            }
            else {
                System.out.println("Incorrect username/password,");
            }
        }
        else if (choice==2){
            System.out.println("Now exiting...");
            System.exit(0);
        }
    }
}
