public class Planets {

    String planet;
    String type;
    String revolution;
    String diameter;
}
