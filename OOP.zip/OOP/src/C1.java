public class C1 {
    private String userName;
    private String password;
    private int id;

    C1(String userName, String password, int id){
        this.userName = userName;
        this.password = password;
        this.id = id;
    }

    void setUserName(String newUserName){
        userName = newUserName;
    }

    String getUserName(){
        return userName;
    }
    void setPassword(String newPassword){
        userName = newPassword;
    }

    String getPassword(){
        return password;
    }
}
