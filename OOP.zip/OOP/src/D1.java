public class D1 {
    private String title;
    private String author;
    private String ISBN;
    static D1[] books = new D1[100];

    D1(){

    }

    D1(String title, String author, String ISBN){
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
    }

    void addBook(D1 book){
        for (int i=0; i<100; i++){
            if (books[i]==null){
                books[i] = book;
                break;
            }
        }
    }

    String getTitle(){
        return title;
    }

    void setTitle(String newTitle){
        title = newTitle;
    }

    String getAuthor(){
        return author;
    }

    void setAuthor(String newAuthor){
        author = newAuthor;
    }

    String getISBN(){
        return ISBN;
    }

    void setISBN(String newISBN){
        ISBN = newISBN;
    }

    void removeBook(D1 removeBook){
        for (int i=0; i<100; i++){
            if (books[i]==removeBook){
                books[i]=null;
                break;
            }
        }
    }

    void displayBook(){
        for (D1 books : books){
            if (books!=null) {
                System.out.println("Title: " + books.title);
                System.out.println("Author: " + books.author);
                System.out.println("ISBN: " + books.ISBN);
                System.out.println();
            }
        }
    }

}
