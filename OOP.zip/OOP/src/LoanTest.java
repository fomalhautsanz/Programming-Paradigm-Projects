import java.util.Scanner;

public class LoanTest {
    public static void main (String[] args){
        Scanner input = new Scanner(System.in);
        Loan myLoan = new Loan("Anna Myers","P1109");
        System.out.println("1. Loan  Using Simple Interest");
        System.out.println("2. Loan  Using Compound Interest");
        int choice = input.nextInt();

        if (choice==1){
            System.out.print("Enter loan amount: ");
            double loan = input.nextDouble();
            myLoan.setLoanAmount(loan);
            System.out.print("Enter rate: ");
            double rate = input.nextDouble();
            System.out.print("Enter years to pay: ");
            int years = input.nextInt();
            myLoan.loanUsingSimpleInterest(rate,years);
            System.out.println("Interest: " + myLoan.getInterest());
            System.out.println("Amount to pay: " + myLoan.getTotalAmount());
        }
        else if (choice==2){
            System.out.print("Enter loan amount: ");
            double loan = input.nextDouble();
            myLoan.setLoanAmount(loan);
            System.out.print("Enter rate: ");
            double rate = input.nextDouble();
            System.out.print("Enter years to pay: ");
            int years = input.nextInt();
            myLoan.loanUsingCompound(rate,years);
            System.out.println("Interest: " + myLoan.getInterest());
            System.out.println("Amount to pay: " + myLoan.getTotalAmount());
        }
    }
}
