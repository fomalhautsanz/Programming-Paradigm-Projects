import java.util.Scanner;

public class Coffee {
    Scanner input = new Scanner(System.in);
    String coffeeName;
    double price;
    Coffee[] flavors = new Coffee[100];
    int count=0;

    void displayMenu(){
        while (true){
            System.out.println("===========================================");
            System.out.println("WELCOME TO CAFE SMILE ^^");
            System.out.println("===========================================");
            System.out.println("1.) Display Cafe Menu\n" +
                    "2.) Apply a Discount\n" +
                    "3.) Add New Coffee Flavor\n" +
                    "4.) Remove a Coffe Flavor\n" +
                    "5.) Exit");
            int choice = input.nextInt();
            input.nextLine();
            if (choice==1){
                displayFlavors();
            }
            else if (choice==2){
                applyDiscount();
            }
            else if (choice==3){
                addFlavor();
            }
            else if (choice==4){
                removeFlavor();
            }
            else if (choice==5){
                System.out.println("Thank you for stopping by! Please come again");
                System.exit(0);
            }
            else {
                System.out.println("Please enter a valid option");
            }
        }
    }

    void displayFlavors(){

        if (count==0){
            System.out.println("The menu is currently empty...");
            return;
        }
        for (int i=0; i<flavors.length; i++) {
            if (flavors[i] != null) {
                System.out.println((i+1) + ").");
                System.out.println("Flavor: " + flavors[i].coffeeName);
                System.out.println("Price: " + flavors[i].price);
            }
        }
    }

    void applyDiscount(){
        displayFlavors();
        System.out.print("Enter the coffee number to be discounted: ");
        int choice = input.nextInt();

        if (choice>count){
            System.out.println("Invalid input!");
            return;
        }
        System.out.print("Enter the discount rate (%):");
        double rate = input.nextDouble();
        flavors[choice-1].price-=(flavors[choice-1].price*rate/100);
        System.out.println("Discounted successfully!\n");
    }

    void addFlavor(){
        flavors[count] = new Coffee();
        if (flavors[count]!=null){
            System.out.print("Enter coffee flavor: ");
            flavors[count].coffeeName = input.nextLine();
            System.out.print("Enter price: ");
            flavors[count].price = input.nextDouble();
            input.nextLine();
            count++;
            System.out.println("Coffee flavor added successfully!\n");
        }
    }

    void removeFlavor(){
            displayFlavors();
            System.out.print("Enter coffee number to delete: ");
            int num = input.nextInt();

            if (num > count) {
                System.out.println("Invalid input!");
                return;
            }

           for (int i=num-1; i<count-1; i++){
               flavors[i]=flavors[i+1];
           }
           flavors[count-1]=null;
           count--;
    }
}
