public class Employees {
    String name;
    String jobTitle;
    double salary;

    void displayEmployee(){
        System.out.println("Employee Name: " + name);
        System.out.println("Job Title: " + jobTitle);
        System.out.println("Salary: " + salary);
    }

    double updateSalary(double rate){
        return salary=salary+(salary*rate/100);
    }


    void setSalary(double updatedSalary){
        salary=updatedSalary;
    }
}
