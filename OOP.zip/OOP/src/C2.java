public class C2 {
    public static void main (String[] args){
        C1 tryIt = new C1("Wawex","wawex143",13341);
        tryIt.setUserName("Krazy");
        String username = tryIt.getUserName();
        System.out.println(username);
    }
}
