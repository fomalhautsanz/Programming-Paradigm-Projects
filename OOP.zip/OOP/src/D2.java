public class D2 {
    public static void main (String[] args){
        D1 book1 = new D1("Harry Potter","JK Rowling","120089210");
        D1 book2 = new D1("No Longer Human","Osamu Dazai","1908476510");

        book1.addBook(book1);
        book2.addBook(book2);

        book1.removeBook(book1);
        D1 display = new D1();
        display.displayBook();
    }
}
