public class SavingsAccountTest {
    public static void main (String[] args){

        SavingsAccount saver1 = new SavingsAccount();
        saver1.setSavingsBalance(2000);

        SavingsAccount saver2 = new SavingsAccount();
        saver2.setSavingsBalance(3000);

        SavingsAccount.modifyInterestRate(4);

        System.out.println("---------------- Configuration: <Default> ---------------");
        System.out.println("New balance for Saver1=" + saver1.calculateMonthlyInterest(SavingsAccount.getAnnualInterestRate()));
        System.out.println("New balance for Saver2=" + saver2.calculateMonthlyInterest(SavingsAccount.getAnnualInterestRate()));

        SavingsAccount.modifyInterestRate(5);

        System.out.println("New balance for Saver1=" + saver1.calculateMonthlyInterest(SavingsAccount.getAnnualInterestRate()));
        System.out.println("New balance for Saver2=" + saver2.calculateMonthlyInterest(SavingsAccount.getAnnualInterestRate()));

    }
}
