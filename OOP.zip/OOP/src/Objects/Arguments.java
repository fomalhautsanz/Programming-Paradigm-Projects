package Objects;

public class Arguments {
    int a;

    Arguments(int x){
        a=x;
    }

    Arguments calculate(){
        Arguments arg = new Arguments(a+10);
        return arg;
    }
}

class Main{
    public static void main (String[] args){
        Arguments a1 = new Arguments(10);
        System.out.println("a=" + a1.a);
        Arguments a2 = a1.calculate();
        System.out.println("a=" + a2.a);
        a2 = a2.calculate();
        System.out.println("a=" + a2.a);
    }
}
