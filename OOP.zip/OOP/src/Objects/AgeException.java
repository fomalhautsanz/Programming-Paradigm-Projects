package Objects;

public class AgeException extends Exception{

    AgeException(String message){
        super(message);
    }
}
