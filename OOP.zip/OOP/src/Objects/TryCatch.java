package Objects;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TryCatch {
   public static void main (String[] args){
       Scanner input = new Scanner (System.in);

       do {
           try {
               System.out.print("Enter a number: ");
               int num = input.nextInt();
               System.out.println(Math.pow(num,2));
               break;
           } catch (InputMismatchException e){
               input.nextLine();
               System.out.println("Please enter a number!");
           }
       } while (true);
   }
}
