package Objects;

import java.util.Scanner;

public class AgeTest {
    public static void main (String[] args){
        Scanner input = new Scanner(System.in);

        System.out.print("Enter your age: ");
        int age = input.nextInt();

        try {
            checkAge(age);
        } catch (AgeException e){
            System.out.println("A problem occurred: " + e);
        }
    }

    static void checkAge(int age) throws AgeException{
        if (age<18){
            throw new AgeException("\nYou must be 18+ to sign up.");
        }
        else {
            System.out.println("Successfully signed up!");
        }
    }
}
