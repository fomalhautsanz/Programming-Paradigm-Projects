public class Loan {
    private String name;
    private String ID;
    private double loanAmount;
    private double totalAmount;
    double rate;
    int years;
    private double interest;

    Loan(String name,String ID){
        this.name=name;
        this.ID=ID;
    }

    public double getInterest() {
        return interest;
    }

    public String getName() {
        return name;
    }

    public void setLoanAmount(double totalAmount) {
        this.loanAmount = totalAmount;
    }

    public String getID() {
        return ID;
    }

    public double getLoanAmount() {
        return loanAmount;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void loanUsingSimpleInterest(double rate, int years){
        interest=(loanAmount*rate*years)/100;
        totalAmount=loanAmount+interest;
    }

    public void loanUsingCompound(double rate, int years){
        interest=loanAmount*(Math.pow((1+rate/100),years));
        totalAmount=loanAmount+interest;
    }
}
