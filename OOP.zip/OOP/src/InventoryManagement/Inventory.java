package InventoryManagement;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Inventory {
    static Scanner input = new Scanner(System.in);
    static Product[] products;
    static int totalProducts;
    static int count=0;

    Inventory(){
        products = new Product[100];
    }


    public void addProduct(Product p){
        products[count]=new Product();
        if (products[count]!=null){
            products[count]=p;
            count++;
            System.out.println("Product added successfully!");
        }
    }

    public void addProduct(String name, double price){
        products[count]=new Product();
        if (products[count] != null){
            products[count].setName(name);
            products[count].setPrice(price);
            count++;
            System.out.println("Product added successfully!");
        }
    }

    public void updateStock(Product p, int quantity){

        if (p!=null){
            p.updateStock(quantity);
        } else {
            System.out.println("Invalid product");
        }

    }

    public static void displayTotalProducts(){

        if (count==0){
            System.out.println("No products in inventory");
            return;
        }

        for (int j = 0; j < count; j++) {
            System.out.println((j + 1) + "). ");
            products[j].displayProduct();
            System.out.println("------------------------------------------");
        }
    }

    public static int getTotalProducts(){
        totalProducts=count;
        return totalProducts;
    }

    public static void main (String[] args) throws IOException {
        Inventory inventory = new Inventory();

        while (true) {
            try {
                menu(inventory);
            } catch (InputMismatchException e) {
                input.nextLine();
                System.out.println("Please enter valid inputs");
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Number index not found in the list");
            }
            catch (NullPointerException e){
                System.out.println("That number does not exist");
            }
        }


    }

    public static void menu(Inventory inventory){


        System.out.println("1. Add Product");
        System.out.println("2. Display Products");
        System.out.println("3. Add Stock");
        System.out.println("4. Exit");
        int choice = input.nextInt();
        input.nextLine();

        switch (choice){
            case 1:
                Product product = new Product();
                System.out.print("Enter ID: " );
                product.setId(input.nextInt());
                input.nextLine();
                System.out.print("Enter Name: " );
                product.setName(input.nextLine());
                System.out.print("Enter Price: " );
                product.setPrice(input.nextDouble());
                System.out.print("Enter Quantity: " );
                product.setQuantity(input.nextInt());

                inventory.addProduct(product);
                break;

            case 2:
                Inventory.displayTotalProducts();
                break;

            case 3:
                Inventory.displayTotalProducts();
                System.out.print("Enter product number: ");
                choice = input.nextInt();

                System.out.print("Enter quantity: ");
                int quantity = input.nextInt();
                Inventory.products[choice-1].updateStock(quantity);
                break;

            case 4:
                System.out.println("Now exiting the program...");
                System.exit(0);
                break;

            default:
                System.out.println("An error occurred.");
        }
    }


/*
    public static void main (String[] args) throws IOException {

        Scanner input = new Scanner(System.in);
        Product product1 = new Product(12009, "Pepper Spray", 250, 10);
        Inventory inventory = new Inventory();
        inventory.addProduct(product1);
        inventory.addProduct("Bombshell",300);
        inventory.updateStock(product1,15);
        Inventory.displayTotalProducts();
        System.out.println("Total products: " + Inventory.getTotalProducts());

    }

 */
}
