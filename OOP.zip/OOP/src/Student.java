public class Student {
    String name;
    String idNum;

}
