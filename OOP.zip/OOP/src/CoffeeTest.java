public class CoffeeTest {
    public static void main (String[] args) {
        Coffee myCafe = new Coffee();
        myCafe.displayMenu();
    }
}
