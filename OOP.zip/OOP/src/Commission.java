public class Commission {
    private double principal;
    private double commissionRate;

    Commission(){

    }

    Commission(double principal,double commissionRate){
        this.principal=principal;
        this.commissionRate=commissionRate;
    }

    public void setPrincipal(double principal) {
        this.principal = principal;
    }

    public double getPrincipal() {
        return principal;
    }

    public void setCommissionRate(double commissionRate) {
        this.commissionRate = commissionRate;
    }

    public double getCommissionRate() {
        return commissionRate;
    }

    public void calculate(){
        double total;
        total=getPrincipal()*getCommissionRate();
        System.out.println("Total: " + total);
    }
}

class CommissionTest{
    public static void main (String[] args){
        Commission myCommission = new Commission();

        myCommission.setPrincipal(100);
        myCommission.setCommissionRate(5);

        myCommission = new Commission(myCommission.getPrincipal(), myCommission.getCommissionRate());

        System.out.println("Principal: " + myCommission.getPrincipal());
        System.out.println("Commission Rate: " + myCommission.getCommissionRate());

        myCommission.calculate();
    }
}