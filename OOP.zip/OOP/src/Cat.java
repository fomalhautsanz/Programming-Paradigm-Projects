import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Cat {
    private int hungry;
    private int mood;
    private int energy;
    Scanner input = new Scanner(System.in);

    Cat(){
        hungry=100;
        mood=100;
        energy=100;
    }

    public void feed(){
        if (hungry<=0){
            System.out.println("\nMeowy is not hungry anymore!");
        }
        else {
            hungry-=10;
        }
        System.out.println();
        displayStatus();
    }

    public void play(){
       if (mood>=100){
           System.out.println("\nMood bar is already full!");
       } else {
           mood += 10;
           hungry += 10;
           energy -= 10;
       }
        System.out.println();
        displayStatus();
    }

    public void sleep(){
        if (energy>=100){
            System.out.println("\nEnergy bar is already full!");
        }
        else {
            energy+=10;
        }
        System.out.println();
        displayStatus();
    }

    public void ignore(){
        if (mood<=0 || hungry>=100){
            System.out.println("\nYou've been ignoring Meowy for too long!");
        }
        else {
            mood-=10;
            hungry+=10;
        }
        System.out.println();
        displayStatus();
    }

    public void displayStatus(){
        System.out.println("MEOWY'S STATUS");
        System.out.println("Hunger: " + hungry);
        System.out.println("Mood: " + mood);
        System.out.println("Energy: " + energy);
    }

    public void myCat(){
        System.out.println();
        try{
            FileReader myCat = new FileReader("D:\\File Handling\\catto.txt");
            Scanner myReader = new Scanner(myCat);
            while(myReader.hasNextLine()){
                String data = myReader.nextLine();
                System.out.println(data);
            }
            myReader.close();
        }
        catch (IOException e){
            System.out.println("An error occured.");
            e.printStackTrace();
        }
        System.out.println();
    }

    public void actions(){
        while (true) {
            myCat();
            System.out.println("Meowy is your very own orange kitty. What do you want to do? ");
            System.out.println("1. Feed her");
            System.out.println("2. Play with her");
            System.out.println("3. Let her sleep");
            System.out.println("4. Ignore her");
            System.out.println("5. Leave");
            int choice = input.nextInt();
            input.nextLine();

            switch (choice) {
                case 1:
                    feed();
                    break;
                case 2:
                    play();
                    break;
                case 3:
                    sleep();
                    break;
                case 4:
                    ignore();
                    break;
                case 5:
                    System.out.println("\nYou made Meowy cry. She hates you now!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("\nDo something you stupid owner\n");
                    break;
            }
        }
    }
}
