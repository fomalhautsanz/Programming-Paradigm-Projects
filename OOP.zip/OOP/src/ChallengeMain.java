import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ChallengeMain {
    public static void main (String[] args){
        Scanner input = new Scanner(System.in);

        try {
            System.out.print("Enter your name: ");
            String name = input.nextLine();
            System.out.print("Enter your nation: ");
            String nation = input.nextLine();
            System.out.print("Enter your height (in meters): ");
            double height = input.nextDouble();
            System.out.print("Enter your weight (in kg): ");
            double weight = input.nextDouble();
            System.out.println();
            Challenge details = new Challenge(name,nation,height,weight);
        }
        catch (InputMismatchException e){
            System.out.println("An error occurred. Ensure that the information is encoded correctly.");
        }


    }
}
