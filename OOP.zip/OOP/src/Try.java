import java.util.Scanner;

public class Try {
    Scanner input = new Scanner(System.in);

    String name;
    String idNum;
    double grade;
    Try[] classList = new Try[100];
    int count=0;
    String gradeStat = (grade>74)? "PASSED":"FAILED";

    void menu(){
        while (true) {
            System.out.println("1. Display Student");
            System.out.println("2. Add Student");
            System.out.println("3. Remove Student");
            int choice = input.nextInt();
            input.nextLine();

            if (choice == 1) {
                displayStudent();
            } else if (choice == 2) {
                addStudent();
            } else if (choice == 3) {
                removeStudent();
            } else {
                System.out.println("Invalid input!");
                return;
            }
        }
    }

    void addStudent(){
        classList[count]=new Try();
        if(classList[count]!=null){
            System.out.print("Enter name: ");
            classList[count].name = input.nextLine();
            System.out.print("Enter ID number: ");
            classList[count].idNum = input.nextLine();
            System.out.print("Enter grade: ");
            classList[count].grade = input.nextDouble();
            classList[count].gradeStat = isPassing(classList[count].grade);
            count++;
            input.nextLine();
        }
    }

    void removeStudent(){
        System.out.print("Enter the student number to delete: ");
        int num = input.nextInt();

        for (int i=num-1;i<count-1; i++){
            classList[i]=classList[i+1];
        }
        classList[count-1]=null;
        count--;
    }

    void displayStudent() {

        if (count == 0) {
            System.out.println("Student list is currently empty...");
            return;
        }
        System.out.println("Now displaying the class list...");
        for (int i = 0; i < count; i++) {
            if (classList[i] != null) {
                System.out.println((i + 1) + ").");
                System.out.println("Name: " + classList[i].name);
                System.out.println("ID Number: " + classList[i].idNum);
                System.out.println("Grade: " + classList[i].grade +
                "\nStatus: " + isPassing(classList[i].grade));
            }
        }
    }

    String isPassing(double grade){
        return (grade > 74) ? "PASSED" : "FAILED";
    }
}
