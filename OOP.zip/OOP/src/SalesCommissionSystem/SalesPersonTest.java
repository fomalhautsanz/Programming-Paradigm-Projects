package SalesCommissionSystem;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class SalesPersonTest {

    public static void main (String[] args) throws IOException {
        Scanner input = new Scanner(System.in);
            try {
                System.out.print("Enter name: ");
                String name = input.nextLine();
                System.out.print("Enter sales amount: ");
                int salesAmount = input.nextInt();
                Salesperson salesperson1 = new Salesperson(name, salesAmount);

                input.nextLine();
                System.out.println();

                System.out.print("Enter name: ");
                name = input.nextLine();
                System.out.print("Enter sales amount: ");
                salesAmount = input.nextInt();
                Salesperson salesperson2 = new Salesperson(name, salesAmount);

                System.out.println();
                System.out.println("Name: " + salesperson1.getName());
                System.out.println("Sales Amount: " + salesperson1.getSalesAmount());
                System.out.println();
                System.out.println("Name: " + salesperson2.getName());
                System.out.println("Sales Amount: " + salesperson2.getSalesAmount());

                System.out.print("Apply a commission rate for " + salesperson1.getName() + ": ");
                double rate = input.nextDouble();
                System.out.print("Commission: " + salesperson1.applyCommission(rate));
                System.out.println();
                System.out.print("Apply a commission rate for " + salesperson2.getName() + ": ");
                rate = input.nextDouble();
                System.out.println("Commission: " + salesperson2.applyCommission(rate));
                System.out.println();
                System.out.println("Transferring sales from " + salesperson2.getName() + " to " + salesperson1.getName());
                System.out.print("Enter sales amount to transfer: ");
                double amount = input.nextDouble();
                salesperson1.transferSales(salesperson2, amount);

                System.out.println();
                System.out.println("Name: " + salesperson1.getName());
                System.out.println("Sales Amount: " + salesperson1.getSalesAmount());


                System.out.println("Name: " + salesperson2.getName());
                System.out.println("Sales Amount: " + salesperson2.getSalesAmount());

                System.out.println();
                System.out.println("TOTAL SALES : " + Salesperson.totalSales);
            } catch (InputMismatchException e) {
                input.nextLine();
                System.out.println("Please enter a valid credentials!");
            } catch (RuntimeException e){
                System.out.println("Rate must be positive!");
            }

    }

    /*public void menu (){
        while (true){
            System.out.println("SALES COMMISSION SYSTEM");
            System.out.println("1. Add Person");
            System.out.println("2. Apply Commission Rate");
            System.out.println("3. Transfer Sales");
            int choice = input.nextInt();

            switch (choice){
                case 1:
                    System.out.println("Enter name");
            }
        }
    }

     */
}
