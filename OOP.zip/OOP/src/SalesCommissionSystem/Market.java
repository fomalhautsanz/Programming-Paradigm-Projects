package SalesCommissionSystem;

import java.io.IOException;

public class Market {
    String productName;
    int stocks;

    Market (String productName,int stocks){
        this.productName=productName;
        this.stocks=stocks;
    }

    public void initialize(Market market){
        market.productName = "Coconut";
        market.stocks = 100;
    }

    public void order (int ordered){
        try{
            if (ordered<0){
                throw new IllegalArgumentException("Value must be positive");
            }
            if (ordered>stocks){
                throw new Exception("Insufficient stocks");
            }
            stocks-=ordered;
        } catch (Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void transfer (Market product, int transferStocks){
        try{
            if (transferStocks<0){
                throw new IllegalArgumentException("Enter a positive amount");
            }
            if (transferStocks>stocks){
                throw new Exception(this.productName + " has insufficient stocks");
            }
            product.stocks-=transferStocks;
            this.stocks+=transferStocks;
        } catch (Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) throws IOException {
        Market coconut1 = new Market("Coconut v1",20);
        Market coconut2 = new Market("Coconut v2",30);

        System.out.println("Product: " + coconut1.productName);
        System.out.println("Stocks: " + coconut1.stocks);
        System.out.println("Product: " + coconut2.productName);
        System.out.println("Stocks: " + coconut2.stocks);

        coconut1.order(5);
        coconut2.order(3);

        System.out.println("Product: " + coconut1.productName);
        System.out.println("Stocks: " + coconut1.stocks);
        System.out.println("Product: " + coconut2.productName);
        System.out.println("Stocks: " + coconut2.stocks);

        coconut1.transfer(coconut2,8);

        System.out.println("Product: " + coconut1.productName);
        System.out.println("Stocks: " + coconut1.stocks);
        System.out.println("Product: " + coconut2.productName);
        System.out.println("Stocks: " + coconut2.stocks);

    }
}
