package SalesCommissionSystem;

import java.util.Scanner;

public class Salesperson {
    Scanner input = new Scanner(System.in);
    private String name;
    private double salesAmount;
    private double commissionRate;
    static int totalSales=0;

    Salesperson(String name, int salesAmount){
        this.name = name;
        this.salesAmount = salesAmount;
        totalSales+=salesAmount;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setSalesAmount(int salesAmount) {
        try {
            if (salesAmount < 0) {
                throw new IllegalArgumentException("Sales must be positive!");
            }

            this.salesAmount = salesAmount;
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());;
        }
    }

    public double getSalesAmount() {
        return salesAmount;
    }

    public void setCommissionRate(double commissionRate) {
        try{
            if (commissionRate<0){
                throw new IllegalArgumentException("Commission rate must be positive!");
            }
            this.commissionRate = commissionRate;
        } catch (IllegalArgumentException e) {
            throw new RuntimeException(e);
        }
    }

    public double getCommissionRate() {
        return commissionRate;
    }

    public double applyCommission(double rate){
        try{
            if (rate<0){
                throw  new IllegalArgumentException("Rate must be positive!");
            }
            return salesAmount*rate/100;
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
            return 0.0;
        }
    }

    public double applyCommission(){
        return (double) (salesAmount * 10) /100;
    }

    public static int getTotalSales() {
        return totalSales;
    }

    public void display(){
        System.out.println("Name: " + getName());
        System.out.println("Sales Amount: " + getSalesAmount());
        System.out.println("--------------------------------------------------");
    }

    public void transferSales(Salesperson from, double amount){
        try{
            if (amount<0){
                input.nextLine();
                throw new IllegalArgumentException("Please enter a positive amount");
            }
            if (amount>from.getSalesAmount()){
                throw new Exception(from.getName() + " has insufficient funds");
            }
            from.salesAmount-=amount;
            this.salesAmount+=amount;
        } catch (Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }
}
