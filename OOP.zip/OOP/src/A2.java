public class A2 {
    public static void main (String[] args){

        A1 char1 = new A1("Bernard","I can end the eternity!",100, 65, 10);
        A1 char2 = new A1("Evelyn", "I will save you.", 90, 80, 10);

        char2.sayDialogue();
        char2.manaHealth();
        System.out.println();
    }
}
