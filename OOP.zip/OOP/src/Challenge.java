public class Challenge {

    String name;
    String nation;
    double height;
    double weight;

    public Challenge(String name, String nation, double height, double weight){
        this.name = name;
        this.nation = nation;
        this.height = height;
        this.weight = weight;

        System.out.println( "THIS PERSON WAS ADDED TO THE LIST" +
                "\nName: " + name +
                "\nNation: " + nation +
                "\nHeight: " + height + " m" +
                "\nWeight: " +  weight + " kg"
        );
    }
}
