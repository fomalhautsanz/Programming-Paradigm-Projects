import java.util.Objects;
import java.util.Scanner;

public class BankTest2 {
    public static void main (String[] args){
        Scanner input = new Scanner(System.in);
        Bank[] banks = new Bank[100];
        int count=0;

        while (true) {
            System.out.println("1. Create a new account\n" +
                    "2. Log In");
            int choice = input.nextInt();
            input.nextLine();

            if (choice == 1) {
                if (count < banks.length) {
                    banks[count] = new Bank();
                    System.out.print("Enter account name: ");
                    banks[count].name = input.nextLine();
                    System.out.print("Enter account number: ");
                    banks[count].accountNum = input.nextLine();
                    System.out.print("Enter initial balance: ");
                    banks[count].balance = input.nextInt();
                    input.nextLine();
                    count++;
                } else {
                    System.out.println("Account limit reached!");
                }

            } else if (choice == 2) {
                System.out.print("Enter account name: ");
                String name = input.nextLine();
                System.out.print("Enter account number: ");
                String accountNum = input.nextLine();

                boolean found = false;
                for (int i = 0; i < banks.length; i++) {
                    if (banks[i] != null && Objects.equals(name, banks[i].name) && Objects.equals(accountNum, banks[i].accountNum)) {
                        banks[i].displayAcc();
                        banks[i].bankMenu();
                        found = true;
                        break;
                    }
                }
                if (!found){
                    System.out.println("Invalid username or password!");
                }
            }
        }
    }
}
