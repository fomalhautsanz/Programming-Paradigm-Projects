import java.util.Scanner;

public class B2 {
    public static void main (String[] args){
        Scanner input = new Scanner(System.in);

        System.out.println("STUDENT OBJECT SIMULATION");
        System.out.println("=================================");
        System.out.print("First Name: ");
        String firstName = input.nextLine();
        System.out.print("Last Name: ");
        String lastName = input.nextLine();
        System.out.print("Year: ");
        String year = input.nextLine();
        System.out.print("Course: ");
        String course = input.nextLine();
        System.out.print("Section: ");
        String section = input.nextLine();
        System.out.print("Midterm Grade: ");
        double midtermGrade = input.nextDouble();
        System.out.print("Final Grade: ");
        double finalGrade = input.nextDouble();

        System.out.println(" ");
        System.out.println("RESULT");
        System.out.println("===================================");
        B1 studentEvaluation = new B1(firstName,lastName,year,course,section,midtermGrade,finalGrade);
        System.out.println(" ");
        studentEvaluation.introduceSelf();
        System.out.println(" ");
        studentEvaluation.evaluateGrade();
    }
}
