public class First {
    public static void main (String[] args){

        Planets planet1 = new Planets();
        planet1.planet = "Mercury";
        planet1.type = "Terrestrial";
        planet1.revolution = "89.97 days";
        planet1.diameter = "4.879 km";

        Planets planet2 = new Planets();
        planet2.planet = "Venus";
        planet2.type = "Terrestrial";
        planet2.revolution = "243 days";
        planet2.diameter = "12.104 km";

        Planets[] planets = {planet1, planet2};

        for (Planets planet : planets){
            System.out.println("Planet: " +  planet.planet);
            System.out.println("Type: " + planet.type);
            System.out.println("Revolution: " + planet.revolution);
            System.out.println("Diameter: " + planet.diameter);
            System.out.println();
        }

    }
}
