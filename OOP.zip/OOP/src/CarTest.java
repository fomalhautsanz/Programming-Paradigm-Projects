import java.util.Scanner;

public class CarTest {
    public static void main (String[] args){
        Scanner input = new Scanner(System.in);

        //NOTE: TAWAGA ANG CLASS BY MAKING AN OBJECT
        Car car1 = new Car();
        //NOTE: DON'T FORGET TO INITIALIZE THE VALUES PARA DILI MO-NULL ANG I-PRINT
        car1.make = "Toyota";
        car1.model = "Corolla";
        car1.year = 2020;
        car1.price = 100000;
        car1.displayInfo(); //NOTE: DISPLAY DIRI ANG ORIGINAL PRICE

        System.out.print("Enter the discount rate (%) for " + car1.make + " " + car1.model + ": ");
        double rate = input.nextDouble();
        //NOTE: CALL THE OBJECT FIRST THEN ANG METHOD NIYA TAS ISULOD SA PARAMETER ANG RATE (PERCENTAGE)
        car1.applyDiscount(rate);
        car1.displayInfo(); //NOTE: DISPLAY DIRI ANG UPDATED PRICE


        //NOTE: SAME PROCESS ABOVE
        Car car2 = new Car();
        car2.make = "Honda";
        car2.model = "Civic";
        car2.year = 2021;
        car2.price = 100000;
        car2.displayInfo();

        System.out.print("Enter the discount rate (%) for " + car2.make + " " + car2.model + ": ");
        rate = input.nextDouble();
        car2.applyDiscount(rate);
        car2.displayInfo();
    }
}
