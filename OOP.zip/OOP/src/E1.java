import java.util.Random;

public class E1 {
    private String songTitle;
    private String songArtist;
    static E1[] songs = new E1[100];

    E1(){

    }

    E1(String songTitle, String songArtist){
        this.songTitle=songTitle;
        this.songArtist=songArtist;
    }

    String getSongTitle(){
        return songTitle;
    }

    String getSongArtist(){
        return songArtist;
    }

    void addSong (E1 song){
        for (int i=0; i<100; i++){
            if (songs[i]==null){
                songs[i]=song;
                break;
            }
        }
    }

    void removeSong (E1 removeSong){
        for (int i=0; i<100; i++){
            if (songs[i]==removeSong){
                songs[i]=null;
                break;
            }
        }
    }

    void randomSong(){
        int size = songs.length;
        if (size==0){
            System.out.print("Song list is empty");
            return;
        }

        Random random = new Random();
        int index = random.nextInt(size);
        System.out.println("Now playing: " + songs[index].getSongTitle() + " by " + songs[index].getSongArtist());
    }

    void displaySongs(){
        for (int i=0; i<100; i++){
            System.out.println(i+1 + ").");
            if (songs[i]!=null){
                System.out.println(songs[i].songTitle);
                System.out.println(songs[i].getSongArtist());
            }
        }
    }
}
