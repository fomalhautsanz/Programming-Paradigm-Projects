public class SavingsAccount {

    static double annualInterestRate;
    private double savingsBalance;

    SavingsAccount(){
        annualInterestRate = 0;
        savingsBalance = 0;
    }

    public double calculateMonthlyInterest(double interestRate){
        return savingsBalance += savingsBalance * (interestRate/100) / 12;
    }

    public static void modifyInterestRate (double newInterestRate){
        annualInterestRate=newInterestRate;
    }

    public void setSavingsBalance(double savingsBalance) {
        this.savingsBalance = savingsBalance;
    }

    public static double getAnnualInterestRate() {
        return annualInterestRate;
    }
}
