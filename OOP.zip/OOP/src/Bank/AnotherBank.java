package Bank;

public class AnotherBank {
    private int accountNumber;
    private String accountHolderName;
    private double balance;

    AnotherBank(int accountNumber,String accountHolderName,double balance){
        this.accountNumber=accountNumber;
        this.accountHolderName=accountHolderName;
        this.balance=balance;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public double getBalance() {
        return balance;
    }

    public void depositMoney(double deposit){
        if (deposit<0){
            System.out.println("Please enter a valid amount!");
        }
        else {
            balance+=deposit;
            System.out.println("Deposited successfully!");
            System.out.println("Updated balance: " + getBalance());
        }
    }

    public void withdrawMoney(double withdraw){
        if (withdraw>balance){
            System.out.println("Insufficient funds!");
        }
        else {
            balance-=withdraw;
            System.out.println("Deposited successfully!");
            System.out.println("Updated balance: " + getBalance());
        }
    }

    public void checkBalance(){
        System.out.println("Your current balance is: " + balance);
    }
}
