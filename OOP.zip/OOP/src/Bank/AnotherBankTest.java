package Bank;

public class AnotherBankTest {
    public static void main (String[] args){
        AnotherBank myBank = new AnotherBank(1009,"Hermosa Santos",2100);
        System.out.println(myBank.getAccountNumber());
        System.out.println(myBank.getAccountHolderName());
        System.out.println(myBank.getBalance());
        myBank.depositMoney(300);
        myBank.withdrawMoney(500);
        myBank.checkBalance();
    }
}
