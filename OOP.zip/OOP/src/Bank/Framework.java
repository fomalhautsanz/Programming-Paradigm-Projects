package Bank;

import java.util.Objects;
import java.util.Scanner;

public class Framework {
    Scanner input = new Scanner(System.in);
    private String adminName="paradox000";
    private String password="asdfghkl";
    private String clientName;
    private String accountType;
    private int id;
    private double balance;

    Framework(){

    }

    Framework(String clientName,String accountType,int id,double balance){
        this.clientName=clientName;
        this.accountType=accountType;
        this.id=id;
        this.balance=balance;
    }

    public String getAdminName() {
        return adminName;
    }

    public String getPassword() {
        return password;
    }

    public void createAcc(){
        System.out.print("Enter name: ");
        this.clientName = input.nextLine();
        System.out.print("Enter account type: ");
        this.accountType = input.nextLine();
        System.out.print("Enter ID: ");
        this.id = input.nextInt();
        System.out.print("Enter initial balance: ");
        this.balance = input.nextDouble();
        input.nextLine();
        System.out.println("Account created successfully!");
    }

    public void displayInfo(){
        System.out.println("Client Name: " + clientName);
        System.out.println("Account Type: " + accountType);
        System.out.println("ID: " + id);
        System.out.println("Balance: " + balance);
    }

    boolean isAdmin(String enteredName, String enteredPassword){
        return (Objects.equals(enteredName, getAdminName()) && Objects.equals(enteredPassword, getPassword()));
    }

    public void deposit(double depositedMoney){
        balance+=depositedMoney;
        System.out.println("Deposit successful!");
    }

    public void withdrawMoney(double withdrewMoney){
        if (withdrewMoney>balance){
            System.out.println("Insufficient funds!");
        }
        else if (withdrewMoney>0){
            balance-=withdrewMoney;
            System.out.println("Withdraw successful!");
        }
    }
}


class BankSystem4 {
    static Framework newAcc = new Framework();
    static Scanner input = new Scanner(System.in);
    public static void main (String[] args) {

        System.out.println("WELCOME TO BANK LAND");
        System.out.println("1. Log In");
        System.out.println("2. Exit");
        int choice = input.nextInt();
        input.nextLine();

        if (choice == 1) {
            System.out.print("Enter username: ");
            String username = input.nextLine();
            System.out.print("Enter password: ");
            String password = input.nextLine();

            if (newAcc.isAdmin(username, password)) {
                actionsTaken();
            } else {
                System.out.println("Incorrect username/password! Try Again.");
                return;
            }
        } else if (choice == 2) {
            System.out.println("Now exiting...");
            System.exit(0);
        }
    }


    public static void actionsTaken(){
        while (true) {
            System.out.println("1. Create New Acc");
            System.out.println("2. Deposit Money");
            System.out.println("3. Withdraw Money");
            System.out.println("4. Display Information");
            System.out.println("5. Exit");
            int choice = input.nextInt();
            input.nextLine();

            if (choice == 1) {
                newAcc.createAcc();
            } else if (choice == 2) {
                System.out.print("Enter deposit amount: ");
                double deposit = input.nextDouble();
                newAcc.deposit(deposit);
            } else if (choice == 3) {
                System.out.print("Enter withdraw amount: ");
                double withdraw = input.nextDouble();
                newAcc.withdrawMoney(withdraw);
            } else if (choice == 4) {
                newAcc.displayInfo();
            } else if (choice == 5) {
                System.out.println("Thank you for choosing Bank Land! Now exiting the program...");
                System.exit(0);
            } else {
                System.out.println("Invalid input!");
            }
        }
    }
}
