package Bank;

public class BankAccount {
    String holderName;
    double balance;
    static int totalAccounts=0;

    BankAccount (String holderName,double balance){
        this.holderName = holderName;
        this.balance = balance;
        totalAccounts++;
    }

    public static int getTotalAccounts(){
        return totalAccounts;
    }

    public void deposit(double amount){
        balance+=amount;
    }

    public void deposit(){
        deposit(100);
    }

    public void withdraw(double amount){
        try {
            if (amount<=0){
                throw new IllegalArgumentException("Amount must be positive");
            }
            if (amount>balance){
                throw new Exception("Insufficient funds!");
            }
            this.balance-=amount;
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void transfer (BankAccount from, double amount){
            try{
                if (amount<=0){
                    throw new IllegalArgumentException("Amount must be positive.");
                }
                if (amount> from.balance){
                    throw new Exception("Insufficient balance from " + from.holderName);
                }
                from.balance-=amount;
                this.balance+=amount;
            } catch (Exception e){
                System.out.println("Error: " + e.getMessage());
            }
    }


    public static void main (String[] args){
        BankAccount acc1 = new BankAccount("William Jones", 1500);
        BankAccount acc2 = new BankAccount("Rose Samuel", 2000);
        BankAccount acc3 = new BankAccount("Mariah Carey", 3000);

        System.out.println("BEFORE USING THE METHODS:");
        System.out.println(acc1.holderName + " : " + acc1.balance);
        System.out.println(acc2.holderName + " : " + acc2.balance);
        System.out.println(acc3.holderName + " : " + acc3.balance);
        System.out.println("Total Accounts: " + getTotalAccounts());
        System.out.println();

        acc1.deposit(1000);
        acc2.deposit(1000);
        acc3.deposit(1000);

        System.out.println("AFTER USING THE METHODS:");
        System.out.println(acc1.holderName + " : " + acc1.balance);
        System.out.println(acc2.holderName + " : " + acc2.balance);
        System.out.println(acc3.holderName + " : " + acc3.balance);
        System.out.println(getTotalAccounts());
        System.out.println();

        acc1.withdraw(-1);
        System.out.println(acc1.holderName + " : " + acc1.balance);
        System.out.println(acc2.holderName + " : " + acc2.balance);
    }

}
