public class Objects {
    int i;
    int j;

    Objects(int a, int b){
        i=a;
        j=b;
    }

    void method (Objects ob){
        ob.i/=2;
        ob.j*=2;
    }

    public static void main (String[] marjhun){
        Objects ob = new Objects(30,10);
        System.out.println("a = " + ob.i + " b = " + ob.j);
        ob.method(ob);
        System.out.println("a = " + ob.i + " b = " + ob.j);
    }
}
