public class B1 {
    String firstName, lastName, year, course, section;
    double midtermGrade, finalGrade;

    B1 (String firstName, String lastName, String year, String course, String section, double midtermGrade, double finalGrade){
        this.firstName = firstName;
        this.lastName = lastName;
        this.year = year;
        this.course = course;
        this.section = section;
        this.midtermGrade = midtermGrade;
        this.finalGrade = finalGrade;
    }

    void introduceSelf(){
        System.out.println("Full Name: " + firstName + " " + lastName
        + "\nCourse: " + course
        + "\nYear: " + year
        + "\nSection: " + section);
    }

    void evaluateGrade(){
        double average = (midtermGrade+finalGrade)/2;
        System.out.println("Name: " + firstName + " " + lastName);
        System.out.println("Average: " + average);

        String remark = "";
        if (average > 100 || average < 0){
            remark = "Invalid Grade";
        }
        else if (average>=98){
            remark = "With Highest Honors";
        }
        else if (average>=95){
            remark = "With High Honors";
        }
        else if (average>=90){
            remark = "With Honors";
        }
        else if (average>=75){
            remark = "Passed";
        }
        else if (average<75){
            remark = "Failed";
        }
        System.out.println("Remarks: " + remark);
    }
}
