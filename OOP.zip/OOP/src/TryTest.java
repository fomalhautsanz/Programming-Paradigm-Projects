public class TryTest {
    public static void main (String[] args){
        Try studentList = new Try();
        studentList.menu();
    }
}
